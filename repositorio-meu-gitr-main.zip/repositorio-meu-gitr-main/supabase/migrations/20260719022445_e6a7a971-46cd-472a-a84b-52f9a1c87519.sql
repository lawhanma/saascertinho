CREATE TABLE public.device_balances (
  device_id text PRIMARY KEY,
  balance numeric NOT NULL DEFAULT 0,
  divulg_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.device_balances TO anon, authenticated;
GRANT ALL ON public.device_balances TO service_role;

ALTER TABLE public.device_balances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read device balances"
  ON public.device_balances FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert device balances"
  ON public.device_balances FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update device balances"
  ON public.device_balances FOR UPDATE
  USING (true) WITH CHECK (true);