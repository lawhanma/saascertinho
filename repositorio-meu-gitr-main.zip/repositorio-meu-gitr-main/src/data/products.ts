import camisetaBrasil from "@/assets/camiseta-brasil.jpg";
import bandeiraBrasil from "@/assets/bandeira-brasil.jpg";
import foneBluetooth from "@/assets/fone-bluetooth.jpg";
import smartwatch from "@/assets/smartwatch.jpg";
import mouseGamer from "@/assets/mouse-gamer.jpg";
import caixaSom from "@/assets/caixa-som.jpg";
import garrafaTermica from "@/assets/garrafa-termica.jpg";
import ringLight from "@/assets/ring-light.jpg";
import airFryer from "@/assets/air-fryer.jpg";
import panelaArroz from "@/assets/panela-arroz.jpg";
import liquidificador from "@/assets/liquidificador.jpg";
import aspiradorRobo from "@/assets/aspirador-robo.jpg";
import cafeteira from "@/assets/cafeteira.jpg";
import sanduicheira from "@/assets/sanduicheira.jpg";
import perfume from "@/assets/perfume.jpg";
import skincare from "@/assets/skincare.jpg";
import secador from "@/assets/secador.jpg";
import chapinha from "@/assets/chapinha.jpg";
import tenis from "@/assets/tenis.jpg";
import mochila from "@/assets/mochila.jpg";
import oculos from "@/assets/oculos.jpg";
import carteira from "@/assets/carteira.jpg";
import caboUsbc from "@/assets/cabo-usbc.jpg";
import carregadorWireless from "@/assets/carregador-wireless.jpg";
import suporteCelular from "@/assets/suporte-celular.jpg";
import cameraSeguranca from "@/assets/camera-seguranca.jpg";
import teclado from "@/assets/teclado.jpg";
import webcam from "@/assets/webcam.jpg";

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  image: string;
  sold: number;
  rating: number;
  tag?: string;
};

export const products: Product[] = [
  {
    id: "camiseta-brasil",
    name: "Camiseta do Brasil Oficial",
    description:
      "Camiseta amarela com tecido dry-fit, ideal para torcedores. Confortável e de alta durabilidade.",
    price: 79.9,
    oldPrice: 129.9,
    image: camisetaBrasil,
    sold: 12483,
    rating: 4.9,
    tag: "TOP VENDAS",
  },
  {
    id: "bandeira-brasil",
    name: "Bandeira do Brasil 1,50m",
    description:
      "Bandeira oficial em poliéster resistente, cores vibrantes e acabamento reforçado.",
    price: 34.9,
    oldPrice: 59.9,
    image: bandeiraBrasil,
    sold: 8232,
    rating: 4.8,
    tag: "EM ALTA",
  },
  {
    id: "fone-bluetooth",
    name: "Fone de Ouvido Bluetooth Pro",
    description: "Fone TWS com cancelamento de ruído, bateria de 30h e conexão Bluetooth 5.3.",
    price: 89.9,
    oldPrice: 199.9,
    image: foneBluetooth,
    sold: 24157,
    rating: 4.7,
    tag: "MAIS VENDIDO",
  },
  {
    id: "smartwatch",
    name: "Relógio SmartWatch W9",
    description:
      "Monitor cardíaco, chamadas, GPS e mais de 100 modos esportivos. Compatível iOS e Android.",
    price: 149.9,
    oldPrice: 299.9,
    image: smartwatch,
    sold: 18764,
    rating: 4.8,
    tag: "TOP VENDAS",
  },
  {
    id: "mouse-gamer",
    name: "Mouse Gamer RGB 7200 DPI",
    description:
      "Mouse gamer com iluminação RGB, sensor óptico de alta precisão and 7 botões programáveis.",
    price: 59.9,
    oldPrice: 119.9,
    image: mouseGamer,
    sold: 9817,
    rating: 4.6,
    tag: "OFERTA",
  },
  {
    id: "caixa-som",
    name: "Caixa de Som Bluetooth Bass",
    description: "Caixa portátil com som potente, à prova d'água IPX7 e 12h de autonomia.",
    price: 119.9,
    oldPrice: 219.9,
    image: caixaSom,
    sold: 7342,
    rating: 4.7,
  },
  {
    id: "garrafa-termica",
    name: "Garrafa Térmica Inox 1L",
    description:
      "Mantém a temperatura por até 24h. Aço inoxidável, livre de BPA, tampa vedação total.",
    price: 44.9,
    oldPrice: 79.9,
    image: garrafaTermica,
    sold: 5129,
    rating: 4.9,
  },
  {
    id: "ring-light",
    name: 'Ring Light 10" com Tripé',
    description:
      "Iluminação profissional para lives, com 3 tons de luz, controle e suporte para celular.",
    price: 69.9,
    oldPrice: 139.9,
    image: ringLight,
    sold: 6813,
    rating: 4.7,
    tag: "CRIADORES",
  },
  {
    id: "air-fryer",
    name: "Air Fryer Digital 4L",
    description: "Fritadeira sem óleo com painel digital, 8 funções e cesto antiaderente.",
    price: 299.9,
    oldPrice: 499.9,
    image: airFryer,
    sold: 15234,
    rating: 4.8,
    tag: "MAIS VENDIDO",
  },
  {
    id: "panela-arroz",
    name: "Panela Elétrica de Arroz 1,8L",
    description: "Cozinha até 10 xícaras, função aquecer e revestimento antiaderente.",
    price: 139.9,
    oldPrice: 229.9,
    image: panelaArroz,
    sold: 4217,
    rating: 4.7,
  },
  {
    id: "liquidificador",
    name: "Liquidificador 1200W Turbo",
    description: "12 velocidades, jarra de 2L e lâminas em aço inox para gelo.",
    price: 189.9,
    oldPrice: 349.9,
    image: liquidificador,
    sold: 6891,
    rating: 4.6,
  },
  {
    id: "aspirador-robo",
    name: "Aspirador Robô Inteligente",
    description: "Mapeamento a laser, controle por app, até 120min de bateria.",
    price: 899.9,
    oldPrice: 1499.9,
    image: aspiradorRobo,
    sold: 3123,
    rating: 4.8,
    tag: "PREMIUM",
  },
  {
    id: "cafeteira",
    name: "Cafeteira Espresso Inox",
    description: "Pressão 15 bar, vaporizador de leite e reservatório 1,5L.",
    price: 499.9,
    oldPrice: 899.9,
    image: cafeteira,
    sold: 2541,
    rating: 4.9,
  },
  {
    id: "sanduicheira",
    name: "Sanduicheira Grill Antiaderente",
    description: "Prepara sanduíches e mini grelhados em minutos. 750W.",
    price: 89.9,
    oldPrice: 149.9,
    image: sanduicheira,
    sold: 5326,
    rating: 4.5,
  },
  {
    id: "perfume",
    name: "Perfume Masculino Black 100ml",
    description: "Fragrância amadeirada e marcante, alta fixação e projeção.",
    price: 129.9,
    oldPrice: 249.9,
    image: perfume,
    sold: 9819,
    rating: 4.8,
    tag: "OFERTA",
  },
  {
    id: "skincare",
    name: "Kit Skincare Facial Completo",
    description: "Sérum vitamina C, hidratante e ácido hialurônico para pele radiante.",
    price: 149.9,
    oldPrice: 289.9,
    image: skincare,
    sold: 7652,
    rating: 4.9,
    tag: "TOP BELEZA",
  },
  {
    id: "secador",
    name: "Secador Profissional 2000W",
    description: "Íons negativos, 3 temperaturas e difusor incluso. Cabelo brilhoso e rápido.",
    price: 179.9,
    oldPrice: 329.9,
    image: secador,
    sold: 6127,
    rating: 4.7,
  },
  {
    id: "chapinha",
    name: "Prancha Chapinha Cerâmica",
    description: "Aquecimento em 30s, até 230°C, tecnologia nano titânio.",
    price: 99.9,
    oldPrice: 199.9,
    image: chapinha,
    sold: 8341,
    rating: 4.6,
  },
  {
    id: "tenis",
    name: "Tênis Esportivo Corrida Pro",
    description: "Amortecimento em EVA, cabedal em mesh respirável e solado antiderrapante.",
    price: 199.9,
    oldPrice: 379.9,
    image: tenis,
    sold: 11246,
    rating: 4.8,
    tag: "TOP VENDAS",
  },
  {
    id: "mochila",
    name: "Mochila Impermeável Anti-Furto",
    description: 'Compartimento para notebook 15", entrada USB e tecido resistente à água.',
    price: 139.9,
    oldPrice: 259.9,
    image: mochila,
    sold: 4893,
    rating: 4.7,
  },
  {
    id: "oculos",
    name: "Óculos de Sol Polarizado UV400",
    description: "Lentes polarizadas com proteção UV400, armação leve em metal.",
    price: 79.9,
    oldPrice: 169.9,
    image: oculos,
    sold: 6724,
    rating: 4.6,
  },
  {
    id: "carteira",
    name: "Carteira Slim Couro Legítimo",
    description: "Design ultrafino, bloqueio RFID e 8 compartimentos para cartão.",
    price: 59.9,
    oldPrice: 119.9,
    image: carteira,
    sold: 5213,
    rating: 4.8,
  },
  {
    id: "cabo-usbc",
    name: "Cabo USB-C Turbo 3m Nylon",
    description: "Suporta 100W PD e transferência a 480Mbps. Cabo trançado ultra resistente.",
    price: 24.9,
    oldPrice: 59.9,
    image: caboUsbc,
    sold: 15411,
    rating: 4.7,
    tag: "MAIS VENDIDO",
  },
  {
    id: "carregador-wireless",
    name: "Carregador Wireless 15W Fast",
    description: "Compatível iPhone e Android, indicador LED e proteção antisuperaquecimento.",
    price: 69.9,
    oldPrice: 149.9,
    image: carregadorWireless,
    sold: 4382,
    rating: 4.6,
  },
  {
    id: "suporte-celular",
    name: "Suporte Veicular Magnético",
    description: "Fixação por ímã forte, base adesiva 3M e rotação 360°.",
    price: 29.9,
    oldPrice: 69.9,
    image: suporteCelular,
    sold: 9841,
    rating: 4.7,
    tag: "OFERTA",
  },
  {
    id: "camera-seguranca",
    name: "Câmera de Segurança Wi-Fi HD",
    description: "Visão 360°, áudio bidirecional, visão noturna e alerta de movimento.",
    price: 169.9,
    oldPrice: 329.9,
    image: cameraSeguranca,
    sold: 3723,
    rating: 4.8,
  },
  {
    id: "teclado",
    name: "Teclado Mecânico RGB Gamer",
    description: "Switches azuis, iluminação RGB 16 milhões de cores, anti-ghosting.",
    price: 249.9,
    oldPrice: 449.9,
    image: teclado,
    sold: 5684,
    rating: 4.9,
    tag: "GAMER",
  },
  {
    id: "webcam",
    name: "Webcam Full HD 1080p Pro",
    description: "Foco automático, microfone integrado com cancelamento de ruído.",
    price: 149.9,
    oldPrice: 299.9,
    image: webcam,
    sold: 4213,
    rating: 4.7,
  },
];
