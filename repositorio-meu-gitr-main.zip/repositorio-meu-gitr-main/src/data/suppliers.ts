// Product catalog reorganized by supplier.
// Each product is explicitly paired with its own image to avoid title/image mismatches.

// Seasonal
import ovoPascoa from "@/assets/ovo-pascoa.jpg";
import arvoreNatal from "@/assets/arvore-natal.jpg";
import piscaNatal from "@/assets/pisca-pisca-natal.jpg";
import presenteNamorados from "@/assets/presente-namorados.jpg";
import decoracaoHalloween from "@/assets/decoracao-halloween.jpg";
import bandeiraBrasil from "@/assets/bandeira-brasil.jpg";
import camisetaBrasil from "@/assets/camiseta-brasil.jpg";
// Electronics
import foneBluetooth from "@/assets/fone-bluetooth.jpg";
import smartwatch from "@/assets/smartwatch.jpg";
import mouseGamer from "@/assets/mouse-gamer.jpg";
import caixaSom from "@/assets/caixa-som.jpg";
import ringLight from "@/assets/ring-light.jpg";
import caboUsbc from "@/assets/cabo-usbc.jpg";
import carregadorWireless from "@/assets/carregador-wireless.jpg";
import suporteCelular from "@/assets/suporte-celular.jpg";
import cameraSeguranca from "@/assets/camera-seguranca.jpg";
import teclado from "@/assets/teclado.jpg";
import webcam from "@/assets/webcam.jpg";
import airFryer from "@/assets/air-fryer.jpg";
import aspiradorRobo from "@/assets/aspirador-robo.jpg";
import secador from "@/assets/secador.jpg";
import chapinha from "@/assets/chapinha.jpg";
// Kitchen
import panelaArroz from "@/assets/panela-arroz.jpg";
import liquidificador from "@/assets/liquidificador.jpg";
import cafeteira from "@/assets/cafeteira.jpg";
import sanduicheira from "@/assets/sanduicheira.jpg";
import garrafaTermica from "@/assets/garrafa-termica.jpg";
import jogoFacas from "@/assets/jogo-facas.jpg";
import tabuaCorte from "@/assets/tabua-corte.jpg";
// Diversos
import tenis from "@/assets/tenis.jpg";
import mochila from "@/assets/mochila.jpg";
import oculos from "@/assets/oculos.jpg";
import carteira from "@/assets/carteira.jpg";
import perfume from "@/assets/perfume.jpg";
import skincare from "@/assets/skincare.jpg";
import brinquedoPelucia from "@/assets/brinquedo-pelucia.jpg";
import quadroDecorativo from "@/assets/quadro-decorativo.jpg";
import kitBodySplashVirginia from "@/assets/images/kit_body_splash_virginia_1784526275452.jpg";

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  image: string;
  sold: number;
  rating: number;
  tag?: string;
};

export type Supplier = {
  id: string;
  name: string;
  tagline: string;
  category: string;
  productCount: string;
  cover: string;
  products: Product[];
};

type Item = {
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  image: string;
  tag?: string;
  sold?: number;
  rating?: number;
};

function build(supplierId: string, items: Item[]): Product[] {
  return items.map((it, i) => ({
    id: `${supplierId}-${i + 1}`,
    name: it.name,
    description: it.description,
    price: it.price,
    oldPrice: it.oldPrice,
    image: it.image,
    sold: it.sold !== undefined ? it.sold : 500 + ((i * 137) % 15000),
    rating: it.rating !== undefined ? it.rating : 4.5 + (i % 5) * 0.1,
    tag: it.tag,
  }));
}

// ---------------- SUPPLIER 1: Seasonal ----------------
const sazonaisItems: Item[] = [
  {
    name: "Ovo de Páscoa Recheado 500g",
    description: "Ovo de chocolate ao leite com bombons artesanais e embalagem premium.",
    price: 89.9,
    oldPrice: 149.9,
    tag: "PÁSCOA",
    image: ovoPascoa,
  },
  {
    name: "Árvore de Natal 1,80m Pinheiro",
    description: "Árvore realista canadense com 700 galhos e base metálica.",
    price: 199.9,
    oldPrice: 399.9,
    tag: "NATAL",
    image: arvoreNatal,
  },
  {
    name: "Pisca-Pisca LED 100 Lâmpadas",
    description: "Luzes coloridas 8 modos, 10 metros, uso interno e externo.",
    price: 34.9,
    oldPrice: 79.9,
    tag: "MAIS VENDIDO",
    image: piscaNatal,
  },
  {
    name: "Kit Presente Dia dos Namorados",
    description: "Caixa com chocolates, urso de pelúcia e cartão personalizado.",
    price: 99.9,
    oldPrice: 179.9,
    tag: "AMOR",
    image: presenteNamorados,
  },
  {
    name: "Decoração Halloween Abóbora LED",
    description: "Abóbora de plástico com LED interno para ambientar sua festa.",
    price: 39.9,
    oldPrice: 79.9,
    tag: "HALLOWEEN",
    image: decoracaoHalloween,
  },
  {
    name: "Bandeira do Brasil 1,50m Oficial",
    description: "Poliéster resistente, cores vibrantes, ideal para torcida.",
    price: 34.9,
    oldPrice: 69.9,
    tag: "COPA",
    image: bandeiraBrasil,
  },
  {
    name: "Camiseta do Brasil Copa Oficial",
    description: "Amarela dry-fit torcedor, tamanhos P ao GG.",
    price: 79.9,
    oldPrice: 149.9,
    tag: "COPA",
    image: camisetaBrasil,
  },
];

// ---------------- SUPPLIER 2: Electronics ----------------
const eletroItems: Item[] = [
  {
    name: "Fone Bluetooth TWS Pro",
    description: "TWS com cancelamento de ruído, bateria 30h, Bluetooth 5.3.",
    price: 89.9,
    oldPrice: 199.9,
    tag: "TOP",
    image: foneBluetooth,
  },
  {
    name: "SmartWatch W9 Pro",
    description: "Monitor cardíaco, GPS, chamadas, 100+ modos esportivos.",
    price: 149.9,
    oldPrice: 299.9,
    tag: "MAIS VENDIDO",
    image: smartwatch,
  },
  {
    name: "Mouse Gamer RGB 7200 DPI",
    description: "Sensor óptico, 7 botões programáveis, iluminação RGB.",
    price: 59.9,
    oldPrice: 119.9,
    image: mouseGamer,
  },
  {
    name: "Caixa de Som Bluetooth 20W",
    description: "Portátil, IPX7, bateria 12h, som estéreo potente.",
    price: 119.9,
    oldPrice: 219.9,
    image: caixaSom,
  },
  {
    name: 'Ring Light 10" com Tripé',
    description: "3 tons de luz, tripé 1,60m e suporte para celular.",
    price: 69.9,
    oldPrice: 139.9,
    image: ringLight,
  },
  {
    name: "Cabo USB-C Turbo 3m Nylon",
    description: "100W PD, 480Mbps, trançado ultra resistente.",
    price: 24.9,
    oldPrice: 59.9,
    image: caboUsbc,
  },
  {
    name: "Carregador Wireless 15W Fast",
    description: "Universal iPhone e Android, proteção antisuperaquecimento.",
    price: 69.9,
    oldPrice: 149.9,
    image: carregadorWireless,
  },
  {
    name: "Suporte Veicular Magnético",
    description: "Ímã forte, base 3M, rotação 360°.",
    price: 29.9,
    oldPrice: 69.9,
    image: suporteCelular,
  },
  {
    name: "Câmera Wi-Fi 360° HD",
    description: "Visão noturna, áudio bidirecional, alerta de movimento.",
    price: 169.9,
    oldPrice: 329.9,
    tag: "SEGURANÇA",
    image: cameraSeguranca,
  },
  {
    name: "Teclado Mecânico RGB Gamer",
    description: "Switches azuis, RGB 16M cores, anti-ghosting.",
    price: 249.9,
    oldPrice: 449.9,
    tag: "GAMER",
    image: teclado,
  },
  {
    name: "Webcam Full HD 1080p Pro",
    description: "Foco automático, microfone com cancelamento de ruído.",
    price: 149.9,
    oldPrice: 299.9,
    image: webcam,
  },
  {
    name: "Air Fryer Digital 4L",
    description: "Painel digital 8 funções, cesto antiaderente.",
    price: 299.9,
    oldPrice: 499.9,
    tag: "MAIS VENDIDO",
    image: airFryer,
  },
  {
    name: "Aspirador Robô Inteligente",
    description: "Mapeamento a laser, app, 120min de bateria.",
    price: 899.9,
    oldPrice: 1499.9,
    tag: "PREMIUM",
    image: aspiradorRobo,
  },
  {
    name: "Secador Profissional 2000W",
    description: "Íons negativos, 3 temperaturas, difusor incluso.",
    price: 179.9,
    oldPrice: 329.9,
    image: secador,
  },
  {
    name: "Prancha Chapinha Cerâmica 230°C",
    description: "Aquecimento 30s, nano titânio, cabelo brilhoso.",
    price: 99.9,
    oldPrice: 199.9,
    image: chapinha,
  },
];

// ---------------- SUPPLIER 3: Kitchen ----------------
const cozinhaItems: Item[] = [
  {
    name: "Panela Elétrica de Arroz 1,8L",
    description: "Cozinha até 10 xícaras, função aquecer, antiaderente.",
    price: 139.9,
    oldPrice: 229.9,
    image: panelaArroz,
  },
  {
    name: "Liquidificador 1200W 12 velocidades",
    description: "Jarra 2L, lâminas inox para gelo.",
    price: 189.9,
    oldPrice: 349.9,
    image: liquidificador,
  },
  {
    name: "Cafeteira Espresso Inox 15 bar",
    description: "Vaporizador de leite, reservatório 1,5L.",
    price: 499.9,
    oldPrice: 899.9,
    tag: "TOP",
    image: cafeteira,
  },
  {
    name: "Sanduicheira Grill Antiaderente 750W",
    description: "Prepara sanduíches e mini grelhados rapidamente.",
    price: 89.9,
    oldPrice: 149.9,
    image: sanduicheira,
  },
  {
    name: "Garrafa Térmica Inox 1L",
    description: "Mantém temperatura por 24h, aço inox, sem BPA.",
    price: 44.9,
    oldPrice: 79.9,
    image: garrafaTermica,
  },
  {
    name: "Jogo de Facas 6 Peças Inox",
    description: "Cabo ergonômico, base de madeira inclusa.",
    price: 129.9,
    oldPrice: 259.9,
    tag: "COZINHA",
    image: jogoFacas,
  },
  {
    name: "Tábua de Corte Bambu Grande",
    description: "35x25cm, sustentável, sulco para líquidos.",
    price: 39.9,
    oldPrice: 79.9,
    image: tabuaCorte,
  },
];

// ---------------- SUPPLIER 4: Diversos ----------------
const diversosItems: Item[] = [
  {
    name: "Urso de Pelúcia 40cm Fofinho",
    description: "Ideal para presente, laço de cetim, macio.",
    price: 39.9,
    oldPrice: 79.9,
    tag: "PRESENTE",
    image: brinquedoPelucia,
  },
  {
    name: "Quadro Decorativo Sala 60x40cm",
    description: "Arte moderna abstrata, moldura MDF preta.",
    price: 89.9,
    oldPrice: 179.9,
    image: quadroDecorativo,
  },
  {
    name: "Tênis Esportivo para Corrida",
    description: "Amortecimento EVA, mesh respirável.",
    price: 199.9,
    oldPrice: 379.9,
    tag: "TOP",
    image: tenis,
  },
  {
    name: 'Mochila Anti-Furto Notebook 15"',
    description: "USB, impermeável, tecido resistente.",
    price: 139.9,
    oldPrice: 259.9,
    image: mochila,
  },
  {
    name: "Óculos de Sol Polarizado UV400",
    description: "Armação leve em metal, lentes com proteção UV.",
    price: 79.9,
    oldPrice: 169.9,
    image: oculos,
  },
  {
    name: "Carteira Slim de Couro RFID",
    description: "Ultrafina, 8 compartimentos, bloqueio RFID.",
    price: 59.9,
    oldPrice: 119.9,
    image: carteira,
  },
  {
    name: "Perfume Black Masculino 100ml",
    description: "Fragrância amadeirada, alta fixação.",
    price: 129.9,
    oldPrice: 249.9,
    image: perfume,
  },
  {
    name: "Kit Skincare Facial Completo",
    description: "Sérum Vit C, hidratante e ácido hialurônico.",
    price: 149.9,
    oldPrice: 289.9,
    image: skincare,
  },
];

const cosmeticosItems: Item[] = [
  {
    name: "Kit Body Splash Obsession",
    description:
      "Fragrâncias irresistíveis The Lirios e Obsession de 200ml cada. Frescor, elegância e alta fixação de perfume de alta qualidade.",
    price: 139.9,
    oldPrice: 199.9,
    tag: "LANÇAMENTO",
    image: kitBodySplashVirginia,
    sold: 35000,
    rating: 4.9,
  },
  {
    name: "Perfume Árabe Asad",
    description:
      "O perfume masculino mais desejado do momento. Notas marcantes de especiarias pretas, âmbar e patchouli.",
    price: 229.9,
    oldPrice: 329.9,
    tag: "RECOMENDADO",
    image:
      "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcS7fECEz-EQa3UTV4GwuGtXMSW-TUDKy2f9hF-M-tooplPb92sLxz_F0KE_gLgVQnHm13D8QaKUN_H9wz7dtQojK1FcMFwIBYPugRd-oaBLNe5R9Pf4ey3DBr8GdVlUMqRUXfDoYyc&usqp=CAc",
    sold: 32000,
    rating: 4.8,
  },
  {
    name: "Body Splash VF Wepink - Virginia Fonseca 200ml",
    description:
      "O famoso Body Splash com fragrância doce, sofisticada e marcante de Virginia Fonseca. Perfeito para o dia a dia, com alto frescor.",
    price: 69.9,
    oldPrice: 119.9,
    tag: "MAIS VENDIDO",
    image: "https://http2.mlstatic.com/D_Q_NP_964488-MLU77077188860_062024-O.webp",
    sold: 19450,
    rating: 4.9,
  },
  {
    name: "Sérum Facial 10 em 1 Wepink",
    description:
      "Sérum multifuncional com Ácido Hialurônico, Retinol e Vitamina C. Reduz linhas de expressão e uniformiza o tom da pele.",
    price: 99.9,
    oldPrice: 149.9,
    tag: "PROMOÇÃO",
    image: skincare,
    sold: 9840,
    rating: 4.8,
  },
  {
    name: "Perfume Liberté Wepink 100ml",
    description:
      "Fragrância floral oriental envolvente e misteriosa. Altíssima projeção e fixação de mais de 12 horas.",
    price: 159.9,
    oldPrice: 229.9,
    tag: "PREMIUM",
    image: perfume,
    sold: 8320,
    rating: 4.9,
  },
  {
    name: "Base Líquida Wepink Virginia Fonseca",
    description:
      "Alta cobertura, resistente à água, acabamento matte aveludado com ativos de skincare que cuidam da pele.",
    price: 79.9,
    oldPrice: 129.9,
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQc0aUX7k_3_9JTsbSqOCmd3LiOAGPmzupblk4uTHiGfm8kjF1a4s_8DFo&s=10",
    sold: 14300,
    rating: 4.7,
  },
  {
    name: "Perfume Arabe Asad Bourbon",
    description:
      "Fragrância luxuosa oriental com notas ricas de baunilha, especiarias e acordes quentes amadeirados. Alta fixação e projeção marcante.",
    price: 249.9,
    oldPrice: 349.9,
    tag: "MAIS VENDIDO",
    image:
      "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcR7C37x0-3pfh-31s8cIwbfyjLqmM4LQ-iIJmWDKD1GxAG2ucbn_QLTViAWK4EySYexiTk8-EV5rYScXFYNwNa-OwXIPsV0z3E-1NqSl_gQr8Uf7M4ED9vrC5yqZUXHZSr-3alu0GF1enU&usqp=CAc",
    sold: 12400,
    rating: 4.9,
  },
  {
    name: "Perfume Arabe FAKHAR GOLD EXTRAIT LATTAFA- 100ml MASCULINO",
    description:
      "O auge da perfumaria árabe. Uma fusão sofisticada de ouro e fragrância amadeirada com especiarias preciosas.",
    price: 269.9,
    oldPrice: 379.9,
    image:
      "https://cdn.awsli.com.br/600x450/2627/2627445/produto/287027131/331143b56712c1ef2206395597fb71d2-dyjnhl1cx6.jpg",
    sold: 9800,
    rating: 4.9,
  },
  {
    name: "Lip Gloss Volumoso Wepink - Efeito Plump",
    description:
      "Brilho espelhado que aumenta visivelmente o volume dos lábios em segundos, com hidratação intensa e duradoura.",
    price: 45.9,
    oldPrice: 69.9,
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsv7TEHVyBwgNrZ7r1YL4bBfOSeIcP2BSUDBd3HjOv_yqwSArGjjgjmeU&s=10",
    sold: 11400,
    rating: 4.8,
  },
  {
    name: "Boticario - Her Code - Touch - Eau de Parfum Feminino 50Ml",
    description:
      "Fragrância feminina sensual e misteriosa com um toque amadeirado frutal irresistível.",
    price: 189.9,
    oldPrice: 239.9,
    image:
      "https://static.wixstatic.com/media/295529_0627be63cb594988b4c6bc318db4f32e~mv2.jpg/v1/fill/w_480,h_480,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/295529_0627be63cb594988b4c6bc318db4f32e~mv2.jpg",
    sold: 7300,
    rating: 4.7,
  },
  {
    name: "Perfume Árabe Yara Lattafa Feminino 100ml",
    description:
      "Uma fragrância doce viciante e sofisticada, com notas de baunilha, tangerina, sândalo e acordes gourmand elegantes.",
    price: 259.9,
    oldPrice: 349.9,
    tag: "VIRAL NO TIKTOK",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNBnpjX0Zf8GWUeVjIAoAGdLvxBS25h_5lRslPcJXZIw&s=10",
    sold: 22400,
    rating: 4.9,
  },
  {
    name: "Coffee Woman Duo Desodorante Colônia 100ml",
    description:
      "A mistura perfeita entre a força do café e a cremosidade do leite, criando um aroma sensual e envolvente.",
    price: 169.9,
    oldPrice: 209.9,
    image:
      "https://images.tcdn.com.br/img/img_prod/548128/coffee_woman_duo_colonia_100ml_o_boticario_750_1_9998d47b86fc32693aacb2c682c5652e.jpg",
    sold: 11400,
    rating: 4.8,
  },
  {
    name: "Cuide-Se Bem Deleite Body Splash, 200ml",
    description:
      "Fragrância doce e aconchegante inspirada no aroma suave do leite. Delicioso e refrescante para pós-banho.",
    price: 69.9,
    oldPrice: 89.9,
    image:
      "https://images.tcdn.com.br/img/img_prod/548128/cuide_se_bem_colonia_body_splash_da_perfumaria_o_boticario_338_1_6dffd4441a92ac72742e33855bfb3d18.jpg",
    sold: 18700,
    rating: 4.9,
  },
  {
    name: "Kit Skincare Facial Premium",
    description:
      "Sérum Hidratante Concentrado, sabonete facial antioxidante e tônico revitalizador.",
    price: 119.9,
    oldPrice: 179.9,
    tag: "RECOMENDADO",
    image: skincare,
    sold: 8430,
    rating: 4.8,
  },
  {
    name: "Perfume Red Seduction 100ml",
    description: "Perfume importado marcante com notas florais elegantes, alta fixação.",
    price: 149.9,
    oldPrice: 249.9,
    image: perfume,
    sold: 6210,
    rating: 4.7,
  },
  {
    name: "Óleo Capilar Reparador Sublime Wepink 60ml",
    description:
      "Nutrição profunda, brilho intenso e controle completo do frizz sem pegar os cabelos. Fragrância de salão.",
    price: 59.9,
    oldPrice: 89.9,
    image:
      "https://wepink.vtexassets.com/arquivos/ids/163686-800-800?v=639063173486500000&width=800&height=800&aspect=true",
    sold: 9300,
    rating: 4.8,
  },
  {
    name: "Malbec Masculino",
    description:
      "O clássico amadeirado de O Boticário inspirado no universo dos vinhos. Marcante, magnético e sofisticado.",
    price: 179.9,
    oldPrice: 219.9,
    image:
      "https://images.tcdn.com.br/img/img_prod/548128/malbec_magnetic_colonia_masculina_100ml_o_boticario_726_1_2ca33ec1622f2a02c8e036584057d403.jpg",
    sold: 13500,
    rating: 4.8,
  },
  {
    name: "Kaiak Colônia Masculino 100 ml Natura",
    description:
      "A fragrância clássica da Natura com frescor aquático vibrante e notas cítricas. Perfeito para o dia a dia.",
    price: 124.9,
    oldPrice: 169.9,
    image: "https://m.media-amazon.com/images/I/51sUHxUvC0L.jpg",
    sold: 12000,
    rating: 4.7,
  },
];

export const SUPPLIERS: Supplier[] = [
  {
    id: "techmaster-brasil",
    name: "Innova Partners - SP",
    tagline: "Eletrônicos e eletrodomésticos de ponta",
    category: "Eletrônicos",
    productCount: "+5000",
    cover: smartwatch,
    products: build("tech", eletroItems),
  },
  {
    id: "glow-cosmeticos",
    name: "Glow Cosméticos - PR",
    tagline: "Perfumes, maquiagens e produtos de beleza",
    category: "Cosméticos",
    productCount: "+1200",
    cover: kitBodySplashVirginia,
    products: build("cosmeticos", cosmeticosItems),
  },
  {
    id: "encantos-do-ano",
    name: "Vantaggio Supply - MG",
    tagline: "Ofertas sazonais para todas as datas",
    category: "Sazonais",
    productCount: "+3000",
    cover: arvoreNatal,
    products: build("encantos", sazonaisItems),
  },
  {
    id: "achadinhos-express",
    name: "Selecta Importadora - SP",
    tagline: "Utilidades e achadinhos para o dia a dia",
    category: "Utilidades",
    productCount: "+2500",
    cover: brinquedoPelucia,
    products: build("achadinhos", diversosItems),
  },
  {
    id: "casa-e-sabor",
    name: "CozDrop - RJ",
    tagline: "Cozinha, utensílios e praticidade",
    category: "Cozinha",
    productCount: "+900",
    cover: cafeteira,
    products: build("cozinha", cozinhaItems),
  },
];

export function getSupplier(id: string): Supplier | undefined {
  return SUPPLIERS.find((s) => s.id === id);
}

export function getProductVariations(p: { name: string; id: string }): string[] {
  const name = p.name.toLowerCase();

  if (name.includes("obsession")) {
    return ["Kit Completo", "Fragrância The Lirios", "Fragrância Obsession"];
  }
  if (name.includes("ovo de páscoa") || name.includes("pascoa")) {
    return ["Chocolate ao Leite", "Ninho com Nutella", "Meio Amargo"];
  }
  if (name.includes("árvore de natal") || name.includes("arvore")) {
    return ["Verde Tradicional", "Nevada (Branca)", "Com LED Integrado"];
  }
  if (name.includes("pisca-pisca") || name.includes("led")) {
    if (name.includes("fita") || name.includes("lâmpada") || name.includes("luz")) {
      return ["Branco Quente", "Colorido (RGB)", "Branco Frio"];
    }
  }
  if (name.includes("fone") || name.includes("headset") || name.includes("tws")) {
    return ["Preto Fosco", "Branco Clássico", "Azul Metálico"];
  }
  if (name.includes("smartwatch") || name.includes("relógio") || name.includes("relogio")) {
    return ["Preto Absoluto", "Prata Metálico", "Rose Gold"];
  }
  if (name.includes("mouse")) {
    return ["Preto Gamer", "Branco Neve", "Rosa Quartz"];
  }
  if (name.includes("caixa de som") || name.includes("som")) {
    return ["Preto Carbono", "Vermelho Rubi", "Azul Imperial"];
  }
  if (name.includes("cabo")) {
    return ["Preto Trançado 3m", "Cinza Metálico 3m", "Vermelho Turbo 3m"];
  }
  if (name.includes("carregador")) {
    return ["Preto Premium", "Branco Slim"];
  }
  if (name.includes("suporte")) {
    return ["Fixação Difusor de Ar", "Fixação Painel Ventosa"];
  }
  if (name.includes("câmera") || name.includes("camera")) {
    return ["Padrão 1 Unidade", "Kit 2 Câmeras Monitoramento", "Kit 4 Câmeras Completo"];
  }
  if (name.includes("teclado")) {
    return ["Switch Azul (Clicky)", "Switch Vermelho (Linear)", "Switch Marrom (Tátil)"];
  }
  if (name.includes("webcam")) {
    return ["Full HD 1080p Standard", "Ultra HD 4K Pro Streaming"];
  }
  if (name.includes("air fryer") || name.includes("fritadeira")) {
    return ["Preto Piano 110V", "Preto Piano 220V", "Vermelho Retrô 110V", "Vermelho Retrô 220V"];
  }
  if (name.includes("aspirador")) {
    return ["Branco Minimalista", "Preto Piano"];
  }
  if (name.includes("secador")) {
    return ["Preto Profissional 110V", "Preto Profissional 220V", "Rosa Pink 110V"];
  }
  if (name.includes("chapinha") || name.includes("prancha")) {
    return ["Preto Titanium (Bivolt)", "Rose Gold Cerâmica (Bivolt)"];
  }
  if (name.includes("panela")) {
    return ["Inox Premium 110V", "Inox Premium 220V", "Branca Clássica 110V"];
  }
  if (name.includes("liquidificador")) {
    return ["Preto Turbo 110V", "Preto Turbo 220V", "Vermelho Potência 110V"];
  }
  if (name.includes("cafeteira")) {
    return ["Inox Escovado 110V", "Inox Escovado 220V"];
  }
  if (name.includes("sanduicheira")) {
    return ["Preta Grill 110V", "Preta Grill 220V"];
  }
  if (name.includes("garrafa")) {
    return ["Aço Inox", "Preto Fosco", "Azul Cobalto"];
  }
  if (name.includes("faca") || name.includes("jogo de facas")) {
    return ["Cabo Preto Soft-Touch", "Cabo Clássico em Madeira"];
  }
  if (name.includes("tábua") || name.includes("tabua")) {
    return ["Média 30x20cm", "Grande 35x25cm"];
  }
  if (name.includes("urso") || name.includes("pelúcia") || name.includes("brinquedo")) {
    return ["Marrom Clássico", "Creme Suave", "Rosa Bebê"];
  }
  if (name.includes("quadro")) {
    return ["Moldura Preta 60x40", "Moldura Branca 60x40", "Sem Moldura (Borda Infinita)"];
  }
  if (name.includes("tênis") || name.includes("tenis")) {
    return [
      "Preto Esportivo (Tamanhos 38-43)",
      "Azul Marinho (Tamanhos 38-43)",
      "Rosa Quartz (Tamanhos 35-39)",
    ];
  }
  if (name.includes("mochila")) {
    return ["Preto Executivo", "Cinza Urbano", "Azul Escuro"];
  }
  if (name.includes("óculos") || name.includes("oculos")) {
    return ["Lente Negra / Armação Preta", "Lente Marrom / Armação Dourada"];
  }
  if (name.includes("carteira")) {
    return ["Couro Preto Legítimo", "Couro Pinhão Vintage", "Couro Café Elegante"];
  }
  if (name.includes("perfume")) {
    if (name.includes("asad")) {
      return ["Asad Tradicional", "Asad Bourbon", "Asad Royale"];
    }
    if (name.includes("liberté") || name.includes("liberte")) {
      return ["Liberté Tradicional", "Liberté Nuit"];
    }
    return ["Fragrância Clássica", "Fragrância Intense", "Fragrância Sport"];
  }
  if (name.includes("skincare")) {
    return ["Kit Pele Oleosa/Acneica", "Kit Pele Seca/Sensível", "Kit Pele Mista"];
  }
  if (name.includes("body splash")) {
    if (name.includes("deleite")) {
      return ["Deleite Body Splash 200ml", "Deleite Loção Hidratante 400ml"];
    }
    return ["Fragrância Soft", "Fragrância Intensa", "Fragrância Doce"];
  }
  if (name.includes("sérum") || name.includes("serum")) {
    return ["Sérum 10 em 1 Antissinais", "Sérum Hidratante Hialurônico"];
  }
  if (name.includes("base")) {
    return ["Tom 100 Clarinho", "Tom 120 Claro Médio", "Tom 140 Médio", "Tom 160 Escuro"];
  }
  if (name.includes("lip gloss") || name.includes("gloss")) {
    return ["Incolor Efeito Vidro", "Rosa Delicado", "Nude Brilho"];
  }
  if (name.includes("óleo") || name.includes("oleo")) {
    return ["Óleo Reparador 60ml", "Óleo Reparador Pocket 30ml"];
  }
  if (name.includes("malbec")) {
    return ["Malbec Tradicional 100ml", "Malbec Magnetic 100ml", "Malbec Gold 100ml"];
  }
  if (name.includes("kaiak")) {
    return ["Kaiak Clássico 100ml", "Kaiak Urbe 100ml", "Kaiak Oceano 100ml"];
  }

  // Fallbacks by category/ID keywords
  if (name.includes("amor") || name.includes("namorados") || name.includes("presente")) {
    return ["Cesta de Chocolates", "Cesta de Flores", "Kit Espumante Premium"];
  }
  if (name.includes("halloween")) {
    return ["Laranja Clássico", "Roxo Neon"];
  }
  if (name.includes("bandeira")) {
    return ["Bandeira Oficial 1.50m", "Bandeira de Carro"];
  }

  // General fallback variations
  return ["Modelo Padrão", "Edição Limitada Premium"];
}
