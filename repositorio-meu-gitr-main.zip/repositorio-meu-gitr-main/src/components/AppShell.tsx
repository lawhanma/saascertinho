import { useEffect, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { useAuthUser } from "@/lib/authStore";

export function AppShell({ children }: { children: ReactNode }) {
  const { user, ready } = useAuthUser();
  const navigate = useNavigate();

  useEffect(() => {
    if (ready && !user) navigate({ to: "/login" });
  }, [ready, user, navigate]);

  if (!ready || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-sm text-muted-foreground">Carregando...</div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <div className="sticky top-0 z-40 flex h-12 items-center gap-2 border-b border-border bg-background/80 px-3 backdrop-blur-md">
            <SidebarTrigger />
            <span className="text-xs font-black uppercase tracking-widest text-foreground">
              ΛPEX <span className="font-light text-amber-500">SHOP</span>
            </span>
          </div>
          <main className="flex-1">{children}</main>
        </div>
        <a
          href="https://wa.me/5524981252504"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Falar no WhatsApp (24) 98125-2504"
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-white shadow-lg transition-transform hover:scale-105 hover:bg-[#22c55e]"
        >
          <svg viewBox="0 0 32 32" className="h-6 w-6 fill-current" aria-hidden="true">
            <path d="M19.11 17.29c-.28-.14-1.65-.81-1.9-.9-.26-.09-.44-.14-.63.14-.19.28-.72.9-.88 1.09-.16.19-.32.21-.6.07-.28-.14-1.17-.43-2.23-1.38-.82-.73-1.38-1.63-1.54-1.91-.16-.28-.02-.43.12-.57.13-.13.28-.32.42-.49.14-.16.19-.28.28-.47.09-.19.05-.35-.02-.49-.07-.14-.63-1.52-.86-2.08-.23-.55-.46-.48-.63-.49h-.54c-.19 0-.49.07-.75.35-.26.28-.98.96-.98 2.34s1 2.72 1.14 2.91c.14.19 1.97 3 4.77 4.21.67.29 1.19.46 1.6.59.67.21 1.28.18 1.76.11.54-.08 1.65-.67 1.88-1.32.23-.65.23-1.2.16-1.32-.07-.12-.26-.19-.54-.33zM16 3C8.82 3 3 8.82 3 16c0 2.28.6 4.42 1.65 6.29L3 29l6.87-1.8A12.94 12.94 0 0016 29c7.18 0 13-5.82 13-13S23.18 3 16 3zm0 23.5c-2.03 0-3.92-.6-5.5-1.63l-.39-.24-4.08 1.07 1.09-3.97-.26-.41A10.47 10.47 0 015.5 16C5.5 10.2 10.2 5.5 16 5.5S26.5 10.2 26.5 16 21.8 26.5 16 26.5z" />
          </svg>
        </a>
      </div>
    </SidebarProvider>
  );
}
