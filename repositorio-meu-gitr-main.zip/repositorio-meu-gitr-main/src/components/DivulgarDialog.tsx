import { useEffect, useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { Product } from "@/data/products";
import { CheckCircle2, Loader2, Megaphone, Rocket, Sparkles, TrendingUp } from "lucide-react";
import { addDivulgacao, formatBRL } from "@/lib/salesStore";

type Stage = {
  label: string;
  detail: string;
};

const STAGES: Stage[] = [
  { label: "Conectando à Shopee", detail: "Autenticando conta de vendedor..." },
  {
    label: "IA otimizando título e SEO",
    detail: "Aplicando palavras-chave de alto volume com IA...",
  },
  { label: "Divulgação em massa no Instagram", detail: "IA postando em Stories, Feed e Reels..." },
  { label: "Divulgação em massa no TikTok", detail: "IA gerando vídeos e hashtags virais..." },
  {
    label: "Divulgação em massa no Facebook",
    detail: "IA ativando anúncios em grupos segmentados...",
  },
  {
    label: "Disparo em massa no WhatsApp",
    detail: "IA enviando para milhares de listas de transmissão...",
  },
  { label: "Divulgação em massa no Kwai", detail: "IA publicando anúncios nativos em escala..." },
  {
    label: "Impulsionando dentro da Shopee",
    detail: "IA ativando destaque na busca e categoria...",
  },
  {
    label: "Disparo em massa no Telegram",
    detail: "IA postando em centenas de canais de ofertas...",
  },
  {
    label: "Divulgação em massa concluída!",
    detail: "Seu produto foi divulgado em todas as plataformas.",
  },
];

type Phase = "confirm" | "running" | "done";

export function DivulgarDialog({
  product,
  open,
  onOpenChange,
}: {
  product: Product | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [phase, setPhase] = useState<Phase>("confirm");
  const [stepIdx, setStepIdx] = useState(0);
  const [completed, setCompleted] = useState<number[]>([]);
  const timerRef = useRef<number | null>(null);
  const [earned, setEarned] = useState<number>(0);

  useEffect(() => {
    if (!open) {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      setPhase("confirm");
      setStepIdx(0);
      setCompleted([]);
      setEarned(0);
    }
  }, [open]);

  useEffect(() => {
    if (phase !== "running") return;
    if (stepIdx >= STAGES.length) {
      setPhase("done");
      return;
    }
    timerRef.current = window.setTimeout(() => {
      setCompleted((c) => [...c, stepIdx]);
      setStepIdx((i) => i + 1);
    }, 2100);
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [phase, stepIdx]);

  const progress = Math.round((completed.length / STAGES.length) * 100);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        {phase === "confirm" && product && (
          <>
            <DialogHeader>
              <div className="mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                <Megaphone className="h-7 w-7 text-primary" />
              </div>
              <DialogTitle className="text-center text-2xl">Divulgar {product.name}</DialogTitle>
              <DialogDescription className="text-center text-base leading-relaxed">
                Nossa <span className="font-semibold text-primary">IA</span> vai fazer a divulgação{" "}
                <span className="font-semibold text-foreground">em massa</span> desse produto em{" "}
                <span className="font-semibold text-foreground">todas as redes sociais</span> e
                dentro da própria <span className="font-semibold text-foreground">Shopee</span>!
                <br />
                <span className="mt-2 inline-flex items-center gap-1 font-semibold text-primary">
                  <TrendingUp className="h-4 w-4" /> Expectativa de muitas vendas
                </span>
              </DialogDescription>
            </DialogHeader>
            <div className="mt-2 flex flex-col gap-2">
              <Button
                size="lg"
                className="w-full text-base font-semibold"
                onClick={() => {
                  const r = addDivulgacao();
                  setEarned(r.increment);
                  setPhase("running");
                }}
              >
                <Rocket className="mr-2 h-5 w-5" />
                DIVULGAR AGORA
              </Button>
              <Button variant="ghost" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
            </div>
          </>
        )}

        {phase === "running" && product && (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                IA divulgando em massa "{product.name}"
              </DialogTitle>
              <DialogDescription>
                Nossa IA está fazendo a divulgação em massa — não feche esta janela.
              </DialogDescription>
            </DialogHeader>

            <div className="mt-2">
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="font-medium text-foreground">Progresso</span>
                <span className="font-semibold text-primary">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            <ul className="mt-4 max-h-72 space-y-2 overflow-y-auto pr-1">
              {STAGES.map((s, i) => {
                const done = completed.includes(i);
                const active = i === stepIdx;
                return (
                  <li
                    key={s.label}
                    className={`flex items-start gap-3 rounded-lg border p-3 transition-all ${
                      active
                        ? "border-primary/40 bg-primary/5"
                        : done
                          ? "border-border bg-secondary/40"
                          : "border-border/60 bg-background opacity-60"
                    }`}
                  >
                    <div className="mt-0.5">
                      {done ? (
                        <CheckCircle2
                          className="h-5 w-5 text-[oklch(var(--success))]"
                          style={{ color: "oklch(0.65 0.17 150)" }}
                        />
                      ) : active ? (
                        <Loader2 className="h-5 w-5 animate-spin text-primary" />
                      ) : (
                        <div className="h-5 w-5 rounded-full border-2 border-border" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-foreground">{s.label}</div>
                      <div className="text-xs text-muted-foreground">{s.detail}</div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}

        {phase === "done" && product && (
          <>
            <DialogHeader>
              <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <DialogTitle className="text-center text-2xl">Divulgação concluída!</DialogTitle>
              <DialogDescription className="text-center text-base">
                "{product.name}" foi divulgado com sucesso em <strong>9 canais</strong>.
                <br />
                Prepare-se para uma{" "}
                <span className="font-semibold text-primary">enxurrada de vendas</span>.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-3 rounded-xl border border-primary/30 bg-primary/5 p-4 text-center">
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Saldo adicionado
              </div>
              <div className="mt-1 text-3xl font-black text-primary">+ R$ {formatBRL(earned)}</div>
            </div>
            <div className="mt-2 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-lg bg-secondary p-3">
                <div className="text-xl font-bold text-primary">+320%</div>
                <div className="text-xs text-muted-foreground">Alcance</div>
              </div>
              <div className="rounded-lg bg-secondary p-3">
                <div className="text-xl font-bold text-primary">9</div>
                <div className="text-xs text-muted-foreground">Canais</div>
              </div>
              <div className="rounded-lg bg-secondary p-3">
                <div className="text-xl font-bold text-primary">24h</div>
                <div className="text-xs text-muted-foreground">Impulso ativo</div>
              </div>
            </div>
            <Button size="lg" className="mt-4 w-full" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
