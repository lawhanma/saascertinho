import { ReactNode } from "react";

interface ApexShopLogoProps {
  collapsed?: boolean;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function ApexShopLogo({
  collapsed = false,
  className = "",
  size = "md",
}: ApexShopLogoProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-16 w-16",
  };

  const textSizes = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl",
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Shopee-themed logo icon with shopping bag + stylized A */}
      <svg
        viewBox="0 0 100 100"
        className={`${sizeClasses[size]} shrink-0 select-none drop-shadow-[0_4px_12px_rgba(238,77,45,0.35)]`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Shopee Vibrant Orange Gradient */}
          <linearGradient id="apexShopeeGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FF8E42" />
            <stop offset="50%" stopColor="#EE4D2D" />
            <stop offset="100%" stopColor="#C42D15" />
          </linearGradient>

          {/* Shopee glow/shadow filter for a sophisticated depth effect */}
          <filter id="shopeeGlow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow
              dx="0"
              dy="2"
              stdDeviation="2.5"
              floodColor="#EE4D2D"
              floodOpacity="0.4"
            />
          </filter>
        </defs>

        {/* 1. Shopping Bag Handle Outline */}
        <path
          d="M 32,45 L 28,26 L 40,26 C 40,13 60,13 60,26 L 72,26 L 68,45"
          fill="none"
          stroke="url(#apexShopeeGrad)"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* 2. Central Stylized "A" */}
        {/* Right leg and apex */}
        <path
          d="M 50,15 L 81,80 L 67,80 L 53,49 L 45,49 L 49,38 Z"
          fill="url(#apexShopeeGrad)"
          filter="url(#shopeeGlow)"
        />

        {/* Left leg bottom segment */}
        <path
          d="M 40,43 L 31,63 L 19,80 L 33,80 L 45,53 Z"
          fill="url(#apexShopeeGrad)"
          filter="url(#shopeeGlow)"
        />

        {/* The elegant hook / crossbar */}
        <path
          d="M 51,52 L 35,52 L 40,63 L 45,63 L 43,57 L 50,57 Z"
          fill="url(#apexShopeeGrad)"
          filter="url(#shopeeGlow)"
        />
      </svg>

      {/* Elegant APEX SHOP custom text */}
      {!collapsed && (
        <div className="flex items-baseline font-sans uppercase select-none tracking-wider">
          <span
            className={`${textSizes[size]} font-black text-foreground tracking-[0.05em] leading-none`}
          >
            ΛPEX
          </span>
          <span
            className={`${textSizes[size]} font-light tracking-[0.25em] ml-2 leading-none`}
            style={{
              backgroundImage: "linear-gradient(135deg, #FF8E42 0%, #EE4D2D 50%, #C42D15 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            SHOP
          </span>
        </div>
      )}
    </div>
  );
}
