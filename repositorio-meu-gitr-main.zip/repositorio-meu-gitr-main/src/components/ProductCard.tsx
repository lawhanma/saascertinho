import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Product } from "@/data/suppliers";
import { Flame, Sparkles, Star } from "lucide-react";

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function ProductCard({
  product,
  onGenerate,
  rank,
}: {
  product: Product;
  onGenerate: (p: Product) => void;
  rank?: number;
}) {
  const discount = product.oldPrice ? Math.round((1 - product.price / product.oldPrice) * 100) : 0;

  return (
    <div
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1"
      style={{ boxShadow: "var(--shadow-card)" }}
    >
      <div className="relative aspect-square overflow-hidden bg-secondary">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={1024}
          height={1024}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {rank && (
          <div className="absolute left-3 top-3 z-10">
            {rank === 1 ? (
              <Badge className="border-0 bg-gradient-to-r from-amber-500 via-yellow-400 to-orange-500 text-black font-black shadow-lg shadow-yellow-500/20 px-2.5 py-1">
                🏆 TOP 1
              </Badge>
            ) : rank === 2 ? (
              <Badge className="border-0 bg-gradient-to-r from-slate-300 to-slate-100 text-black font-black shadow-lg px-2.5 py-1">
                🥈 TOP 2
              </Badge>
            ) : rank === 3 ? (
              <Badge className="border-0 bg-gradient-to-r from-amber-700 to-amber-600 text-white font-black shadow-lg px-2.5 py-1">
                🥉 TOP 3
              </Badge>
            ) : (
              <Badge
                variant="secondary"
                className="bg-background/95 backdrop-blur-sm border border-border text-foreground font-black px-2 py-1"
              >
                📈 TOP {rank}
              </Badge>
            )}
          </div>
        )}
        {product.tag && (
          <Badge
            className={`absolute left-3 ${rank ? "bottom-3" : "top-3"} border-0 bg-primary/90 text-primary-foreground shadow-md`}
          >
            <Flame className="mr-1 h-3 w-3" /> {product.tag}
          </Badge>
        )}
        {discount > 0 && (
          <div className="absolute right-3 top-3 rounded-full bg-foreground/90 px-2 py-1 text-xs font-bold text-background">
            -{discount}%
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <h3 className="line-clamp-2 text-sm font-semibold leading-snug text-foreground">
          {product.name}
        </h3>
        <p className="line-clamp-2 text-xs text-muted-foreground">{product.description}</p>

        <div className="mt-auto space-y-2">
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-primary">{brl(product.price)}</span>
            {product.oldPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {brl(product.oldPrice)}
              </span>
            )}
          </div>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Star className="h-3.5 w-3.5 fill-primary text-primary" />
              <strong className="text-foreground">{product.rating.toFixed(1)}</strong>
            </span>
            <span>{product.sold.toLocaleString("pt-BR")} vendidos</span>
          </div>

          <Button
            className="w-full font-bold tracking-wide transition-all group-hover:bg-primary group-hover:text-primary-foreground"
            size="lg"
            onClick={() => onGenerate(product)}
          >
            <Sparkles className="mr-2 h-4 w-4" />
            VER PRODUTO
          </Button>
        </div>
      </div>
    </div>
  );
}
