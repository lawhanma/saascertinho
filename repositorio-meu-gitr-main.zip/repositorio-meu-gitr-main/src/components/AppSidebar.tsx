import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Package,
  User,
  LogOut,
  ShoppingBag,
  Sparkles,
  Video,
  Link2,
  DollarSign,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { signOut, useAuthUser } from "@/lib/authStore";
import { ApexShopLogo } from "./ApexShopLogo";

const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Financeiro", url: "/financeiro", icon: DollarSign },
  { title: "Catálogo", url: "/", icon: Package },
  { title: "Divulgação com IA", url: "/divulgacao-ia", icon: Sparkles },
  { title: "Gerar Vídeos com IA", url: "/video-ia", icon: Video },
  { title: "Integração da conta Shopee", url: "/conectar", icon: Link2 },
  { title: "Perfil", url: "/perfil", icon: User },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const currentPath = useRouterState({ select: (r) => r.location.pathname });
  const navigate = useNavigate();
  const { user } = useAuthUser();

  const handleLogout = () => {
    signOut();
    navigate({ to: "/login" });
  };
  const displayName = user || "Usuário";
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/" className="flex items-center px-1 py-2">
          <ApexShopLogo collapsed={collapsed} />
        </Link>
      </SidebarHeader>

      <SidebarContent className="pt-4">
        <SidebarMenu className="px-2 gap-1">
          {items.map((item) => {
            const active = currentPath === item.url;
            return (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton
                  asChild
                  isActive={active}
                  className={`h-11 rounded-lg font-semibold ${
                    active
                      ? "bg-[oklch(0.96_0.05_50)] text-primary hover:bg-[oklch(0.96_0.05_50)] hover:text-primary"
                      : "text-foreground/70"
                  }`}
                >
                  <Link to={item.url} className="flex items-center gap-3 px-3">
                    <item.icon className="h-5 w-5" />
                    <span>{item.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border gap-3">
        {!collapsed && (
          <div className="flex items-center gap-2 px-2 py-2">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
              {initials}
            </div>
            <div className="min-w-0 leading-tight">
              <div className="text-sm font-semibold truncate">{displayName}</div>
              <div className="text-[11px] text-muted-foreground truncate">Conectado</div>
            </div>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
        >
          <LogOut className="h-5 w-5" />
          {!collapsed && <span>Sair</span>}
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}
