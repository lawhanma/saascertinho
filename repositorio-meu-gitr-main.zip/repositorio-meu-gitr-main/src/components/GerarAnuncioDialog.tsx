import { useEffect, useMemo, useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  Sparkles,
  Download,
  Copy,
  Check,
  Loader2,
  Megaphone,
  CheckCircle2,
  TrendingUp,
  Facebook,
  ExternalLink,
  ShieldCheck,
  Link2,
  Users,
  Target,
  Percent,
  Gauge,
  ShoppingBag,
  Award,
  BarChart3,
  DollarSign,
} from "lucide-react";
import type { Product } from "@/data/suppliers";
import { addCommission, formatBRL } from "@/lib/salesStore";
import { toast } from "sonner";

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const FACEBOOK_GROUPS = [
  {
    name: "Achadinhos da Shopee & Afiliados",
    url: "https://www.facebook.com/groups/2575783226147099",
  },
  {
    name: "Grupo de Ofertas & Cupons Shopee",
    url: "https://www.facebook.com/groups/1037146820653059",
  },
  {
    name: "Afiliados Shopee Brasil - Dicas e Vendas",
    url: "https://www.facebook.com/groups/1882403215702590",
  },
  {
    name: "Achados Incríveis Shopee & Aliexpress",
    url: "https://www.facebook.com/groups/397810495540835",
  },
  {
    name: "Dropshipping e E-commerce Brasil",
    url: "https://www.facebook.com/groups/849740553304995",
  },
  {
    name: "Promos e Achados do Dia - Shopee",
    url: "https://www.facebook.com/groups/1459039968837112",
  },
  {
    name: "Grupo Oficial de Cupons e Descontos",
    url: "https://www.facebook.com/groups/826123847522536",
  },
  {
    name: "Achados de Decoração & Lar Shopee",
    url: "https://www.facebook.com/groups/adoradoresdoreinoo",
  },
  {
    name: "Divulgação de Links de Afiliados",
    url: "https://www.facebook.com/groups/1083275326374859",
  },
  {
    name: "Vendas Online & Renda Extra Shopee",
    url: "https://www.facebook.com/groups/3149151475115630",
  },
];

const DIVULG_STEPS = [
  "Publicando no Instagram",
  "Publicando no TikTok",
  "Publicando no Facebook",
  "Enviando para grupos de WhatsApp",
  "Enviando para canais do Telegram",
  "Publicando no Kwai",
  "Divulgando dentro da Shopee",
  "Impulsionando em grupos de ofertas",
];

type AdStyle = "viral" | "storytelling" | "premium" | "direct";

function buildDescription(p: Product, style: AdStyle = "viral", variation?: string): string {
  const price = brl(p.price);
  const old = p.oldPrice ? brl(p.oldPrice) : null;
  const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;

  const displayName =
    variation &&
    variation !== "Modelo Padrão" &&
    variation !== "Kit Completo" &&
    variation !== "Padrão"
      ? `${p.name} (${variation})`
      : p.name;

  if (style === "viral") {
    return [
      `🚨 GENTE, OLHA ESSE ACHADINHO! 🚨`,
      ``,
      `Se você ainda não conhece o ${displayName}, você está perdendo tempo! 😱`,
      ``,
      `✨ ${p.description}`,
      ``,
      `Por que ele é o queridinho do momento?`,
      `✅ Prático, moderno e de altíssima qualidade`,
      `✅ Recomendado por criadores de conteúdo`,
      `✅ O melhor custo-benefício que você vai ver hoje!`,
      ``,
      `🔥 Sucesso absoluto com mais de ${p.sold.toLocaleString("pt-BR")}+ unidades vendidas e nota ${p.rating.toFixed(1)}/5 de aprovação!`,
      ``,
      old ? `❌ De ${old}\n🔥 POR APENAS ${price} (${discount}% OFF!)` : `🔥 Por apenas ${price}`,
      ``,
      `👉 Comente "EU QUERO" ou me mande um direct para garantir o seu com FRETE RÁPIDO! 🛒👇`,
      ``,
      `#achadinhos #viral #promoção #comprei #shopeebrasil #desconto`,
    ].join("\n");
  }

  if (style === "storytelling") {
    return [
      `Você já sentiu que precisava de mais praticidade e estilo no seu dia a dia? 🤔`,
      ``,
      `O ${displayName} foi desenvolvido exatamente para quem não abre mão de qualidade e quer simplificar a rotina com inteligência.`,
      ``,
      `🌟 O diferencial dele?`,
      `${p.description}`,
      ``,
      `Imagine a sensação de ter um produto premium, confiável e com design impecável focado em resolver seus problemas. É por isso que ele se tornou um success absoluto com mais de ${p.sold.toLocaleString("pt-BR")}+ clientes extremamente satisfeitos!`,
      ``,
      old
        ? `Seja inteligente: garanta o seu hoje de ${old} por apenas ${price} e economize ${discount}%!`
        : `Garanta o seu hoje por apenas ${price}!`,
      ``,
      `🛡️ Sua compra segura:`,
      `• Garantia oficial de fábrica`,
      `• Envio expresso rastreado`,
      `• Suporte premium ao cliente`,
      ``,
      `👉 Toque no link da bio para garantir o seu antes que o estoque acabe! ✨`,
    ].join("\n");
  }

  if (style === "premium") {
    return [
      `✨ SOFISTICAÇÃO & ALTA PERFORMANCE ✨`,
      ``,
      `Apresentamos o ${displayName} — a união perfeita entre tecnologia de ponta, design refinado e durabilidade incomparável.`,
      ``,
      `Criado para pessoas exigentes que valorizam cada detalhe:`,
      `💎 Acabamento premium e exclusivo`,
      `💎 Experiência de uso única e memorável`,
      `💎 Detalhe: ${p.description}`,
      ``,
      `⭐ Classificação máxima: avaliado em ${p.rating.toFixed(1)}/5 estrelas por clientes do nicho de alto padrão.`,
      ``,
      old
        ? `Valor promocional de lançamento: De ${old} por ${price} (com frete gratuito ativo por tempo limitado)`
        : `Valor de lançamento: ${price}`,
      ``,
      `✨ Um investimento no que há de melhor para você ou para presentear quem você ama.`,
      ``,
      `🛒 Clique no link exclusivo da nossa bio e garanta o seu com segurança. Poucas unidades disponíveis.`,
    ].join("\n");
  }

  // default to 'direct'
  return [
    `🔥 OFERTA DO DIA: ${displayName.toUpperCase()} 🔥`,
    ``,
    `Está procurando o melhor preço com entrega rápida? Você acabou de encontrar!`,
    ``,
    `📋 FICHA TÉCNICA E DETALHES:`,
    `• Descrição: ${p.description}`,
    `• Avaliação média: ⭐ ${p.rating.toFixed(1)}/5 estrelas`,
    `• Volume de vendas: +${p.sold.toLocaleString("pt-BR")} entregues`,
    `• Status: Novo, lacrado na caixa com garantia oficial`,
    ``,
    old
      ? `💵 DE: ${old}\n💵 POR: ${price}\n💥 ECONOMIA REAL DE ${discount}%!`
      : `💵 PREÇO ESPECIAL: ${price}`,
    ``,
    `🚚 FRETE SEGURO E RÁPIDO PARA TODO O BRASIL!`,
    ``,
    `🔒 COMPRA 100% PROTEGIDA: Receba exatamente o que pediu ou seu dinheiro de volta.`,
    ``,
    `🛒 Clique no link da bio ou digite "EU QUERO" para receber o link com segurança!`,
  ].join("\n");
}

async function renderAdImage(product: Product, variation?: string): Promise<string> {
  const size = 1080;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, size, size);

  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = product.image;
  await new Promise<void>((res, rej) => {
    img.onload = () => res();
    img.onerror = () => rej(new Error("image load failed"));
  });

  const imgArea = { x: 0, y: 0, w: size, h: size * 0.78 };
  const ratio = Math.max(imgArea.w / img.width, imgArea.h / img.height);
  const iw = img.width * ratio;
  const ih = img.height * ratio;
  const ix = imgArea.x + (imgArea.w - iw) / 2;
  const iy = imgArea.y + (imgArea.h - ih) / 2;
  ctx.drawImage(img, ix, iy, iw, ih);

  ctx.save();
  ctx.translate(size - 180, 180);
  ctx.rotate(Math.PI / 4);
  ctx.fillStyle = "#f5511e";
  ctx.fillRect(-260, -50, 520, 100);
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 44px Inter, Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("OFERTA", 0, 0);
  ctx.restore();

  // Draw variation badge if active
  if (
    variation &&
    variation !== "Modelo Padrão" &&
    variation !== "Kit Completo" &&
    variation !== "Padrão"
  ) {
    ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
    ctx.font = "bold 26px Inter, Arial, sans-serif";
    const text = variation.toUpperCase();
    const textWidth = ctx.measureText(text).width;
    const badgeW = Math.min(600, textWidth + 60);
    const badgeH = 70;
    const badgeX = 40;
    const badgeY = 40;
    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 15);
    } else {
      ctx.rect(badgeX, badgeY, badgeW, badgeH);
    }
    ctx.fill();

    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(text, badgeX + 30, badgeY + badgeH / 2);
  }

  const bannerY = size * 0.78;
  ctx.fillStyle = "#f5511e";
  ctx.fillRect(0, bannerY, size, size - bannerY);

  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.font = "600 34px Inter, Arial, sans-serif";
  ctx.fillText("APENAS", size / 2, bannerY + 60);

  ctx.font = "900 130px Inter, Arial, sans-serif";
  ctx.fillText(brl(product.price), size / 2, bannerY + 165);

  if (product.oldPrice) {
    ctx.font = "500 32px Inter, Arial, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    const oldText = `de ${brl(product.oldPrice)}`;
    ctx.fillText(oldText, size / 2, bannerY + 210);
    const metrics = ctx.measureText(oldText);
    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(size / 2 - metrics.width / 2, bannerY + 210);
    ctx.lineTo(size / 2 + metrics.width / 2, bannerY + 210);
    ctx.stroke();
  }

  return canvas.toDataURL("image/png");
}

// Generate stable random metrics based on product.id so they are constant yet unique for each product
interface ProductMetrics {
  difficulty: { label: string; color: string; percent: number };
  conversionRate: string;
  marginPercent: number;
  costPrice: number;
  profitPerSale: number;
  searchVolume: number;
  totalRevenue: number;
  affiliateCommissionPercent: number;
  daysActive: number;
}

function getProductMetrics(product: Product): ProductMetrics {
  const seed = product.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);

  const difficulties = [
    {
      label: "Muito Fácil (Demanda Explosiva)",
      color: "text-emerald-500 bg-emerald-500/10 border-emerald-500/20",
      percent: 95,
    },
    {
      label: "Fácil (Alta Conversão)",
      color: "text-green-500 bg-green-500/10 border-green-500/20",
      percent: 86,
    },
    {
      label: "Fácil (Alta Demanda)",
      color: "text-teal-500 bg-teal-500/10 border-teal-500/20",
      percent: 79,
    },
    {
      label: "Moderado (Nicho Aquecido)",
      color: "text-blue-500 bg-blue-500/10 border-blue-500/20",
      percent: 64,
    },
  ];
  const difficulty = difficulties[seed % difficulties.length];

  const conversionRate = (3.5 + (seed % 45) / 10).toFixed(1) + "%";
  const marginPercent = 55 + (seed % 26); // 55% to 80%
  const costPrice = +(product.price * (1 - marginPercent / 100)).toFixed(2);
  const profitPerSale = +(product.price - costPrice).toFixed(2);
  const searchVolume = ((seed % 12) + 2) * 8500 + (seed % 7) * 940;
  const totalRevenue = product.sold * product.price;
  const affiliateCommissionPercent = 40 + (seed % 31); // 40% to 70%
  const daysActive = 45 + (seed % 75);

  return {
    difficulty,
    conversionRate,
    marginPercent,
    costPrice,
    profitPerSale,
    searchVolume,
    totalRevenue,
    affiliateCommissionPercent,
    daysActive,
  };
}

type Phase = "ad" | "divulgando" | "done";
type TabId = "metrics" | "affiliate" | "ad";

export function GerarAnuncioDialog({
  product,
  open,
  onOpenChange,
}: {
  product: Product | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [activeTab, setActiveTab] = useState<TabId>("metrics");

  const [adStyle, setAdStyle] = useState<AdStyle>("viral");
  const [loading, setLoading] = useState(true);
  const [adUrl, setAdUrl] = useState<string | null>(null);
  const [description, setDescription] = useState("");
  const [copied, setCopied] = useState(false);
  const ranRef = useRef(false);

  const [phase, setPhase] = useState<Phase>("ad");
  const [stepIndex, setStepIndex] = useState(0);
  const [result, setResult] = useState<{ sales: number; commission: number } | null>(null);

  const [suggestedGroups, setSuggestedGroups] = useState<typeof FACEBOOK_GROUPS>([]);

  // Affiliate state variables
  const [isAffiliated, setIsAffiliated] = useState(false);
  const [affiliateLoading, setAffiliateLoading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Compute unique product-specific metrics
  const metrics = useMemo(() => {
    if (!product) return null;
    return getProductMetrics(product);
  }, [product]);

  const [selectedVariation, setSelectedVariation] = useState<string>("");

  const variations = useMemo(() => {
    if (!product) return [];
    return getProductVariations(product);
  }, [product]);

  // Set default variation when product changes
  useEffect(() => {
    if (variations.length > 0) {
      setSelectedVariation(variations[0]);
    } else {
      setSelectedVariation("");
    }
  }, [variations]);

  // Re-generate description and image whenever product, style, or variation changes
  useEffect(() => {
    if (!open || !product) return;

    setLoading(true);
    renderAdImage(product, selectedVariation)
      .then((url) => setAdUrl(url))
      .catch(() => setAdUrl(product.image))
      .finally(() => setLoading(false));

    setDescription(buildDescription(product, adStyle, selectedVariation));
  }, [open, product, adStyle, selectedVariation]);

  useEffect(() => {
    if (!open) {
      setLoading(true);
      setAdUrl(null);
      setDescription("");
      setCopied(false);
      setPhase("ad");
      setStepIndex(0);
      setResult(null);
      ranRef.current = false;
      setSuggestedGroups([]);
      setActiveTab("metrics");
      setAdStyle("viral");
      setIsAffiliated(false);
      setAffiliateLoading(false);
      setCopiedLink(false);
      setSelectedVariation("");
      return;
    }
    if (!product) return;

    // Check localStorage for active affiliate program
    const active = localStorage.getItem(`aff_active_${product.id}`) === "true";
    setIsAffiliated(active);
  }, [open, product]);

  const handleFindGroups = () => {
    const shuffled = [...FACEBOOK_GROUPS].sort(() => Math.random() - 0.5);
    setSuggestedGroups(shuffled);
  };

  // Affiliate registration simulation
  const handleAffiliate = () => {
    if (!product) return;
    setAffiliateLoading(true);
    setTimeout(() => {
      localStorage.setItem(`aff_active_${product.id}`, "true");
      setIsAffiliated(true);
      setAffiliateLoading(false);

      if (product.name.toLowerCase().includes("obsession")) {
        window.open("https://s.shopee.com.br/5VTtDgPSXR", "_blank");
      }

      toast.success("Afiliação ativada com sucesso! Link exclusivo liberado.", {
        icon: <ShieldCheck className="h-5 w-5 text-emerald-500" />,
      });
    }, 1200);
  };

  const handleCopyAffiliateLink = async () => {
    if (!product) return;
    const link = product.name.toLowerCase().includes("obsession")
      ? "https://s.shopee.com.br/5VTtDgPSXR"
      : `https://apexf.in/aff/${product.id}?ref=user`;
    await navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    toast.success("Link de afiliado copiado para a área de transferência!");
  };

  // Animate the "divulgando" progress
  useEffect(() => {
    if (phase !== "divulgando" || !product) return;
    if (stepIndex >= DIVULG_STEPS.length) {
      const sales = 3 + Math.floor(Math.random() * 18); // 3..20
      const factor = 0.4 + Math.random() * 0.6;
      const commission = +Math.min(product.price, product.price * factor).toFixed(2);
      addCommission(commission, product.price);
      setResult({ sales, commission });
      setPhase("done");
      return;
    }
    const t = window.setTimeout(() => setStepIndex((i) => i + 1), 750);
    return () => window.clearTimeout(t);
  }, [phase, stepIndex, product]);

  const progress = useMemo(() => Math.round((stepIndex / DIVULG_STEPS.length) * 100), [stepIndex]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(description);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!adUrl || !product) return;
    const a = document.createElement("a");
    a.href = adUrl;
    a.download = `anuncio-${product.id}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const startDivulgar = () => {
    setStepIndex(0);
    setPhase("divulgando");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto rounded-3xl p-6">
        <DialogHeader className="border-b border-border pb-4">
          <DialogTitle className="text-xl font-black text-foreground flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            {product?.name}
          </DialogTitle>
          <DialogDescription className="text-left text-xs">
            Visualize métricas consolidadas, gerencie sua afiliação e gere criativos automatizados
            com IA.
          </DialogDescription>
        </DialogHeader>

        {product && (
          <div className="space-y-6 mt-4">
            {/* Horizontal Segmented Tabs Control */}
            <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-muted/60 border border-border/80">
              <button
                type="button"
                onClick={() => setActiveTab("metrics")}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                  activeTab === "metrics"
                    ? "bg-card text-foreground shadow-sm border border-border/30"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <BarChart3 className="h-3.5 w-3.5 shrink-0" />
                Métricas
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("affiliate")}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                  activeTab === "affiliate"
                    ? "bg-card text-foreground shadow-sm border border-border/30"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Users className="h-3.5 w-3.5 shrink-0" />
                Se Afiliar
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("ad")}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                  activeTab === "ad"
                    ? "bg-card text-foreground shadow-sm border border-border/30"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Sparkles className="h-3.5 w-3.5 shrink-0" />
                Gerar Anúncio
              </button>
            </div>

            {/* TAB CONTENT: 1. METRICS */}
            {activeTab === "metrics" && metrics && (
              <div className="space-y-5 animate-fade-in">
                <div className="grid gap-4 sm:grid-cols-2">
                  {/* Sales Performance Card */}
                  <div
                    className="rounded-2xl border border-border bg-card p-5 space-y-4"
                    style={{ boxShadow: "var(--shadow-card)" }}
                  >
                    <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                      <TrendingUp className="h-4 w-4 text-emerald-500" />
                      Performance de Vendas
                    </h4>

                    <div className="space-y-3.5">
                      <div className="flex justify-between items-baseline">
                        <span className="text-xs text-muted-foreground font-semibold">
                          Unidades Vendidas:
                        </span>
                        <span className="text-base font-black text-foreground">
                          {product.sold.toLocaleString("pt-BR")} un
                        </span>
                      </div>

                      <div className="flex justify-between items-baseline border-t border-border/50 pt-2.5">
                        <span className="text-xs text-muted-foreground font-semibold">
                          Receita Gerada:
                        </span>
                        <span className="text-base font-black text-primary">
                          {brl(metrics.totalRevenue)}
                        </span>
                      </div>

                      <div className="flex justify-between items-baseline border-t border-border/50 pt-2.5">
                        <span className="text-xs text-muted-foreground font-semibold">
                          Preço de Venda:
                        </span>
                        <span className="text-sm font-bold text-foreground">
                          {brl(product.price)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Difficulty & Conversion */}
                  <div
                    className="rounded-2xl border border-border bg-card p-5 space-y-4"
                    style={{ boxShadow: "var(--shadow-card)" }}
                  >
                    <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                      <Gauge className="h-4 w-4 text-primary" />
                      Análise de Mercado
                    </h4>

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span className="text-muted-foreground">Facilidade de Venda:</span>
                          <span className="font-bold text-foreground">
                            {metrics.difficulty.label.split(" ")[0]}
                          </span>
                        </div>
                        <div
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border text-center ${metrics.difficulty.color}`}
                        >
                          {metrics.difficulty.label}
                        </div>
                      </div>

                      <div className="space-y-1 pt-1.5 border-t border-border/50">
                        <div className="flex justify-between text-xs font-semibold">
                          <span className="text-muted-foreground">Conversão Estimada:</span>
                          <span className="font-black text-foreground">
                            {metrics.conversionRate}
                          </span>
                        </div>
                        <Progress
                          value={parseFloat(metrics.conversionRate) * 10}
                          className="h-2 bg-muted"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Extended Metrics Bento Grid */}
                <div className="grid gap-3 grid-cols-2 sm:grid-cols-4">
                  <div className="p-3.5 bg-muted/30 border border-border/70 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                      <Target className="h-3 w-3 text-primary" /> Volume de Busca
                    </span>
                    <p className="text-sm font-black text-foreground">
                      {metrics.searchVolume.toLocaleString("pt-BR")}/mês
                    </p>
                  </div>

                  <div className="p-3.5 bg-muted/30 border border-border/70 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                      <Percent className="h-3 w-3 text-emerald-500" /> Margem Média
                    </span>
                    <p className="text-sm font-black text-foreground">{metrics.marginPercent}%</p>
                  </div>

                  <div className="p-3.5 bg-muted/30 border border-border/70 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                      <DollarSign className="h-3 w-3 text-primary" /> Lucro p/ Unidade
                    </span>
                    <p className="text-sm font-black text-emerald-600">
                      {brl(metrics.profitPerSale)}
                    </p>
                  </div>

                  <div className="p-3.5 bg-muted/30 border border-border/70 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                      <Award className="h-3 w-3 text-amber-500" /> Score de Sucesso
                    </span>
                    <p className="text-sm font-black text-foreground">
                      {(product.rating * 20).toFixed(0)}/100
                    </p>
                  </div>
                </div>

                {/* Action footer */}
                <div className="flex gap-2 justify-end pt-2">
                  <Button
                    variant="outline"
                    className="font-bold text-xs"
                    onClick={() => setActiveTab("affiliate")}
                  >
                    Ir para Afiliação
                  </Button>
                  <Button className="font-bold text-xs" onClick={() => setActiveTab("ad")}>
                    Gerar Criativos
                  </Button>
                </div>
              </div>
            )}

            {/* TAB CONTENT: 2. AFFILIATION */}
            {activeTab === "affiliate" && metrics && (
              <div className="space-y-5 animate-fade-in">
                {isAffiliated ? (
                  // Active Affiliate Panel
                  <div className="space-y-4">
                    <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-5 space-y-4">
                      <div className="flex items-center gap-2 text-emerald-600">
                        <ShieldCheck className="h-5 w-5 animate-bounce" />
                        <h4 className="text-sm font-black uppercase tracking-wider">
                          Afiliação Ativa
                        </h4>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Parabéns! Você é um afiliado oficial deste produto. Divulgue seu link
                        exclusivo abaixo e receba comissões automáticas diretamente no seu painel.
                      </p>

                      {/* Affiliate Link Input Area */}
                      <div className="space-y-1.5 pt-2">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                          <Link2 className="h-3.5 w-3.5" /> Seu Link de Divulgação Exclusivo
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            readOnly
                            value={
                              product.name.toLowerCase().includes("obsession")
                                ? "https://s.shopee.com.br/5VTtDgPSXR"
                                : `https://apexf.in/aff/${product.id}?ref=user`
                            }
                            className="flex-1 bg-card border border-border rounded-xl px-3 py-2 text-xs font-mono text-muted-foreground"
                          />
                          <Button
                            size="sm"
                            variant={copiedLink ? "secondary" : "outline"}
                            onClick={handleCopyAffiliateLink}
                            className="font-bold shrink-0 text-xs"
                          >
                            {copiedLink ? (
                              <Check className="h-4 w-4 text-emerald-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Commissions Details Box */}
                    <div className="grid gap-3 sm:grid-cols-2 p-4 bg-muted/20 border border-border/80 rounded-xl">
                      <div className="space-y-0.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground">
                          Sua Comissão
                        </span>
                        <p className="text-xl font-black text-emerald-600">
                          {metrics.affiliateCommissionPercent}%
                        </p>
                      </div>
                      <div className="space-y-0.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground">
                          Ganho Líquido por Venda
                        </span>
                        <p className="text-xl font-black text-primary">
                          {brl((product.price * metrics.affiliateCommissionPercent) / 100)}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  // Affiliate CTA Screen
                  <div
                    className="rounded-2xl border border-border bg-card p-6 text-center space-y-5"
                    style={{ boxShadow: "var(--shadow-card)" }}
                  >
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <Users className="h-7 w-7" />
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-base font-black text-foreground">
                        Solicitar Afiliação Instantânea
                      </h4>
                      <p className="text-xs text-muted-foreground max-w-md mx-auto leading-relaxed">
                        Afilie-se agora mesmo para obter o seu link exclusivo da Shopee. Oferecemos
                        comissão garantida de{" "}
                        <span className="font-bold text-primary">
                          {metrics.affiliateCommissionPercent}%
                        </span>{" "}
                        sobre o preço final deste produto!
                      </p>
                    </div>

                    {/* Profit showcase */}
                    <div className="max-w-xs mx-auto p-3.5 rounded-xl border border-border/80 bg-muted/40 grid grid-cols-2 gap-3 text-left">
                      <div>
                        <span className="text-[9px] uppercase font-bold text-muted-foreground">
                          Preço Original
                        </span>
                        <p className="text-sm font-black text-foreground">{brl(product.price)}</p>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase font-bold text-muted-foreground">
                          Sua Comissão
                        </span>
                        <p className="text-sm font-black text-emerald-600">
                          {brl((product.price * metrics.affiliateCommissionPercent) / 100)}
                        </p>
                      </div>
                    </div>

                    <Button
                      className="w-full max-w-sm font-black uppercase tracking-wider text-xs h-11"
                      onClick={handleAffiliate}
                      disabled={affiliateLoading}
                    >
                      {affiliateLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processando Afiliação...
                        </>
                      ) : (
                        <>🤝 Se Afiliar ao Produto</>
                      )}
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: 3. ADS & AI CREATIVES */}
            {activeTab === "ad" && (
              <div className="space-y-5 animate-fade-in">
                {/* Variation Selector */}
                {variations.length > 1 && (
                  <div className="rounded-xl border border-border/80 bg-muted/20 p-3.5 space-y-2">
                    <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
                      <Sparkles className="h-3.5 w-3.5 text-primary" />
                      Escolha a Variação do Produto para o Anúncio
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {variations.map((v) => (
                        <button
                          key={v}
                          type="button"
                          onClick={() => setSelectedVariation(v)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                            selectedVariation === v
                              ? "bg-primary text-primary-foreground border-primary shadow-sm"
                              : "bg-card text-foreground hover:bg-muted border-border"
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {phase === "ad" && (
                  <>
                    <div className="grid gap-6 md:grid-cols-2">
                      <div>
                        <div className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                          Imagem do anúncio
                        </div>
                        <div className="relative aspect-square overflow-hidden rounded-xl border border-border bg-secondary">
                          {loading ? (
                            <div className="flex h-full w-full items-center justify-center">
                              <Loader2 className="h-8 w-8 animate-spin text-primary" />
                            </div>
                          ) : (
                            <img
                              src={adUrl!}
                              alt={`Anúncio de ${product.name}`}
                              className="h-full w-full object-cover"
                            />
                          )}
                        </div>
                        <Button
                          className="mt-3 w-full font-bold"
                          size="lg"
                          variant="secondary"
                          disabled={loading || !adUrl}
                          onClick={handleDownload}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Baixar imagem
                        </Button>
                      </div>

                      <div>
                        <div className="mb-3">
                          <label className="text-xs font-bold uppercase tracking-wide text-muted-foreground block mb-2">
                            Variação de Anúncio IA
                          </label>
                          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-muted/40 border border-border/60">
                            <button
                              type="button"
                              onClick={() => setAdStyle("viral")}
                              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                                adStyle === "viral"
                                  ? "bg-card text-foreground shadow-sm border border-border/30"
                                  : "text-muted-foreground hover:text-foreground"
                              }`}
                            >
                              <Sparkles className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                              Oferta Viral
                            </button>
                            <button
                              type="button"
                              onClick={() => setAdStyle("storytelling")}
                              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                                adStyle === "storytelling"
                                  ? "bg-card text-foreground shadow-sm border border-border/30"
                                  : "text-muted-foreground hover:text-foreground"
                              }`}
                            >
                              <Users className="h-3.5 w-3.5 shrink-0 text-primary" />
                              Storytelling
                            </button>
                            <button
                              type="button"
                              onClick={() => setAdStyle("premium")}
                              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                                adStyle === "premium"
                                  ? "bg-card text-foreground shadow-sm border border-border/30"
                                  : "text-muted-foreground hover:text-foreground"
                              }`}
                            >
                              <Award className="h-3.5 w-3.5 shrink-0 text-yellow-500" />
                              VIP / Premium
                            </button>
                            <button
                              type="button"
                              onClick={() => setAdStyle("direct")}
                              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                                adStyle === "direct"
                                  ? "bg-card text-foreground shadow-sm border border-border/30"
                                  : "text-muted-foreground hover:text-foreground"
                              }`}
                            >
                              <Target className="h-3.5 w-3.5 shrink-0 text-rose-500" />
                              Direto ao Ponto
                            </button>
                          </div>
                        </div>
                        <Textarea
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          className="min-h-[220px] resize-none text-sm leading-relaxed"
                        />
                        <Button
                          className="mt-3 w-full font-bold"
                          size="lg"
                          variant={copied ? "secondary" : "outline"}
                          onClick={handleCopy}
                        >
                          {copied ? (
                            <>
                              <Check className="mr-2 h-4 w-4" /> Copiado!
                            </>
                          ) : (
                            <>
                              <Copy className="mr-2 h-4 w-4" /> Copiar descrição
                            </>
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Seção Divulgação Rápida com IA */}
                    <div className="p-4 rounded-2xl border border-primary/20 bg-primary/5 space-y-3.5">
                      <div className="flex flex-col gap-1 text-left">
                        <h4 className="text-xs font-black uppercase tracking-wider text-primary flex items-center gap-1.5">
                          <Megaphone className="h-4 w-4 shrink-0" />
                          Divulgação de Tráfego Orgânico com IA
                        </h4>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          Nossa inteligência artificial pode disparar campanhas integradas e
                          automáticas para o Kwai, TikTok, Facebook, WhatsApp, Instagram e Twitter
                          consumindo créditos de IA para recompensas expressas.
                        </p>
                      </div>
                      <Button
                        className="w-full font-black uppercase tracking-widest text-xs h-11"
                        onClick={startDivulgar}
                        disabled={loading}
                      >
                        🚀 Disparar Divulgação de Tráfego IA
                      </Button>
                    </div>

                    {/* Seção Achar Grupos */}
                    <div className="rounded-2xl border border-border bg-muted/30 p-4 space-y-4">
                      <div className="flex flex-col gap-1.5 text-left">
                        <h4 className="text-sm font-bold text-foreground flex items-center gap-2">
                          <Facebook className="h-4.5 w-4.5 text-[#1877F2]" />
                          Achar grupos de divulgação
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          Gere maior alcance encontrando e postando diretamente nos grupos sugeridos
                          do Facebook.
                        </p>
                      </div>

                      <Button
                        className="w-full font-bold uppercase tracking-wider"
                        size="lg"
                        variant="outline"
                        onClick={handleFindGroups}
                        disabled={loading}
                      >
                        <Facebook className="mr-2 h-4 w-4 text-[#1877F2]" />
                        {suggestedGroups.length > 0 ? "Encontrar mais grupos" : "Achar Grupos"}
                      </Button>

                      {suggestedGroups.length > 0 && (
                        <div className="space-y-2 text-left">
                          <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                            Grupos Recomendados
                          </div>
                          <div className="grid gap-2 sm:grid-cols-2 max-h-[180px] overflow-y-auto pr-1">
                            {suggestedGroups.map((group, idx) => (
                              <a
                                key={group.url}
                                href={group.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-3 text-xs font-semibold hover:border-primary/50 hover:bg-accent/5 transition-all group"
                                id={`group-link-${idx}`}
                              >
                                <span className="truncate text-foreground font-medium flex items-center gap-2">
                                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-[10px] font-black">
                                    {idx + 1}
                                  </span>
                                  <span className="truncate">{group.name}</span>
                                </span>
                                <ExternalLink className="h-3.5 w-3.5 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {phase === "divulgando" && (
                  <div className="space-y-4 text-left animate-fade-in">
                    <Progress value={progress} className="h-3" />
                    <div className="text-center text-sm font-semibold text-muted-foreground">
                      {progress}% concluído
                    </div>
                    <ul className="space-y-2">
                      {DIVULG_STEPS.map((label, i) => {
                        const done = i < stepIndex;
                        const active = i === stepIndex;
                        return (
                          <li
                            key={label}
                            className={`flex items-center gap-3 rounded-lg border px-4 py-2.5 text-sm transition ${
                              done
                                ? "border-green-300 bg-green-50 text-green-800"
                                : active
                                  ? "border-primary/40 bg-primary/5 text-foreground"
                                  : "border-border text-muted-foreground"
                            }`}
                          >
                            {done ? (
                              <CheckCircle2 className="h-4 w-4 shrink-0 text-green-600" />
                            ) : active ? (
                              <Loader2 className="h-4 w-4 shrink-0 animate-spin text-primary" />
                            ) : (
                              <span className="h-4 w-4 shrink-0 rounded-full border border-border" />
                            )}
                            <span className="font-medium">{label}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}

                {phase === "done" && result && (
                  <div className="space-y-4 text-center animate-fade-in">
                    <div className="rounded-2xl border border-green-300 bg-green-50 p-6">
                      <TrendingUp className="mx-auto h-8 w-8 text-green-600" />
                      <div className="mt-2 text-4xl font-black text-green-700">
                        {result.sales} Vendas realizadas
                      </div>
                      <p className="mt-1 text-sm font-medium text-green-800">
                        Sua divulgação gerou vendas imediatas!
                      </p>
                    </div>
                    <div className="rounded-2xl border border-primary/30 bg-primary/5 p-6">
                      <div className="text-xs font-bold uppercase tracking-wider text-primary">
                        Comissão creditada
                      </div>
                      <div className="mt-1 text-4xl font-black text-primary">
                        R$ {formatBRL(result.commission)}
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        O valor foi somado ao saldo da sua Dashboard.
                      </p>
                    </div>
                    <Button className="w-full font-bold" size="lg" onClick={() => setPhase("ad")}>
                      Voltar ao Criador de Anúncios
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
