import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useEffect, useState } from "react";
import {
  Loader2,
  ShieldCheck,
  ShoppingBag,
  CheckCircle2,
  AlertTriangle,
  Link2,
  RefreshCw,
} from "lucide-react";

export const Route = createFileRoute("/conectar")({
  component: ConectarPage,
  head: () => ({
    meta: [
      { title: "Integração Shopee — Apex Shop" },
      {
        name: "description",
        content:
          "Integre sua conta Shopee ao Apex Shop e comece a divulgar produtos campeões de venda.",
      },
    ],
  }),
});

interface IntegrationData {
  connected: boolean;
  storeName: string;
  email: string;
  partnerId: string;
  appKey: string;
  lastSync: string;
  environment: "production" | "sandbox";
}

const STORAGE_KEY = "shopee_integration_settings";

const defaultState: IntegrationData = {
  connected: false,
  storeName: "",
  email: "",
  partnerId: "",
  appKey: "",
  lastSync: "",
  environment: "production",
};

function ConectarPage() {
  const [data, setData] = useState<IntegrationData>(defaultState);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [tempStoreName, setTempStoreName] = useState("");
  const [tempEmail, setTempEmail] = useState("");
  const [tempPartnerId, setTempPartnerId] = useState("");
  const [tempAppKey, setTempAppKey] = useState("");
  const [tempEnv, setTempEnv] = useState<"production" | "sandbox">("production");

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setData(parsed);
        // Pre-fill temp fields
        setTempStoreName(parsed.storeName || "");
        setTempEmail(parsed.email || "");
        setTempPartnerId(parsed.partnerId || "");
        setTempAppKey(parsed.appKey || "");
        setTempEnv(parsed.environment || "production");
      }
    } catch (e) {
      console.error("Error reading shopee integration from storage", e);
    }
  }, []);

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempEmail || !tempStoreName) return;

    setLoading(true);
    setTimeout(() => {
      const updated: IntegrationData = {
        connected: true,
        storeName: tempStoreName,
        email: tempEmail,
        partnerId: tempPartnerId || "PARTNER_sh_" + Math.floor(Math.random() * 900000 + 100000),
        appKey: tempAppKey || "shopee_sec_" + Math.random().toString(36).substring(7),
        lastSync: new Date().toLocaleString("pt-BR"),
        environment: tempEnv,
      };
      setData(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      setLoading(false);
    }, 1800);
  };

  const handleDisconnect = () => {
    if (
      window.confirm(
        "Deseja realmente desconectar sua loja Shopee? Seus agendamentos ativos serão pausados.",
      )
    ) {
      setData(defaultState);
      localStorage.removeItem(STORAGE_KEY);
      setTempStoreName("");
      setTempEmail("");
      setTempPartnerId("");
      setTempAppKey("");
      setTempEnv("production");
    }
  };

  const handleManualSync = () => {
    setSyncing(true);
    setTimeout(() => {
      const updated = {
        ...data,
        lastSync: new Date().toLocaleString("pt-BR"),
      };
      setData(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      setSyncing(false);
    }, 1200);
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 py-10">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-zinc-200 pb-6 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-orange-100 text-orange-600 px-3 py-1 text-xs font-black uppercase tracking-wider mb-2">
              <ShoppingBag className="h-3.5 w-3.5" /> Shopee Partner API
            </div>
            <h1 className="text-3xl font-black text-foreground tracking-tight">
              Integração da Conta Shopee
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Conecte sua loja ou conta de afiliado Shopee para automação de vendas, posts com IA e
              sincronização em tempo real.
            </p>
          </div>
          {data.connected && (
            <span className="self-start md:self-auto inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" /> Conectado
            </span>
          )}
        </div>

        {data.connected ? (
          /* CONNECTED STATE */
          <div className="space-y-6">
            <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs relative overflow-hidden">
              {/* Background Accent Stripe */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-orange-500 to-red-500" />

              <div className="flex items-start justify-between gap-4 pt-2">
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-orange-50 text-orange-600 border border-orange-100 shadow-xs shrink-0">
                    <ShoppingBag className="h-8 w-8" />
                  </div>
                  <div>
                    <h2 className="text-xl font-black text-foreground tracking-tight">
                      {data.storeName}
                    </h2>
                    <p className="text-xs text-muted-foreground font-semibold">{data.email}</p>
                    <div className="mt-1.5 flex flex-wrap gap-2 items-center text-xs">
                      <span className="px-2 py-0.5 rounded-md bg-zinc-100 font-mono text-zinc-600 border border-zinc-200/60">
                        ID: {data.partnerId}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-orange-50 text-orange-600 font-bold uppercase text-[9px] tracking-wide border border-orange-100/60">
                        API {data.environment === "production" ? "Produção" : "Sandbox"}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleManualSync}
                  disabled={syncing}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-zinc-200 hover:bg-zinc-50 active:scale-95 text-xs font-bold transition text-zinc-700 disabled:opacity-50"
                  title="Sincronizar dados agora"
                >
                  <RefreshCw
                    className={`h-3.5 w-3.5 ${syncing ? "animate-spin text-orange-500" : ""}`}
                  />
                  Sincronizar
                </button>
              </div>

              {/* Connected Details Grid */}
              <div className="mt-6 grid gap-4 sm:grid-cols-3 border-t border-zinc-100 pt-6">
                <div className="bg-zinc-50/50 rounded-xl p-3 border border-zinc-100">
                  <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider">
                    Último Sincronismo
                  </span>
                  <p className="text-sm font-semibold text-foreground mt-0.5">
                    {data.lastSync || "Aguardando..."}
                  </p>
                </div>
                <div className="bg-zinc-50/50 rounded-xl p-3 border border-zinc-100">
                  <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider">
                    Status da Conexão
                  </span>
                  <p className="text-sm font-black text-emerald-600 mt-0.5 flex items-center gap-1">
                    <CheckCircle2 className="h-4 w-4" /> Ativa
                  </p>
                </div>
                <div className="bg-zinc-50/50 rounded-xl p-3 border border-zinc-100">
                  <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider">
                    Canal Autorizado
                  </span>
                  <p className="text-sm font-semibold text-foreground mt-0.5">Shopee Webhook v3</p>
                </div>
              </div>

              {/* Action Links */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3 pt-4 border-t border-zinc-100 justify-end">
                <button
                  onClick={handleDisconnect}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-red-600 hover:bg-red-50 rounded-xl border border-transparent transition"
                >
                  Desconectar Conta
                </button>
              </div>
            </div>

            {/* Quick tips & permissions checklist */}
            <div className="bg-orange-50/50 border border-orange-100 rounded-2xl p-5">
              <h3 className="text-sm font-bold text-orange-800 flex items-center gap-2 mb-2">
                <ShieldCheck className="h-5 w-5 text-orange-600" /> Benefícios da sua Integração
                Shopee
              </h3>
              <ul className="text-xs text-orange-950/85 space-y-2.5 list-disc list-inside">
                <li>
                  <span className="font-semibold text-orange-900">
                    Sincronização de Preço e Estoque:
                  </span>{" "}
                  Seus produtos e preços nos catálogos gerados são atualizados automaticamente em
                  tempo real.
                </li>
                <li>
                  <span className="font-semibold text-orange-900">Comissões de Afiliado:</span>{" "}
                  Rastreamento automático e otimização dos links gerados pela IA com sua tag de
                  afiliado.
                </li>
                <li>
                  <span className="font-semibold text-orange-900">Envio Automático:</span> Libere o
                  disparo direto de campanhas, vídeos e anúncios para os canais de divulgação
                  homologados.
                </li>
              </ul>
            </div>
          </div>
        ) : (
          /* FORM / NOT CONNECTED STATE */
          <div className="space-y-6">
            <form
              onSubmit={handleConnect}
              className="rounded-2xl border border-zinc-200 bg-card p-6 md:p-8 space-y-5 shadow-xs"
            >
              <div className="flex items-center gap-2 text-amber-600 bg-amber-50 border border-amber-100 rounded-xl p-4 text-xs font-semibold">
                <AlertTriangle className="h-5 w-5 shrink-0" />
                <span>
                  Sua conta do Apex Shop não possui uma loja Shopee integrada no momento. Configure
                  abaixo para ativar todas as ferramentas de IA.
                </span>
              </div>

              {/* Store Name */}
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">
                  Nome da Loja ou Conta Shopee <span className="text-primary">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={tempStoreName}
                  onChange={(e) => setTempStoreName(e.target.value)}
                  placeholder="Ex: Apex Variedades"
                  className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none transition focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/10"
                />
              </div>

              {/* Email */}
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground">
                  E-mail da sua Conta Shopee <span className="text-primary">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={tempEmail}
                  onChange={(e) => setTempEmail(e.target.value)}
                  placeholder="voce@exemplo.com"
                  className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none transition focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/10"
                />
              </div>

              {/* Row Grid for Partner ID and Env */}
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Shopee Partner ID */}
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-foreground flex items-center justify-between">
                    <span>Shopee Partner ID</span>
                    <span className="text-[10px] text-muted-foreground font-normal">
                      (Opcional)
                    </span>
                  </label>
                  <input
                    type="text"
                    value={tempPartnerId}
                    onChange={(e) => setTempPartnerId(e.target.value)}
                    placeholder="Ex: 839483"
                    className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none transition focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/10"
                  />
                </div>

                {/* Environment Selector */}
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-foreground">
                    Ambiente de Integração
                  </label>
                  <select
                    value={tempEnv}
                    onChange={(e) => setTempEnv(e.target.value as "production" | "sandbox")}
                    className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none transition focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/10"
                  >
                    <option value="production">Produção (Live Store)</option>
                    <option value="sandbox">Sandbox (Teste/Homologação)</option>
                  </select>
                </div>
              </div>

              {/* App Key */}
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-foreground flex items-center justify-between">
                  <span>Shopee App Key (Chave Secreta)</span>
                  <span className="text-[10px] text-muted-foreground font-normal">(Opcional)</span>
                </label>
                <input
                  type="password"
                  value={tempAppKey}
                  onChange={(e) => setTempAppKey(e.target.value)}
                  placeholder="••••••••••••••••••••••••••••••••"
                  className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none transition focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/10"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-black uppercase tracking-widest text-white transition hover:opacity-95 active:scale-95 disabled:opacity-70 shadow-lg shadow-orange-500/20"
                style={{ background: "linear-gradient(135deg, #FF8E42 0%, #EE4D2D 100%)" }}
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Conectando API Shopee...
                  </>
                ) : (
                  <>
                    <Link2 className="h-4 w-4" /> Conectar Conta Shopee
                  </>
                )}
              </button>

              <p className="text-center text-xs text-muted-foreground">
                Sua conexão é estabelecida de forma segura através de encriptação ponta a ponta
                homologada pela Shopee Open Platform.
              </p>
            </form>
          </div>
        )}
      </div>
    </AppShell>
  );
}
