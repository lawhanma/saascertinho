import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useEffect, useState } from "react";
import { useBalance, formatBRL, useStats, withdrawAmount } from "@/lib/salesStore";
import {
  Wallet,
  ArrowUpRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Lock,
  DollarSign,
  ShoppingCart,
  Calendar,
} from "lucide-react";

export const Route = createFileRoute("/financeiro")({
  component: FinanceiroPage,
  head: () => ({
    meta: [
      { title: "Financeiro — Apex Shop" },
      {
        name: "description",
        content: "Gerencie seus ganhos e realize saques de suas comissões.",
      },
    ],
  }),
});

interface SaqueRecord {
  id: string;
  date: string;
  amount: number;
  status: "Pendente" | "Concluido";
  pixKey: string;
}

const STORAGE_HISTORY_KEY = "shopee_withdrawal_history";
const MIN_SAQUE = 1000; // R$ 1.000,00 minimum

function FinanceiroPage() {
  const balance = useBalance();
  const stats = useStats();
  const [history, setHistory] = useState<SaqueRecord[]>([]);
  const [amount, setAmount] = useState("");
  const [pixKey, setPixKey] = useState("");
  const [pixType, setPixType] = useState("cpf");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [successAmount, setSuccessAmount] = useState(0);

  // Load withdrawal history on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_HISTORY_KEY);
      if (stored) {
        setHistory(JSON.parse(stored));
      } else {
        // Initial mock history to look established and polished
        const initialMock: SaqueRecord[] = [
          {
            id: "W-9843",
            date: "10/07/2026 14:32",
            amount: 350.0,
            status: "Concluido",
            pixKey: "hen***@gmail.com",
          },
          {
            id: "W-1234",
            date: "18/07/2026 09:15",
            amount: 150.25,
            status: "Concluido",
            pixKey: "hen***@gmail.com",
          },
        ];
        localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(initialMock));
        setHistory(initialMock);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  const numericAmount = Number(amount.replace(",", ".")) || 0;
  const canWithdraw = balance >= MIN_SAQUE;
  const missingAmount = Math.max(0, MIN_SAQUE - balance);
  const invalidAmount =
    !canWithdraw || numericAmount <= 0 || numericAmount > balance || numericAmount < MIN_SAQUE;

  const handleWithdrawRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (invalidAmount || !pixKey) return;

    setLoading(true);

    setTimeout(() => {
      // 1. Deduct from balance
      withdrawAmount(numericAmount);

      // 2. Add to history
      const newRecord: SaqueRecord = {
        id: "W-" + Math.floor(Math.random() * 9000 + 1000),
        date: new Date().toLocaleString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
        amount: numericAmount,
        status: "Pendente",
        pixKey: pixKey.length > 15 ? pixKey.substring(0, 12) + "..." : pixKey,
      };

      const updatedHistory = [newRecord, ...history];
      setHistory(updatedHistory);
      localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(updatedHistory));

      setSuccessAmount(numericAmount);
      setAmount("");
      setPixKey("");
      setLoading(false);
      setSuccess(true);

      // Reset success banner after 5 seconds
      setTimeout(() => setSuccess(false), 5000);
    }, 1500);
  };

  // Safe division for ticket médio
  const ticketMedio = stats.sales > 0 ? balance / stats.sales : 0;

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        {/* Header */}
        <div className="border-b border-zinc-200 pb-6 mb-8">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-orange-100 text-orange-600 px-3 py-1 text-xs font-black uppercase tracking-wider mb-2">
            <DollarSign className="h-3.5 w-3.5" /> Controle de Comissões
          </div>
          <h1 className="text-3xl font-black text-foreground tracking-tight">Financeiro</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Acompanhe suas vendas, comissões recebidas e solicite saques diretamente para sua conta
            via PIX.
          </p>
        </div>

        {/* Top Cards Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          {/* Main Balance Card */}
          <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-orange-500 to-red-500" />
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider flex items-center gap-1.5">
                <Wallet className="h-3.5 w-3.5 text-orange-500" /> Saldo Disponível
              </span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-xl font-bold text-zinc-500">R$</span>
                <span className="text-4xl font-black tracking-tight text-foreground">
                  {formatBRL(balance)}
                </span>
              </div>
            </div>
            <p className="mt-4 text-[11px] text-muted-foreground font-semibold">
              Ganhos acumulados através de divulgações bem-sucedidas.
            </p>
          </div>

          {/* Pedidos (Sales) Card */}
          <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider flex items-center gap-1.5">
                <ShoppingCart className="h-3.5 w-3.5 text-zinc-500" /> Vendas Realizadas
              </span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-black tracking-tight text-foreground">
                  {stats.sales}
                </span>
                <span className="text-sm font-semibold text-zinc-500">pedidos</span>
              </div>
            </div>
            <p className="mt-4 text-[11px] text-muted-foreground font-semibold">
              Unidades vendidas: <span className="font-bold text-foreground">{stats.units}</span>
            </p>
          </div>

          {/* Ticket Médio Card */}
          <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider flex items-center gap-1.5">
                <TrendingUp className="h-3.5 w-3.5 text-zinc-500" /> Comissão Média
              </span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-xl font-bold text-zinc-500">R$</span>
                <span className="text-4xl font-black tracking-tight text-foreground">
                  {formatBRL(ticketMedio)}
                </span>
              </div>
            </div>
            <p className="mt-4 text-[11px] text-muted-foreground font-semibold">
              Média de comissão recebida por pedido.
            </p>
          </div>

          {/* Visitors / Conversion Card */}
          <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-black tracking-wider flex items-center gap-1.5">
                <ArrowUpRight className="h-3.5 w-3.5 text-zinc-500" /> Cliques / Visualizações
              </span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-black tracking-tight text-foreground">
                  {stats.views}
                </span>
                <span className="text-xs font-semibold text-zinc-500">visualizações</span>
              </div>
            </div>
            <p className="mt-4 text-[11px] text-muted-foreground font-semibold">
              Conversão média estimada de cliques em vendas.
            </p>
          </div>
        </div>

        {/* Main Content split */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Column 1 & 2: Form & Security banner */}
          <div className="lg:col-span-2 space-y-6">
            {/* Withdrawal form card */}
            <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs">
              <h2 className="text-lg font-black text-foreground tracking-tight flex items-center gap-2 mb-4">
                <Wallet className="h-5 w-5 text-orange-500" /> Solicitar Saque via PIX
              </h2>

              {success && (
                <div className="mb-5 flex items-start gap-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 text-xs font-semibold">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-bold block text-sm">Saque solicitado com sucesso!</span>
                    <span className="mt-1 block">
                      O valor de R$ {formatBRL(successAmount)} foi encaminhado para processamento e
                      cairá na sua conta em até 2 dias úteis.
                    </span>
                  </div>
                </div>
              )}

              {!canWithdraw && (
                <div className="mb-5 flex items-start gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs font-semibold">
                  <AlertTriangle className="h-5 w-5 shrink-0 text-amber-600" />
                  <div>
                    <span className="font-bold">Saque Indisponível:</span> O saldo mínimo para
                    solicitar saque é de <b>R$ {formatBRL(MIN_SAQUE)}</b>. Faltam{" "}
                    <b>R$ {formatBRL(missingAmount)}</b>. Continue divulgando produtos no catálogo
                    para acumular mais comissões!
                  </div>
                </div>
              )}

              <form onSubmit={handleWithdrawRequest} className="space-y-4">
                {/* Amount input */}
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <label className="text-sm font-bold text-foreground">Valor a Sacar</label>
                    <span className="text-xs font-semibold text-muted-foreground">
                      Disponível: R$ {formatBRL(balance)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 focus-within:bg-white focus-within:ring-2 focus-within:ring-orange-500/15">
                    <span className="text-base font-black text-orange-500">R$</span>
                    <input
                      type="text"
                      required
                      disabled={!canWithdraw}
                      value={amount}
                      onChange={(e) => setAmount(e.target.value.replace(/[^0-9.,]/g, ""))}
                      placeholder="0,00"
                      className="w-full bg-transparent text-lg font-black outline-none disabled:opacity-50"
                    />
                  </div>
                  {canWithdraw && numericAmount > balance && (
                    <p className="mt-1 text-xs font-bold text-red-600 flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> Valor maior que o saldo disponível.
                    </p>
                  )}
                  {canWithdraw && numericAmount > 0 && numericAmount < MIN_SAQUE && (
                    <p className="mt-1 text-xs font-bold text-red-600 flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> O saque mínimo é de R${" "}
                      {formatBRL(MIN_SAQUE)}.
                    </p>
                  )}
                </div>

                {/* Pix Type and key */}
                <div className="grid gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1.5 block text-sm font-bold text-foreground">
                      Tipo de Chave
                    </label>
                    <select
                      value={pixType}
                      disabled={!canWithdraw}
                      onChange={(e) => setPixType(e.target.value)}
                      className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-3 text-sm text-foreground outline-none focus:bg-white focus:ring-2 focus:ring-orange-500/15"
                    >
                      <option value="cpf">CPF</option>
                      <option value="email">E-mail</option>
                      <option value="celular">Celular</option>
                      <option value="chave_aleatoria">Chave Aleatória</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="mb-1.5 block text-sm font-bold text-foreground">
                      Chave PIX destinatária
                    </label>
                    <input
                      type="text"
                      required
                      disabled={!canWithdraw}
                      value={pixKey}
                      onChange={(e) => setPixKey(e.target.value)}
                      placeholder={
                        pixType === "cpf"
                          ? "000.000.000-00"
                          : pixType === "celular"
                            ? "(00) 90000-0000"
                            : "Digite a chave PIX correspondente"
                      }
                      className="w-full rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-foreground outline-none focus:bg-white focus:ring-2 focus:ring-orange-500/15 disabled:opacity-50"
                    />
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={invalidAmount || !pixKey || loading}
                  className="flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-black uppercase tracking-widest text-white transition hover:opacity-95 active:scale-95 disabled:opacity-50 disabled:pointer-events-none shadow-lg shadow-orange-500/20 mt-4"
                  style={{ background: "linear-gradient(135deg, #FF8E42 0%, #EE4D2D 100%)" }}
                >
                  {loading ? (
                    <>
                      <Clock className="h-4 w-4 animate-spin" /> Processando...
                    </>
                  ) : (
                    <>
                      <Wallet className="h-4 w-4" /> Solicitar Saque PIX
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Quick tips about commissions */}
            <div className="rounded-2xl border border-zinc-200 bg-zinc-50/50 p-5 space-y-3">
              <h3 className="text-sm font-black text-foreground uppercase tracking-wider flex items-center gap-2">
                <Lock className="h-4 w-4 text-zinc-500" /> Termos de Faturamento e Segurança
              </h3>
              <ul className="text-xs text-muted-foreground space-y-2 list-disc list-inside">
                <li>Os saques são faturados diretamente para sua conta bancária PIX cadastrada.</li>
                <li>
                  Por questões de segurança contra fraudes em plataformas parceiras, o tempo de
                  auditoria de cliques leva em torno de{" "}
                  <span className="font-semibold text-foreground">24 a 48 horas úteis</span>.
                </li>
                <li>
                  As comissões de produtos reembolsados ou cancelados na Shopee são deduzidas
                  automaticamente do balanço geral.
                </li>
              </ul>
            </div>
          </div>

          {/* Column 3: History list */}
          <div className="space-y-6">
            <div className="rounded-2xl border border-zinc-200 bg-card p-6 shadow-xs">
              <h2 className="text-lg font-black text-foreground tracking-tight flex items-center gap-2 mb-4">
                <Clock className="h-5 w-5 text-zinc-500" /> Histórico de Saques
              </h2>

              <div className="space-y-3">
                {history.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-6">
                    Nenhum saque solicitado ainda.
                  </p>
                ) : (
                  history.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-xl border border-zinc-100 bg-zinc-50/50 p-4 flex items-center gap-2.5 text-xs font-semibold text-zinc-700"
                    >
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                      <span>
                        Saque de{" "}
                        <strong className="text-[#EE4D2D] font-bold">
                          R$ {formatBRL(item.amount)}
                        </strong>{" "}
                        realizado no dia {item.date.split(" ")[0]}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
