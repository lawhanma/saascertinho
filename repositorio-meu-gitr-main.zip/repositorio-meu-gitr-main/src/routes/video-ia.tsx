import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import {
  Video,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Copy,
  Check,
  Search,
  Coins,
  RefreshCw,
  Sliders,
  Type,
  Music,
  Share2,
  Tv,
  ExternalLink,
  Flame,
  Award,
  Maximize2,
  Heart,
  MessageCircle,
  Bookmark,
  ChevronRight,
  Eye,
  AlertCircle,
  FileText,
  Upload,
  CheckCircle2,
  VideoOff,
  X,
} from "lucide-react";
import { useEffect, useState, useRef, useMemo } from "react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  getAICredits,
  spendAICredits,
  setAICreditsDirectly,
  formatBRL,
  addStats,
} from "@/lib/salesStore";
import { SUPPLIERS } from "@/data/suppliers";
import type { Product } from "@/data/suppliers";
import { toast } from "sonner";

export const Route = createFileRoute("/video-ia")({
  component: VideoIAPage,
  head: () => ({
    meta: [
      { title: "Gerar Vídeos com IA — ApexFinder" },
      {
        name: "description",
        content:
          "Crie vídeos virais de alta conversão para seus produtos de forma totalmente automática usando Inteligência Artificial.",
      },
    ],
  }),
});

const VIDEO_TEMPLATES = [
  {
    id: "viral",
    name: "Achadinho Viral (TikTok Style)",
    emoji: "🔥",
    description: "Foco em curiosidade extrema, gatilho de escassez e apelo visual rápido.",
    getScript: (p: Product) => [
      "Olha só esse achadinho que acabei de encontrar! 😱",
      `Sério, esse ${p.name} vai facilitar muito o seu dia a dia.`,
      `${p.description}.`,
      "E o melhor de tudo? Ele está com um desconto surreal hoje!",
      "Comente 'EU QUERO' ou clique no link da bio para garantir o seu antes que acabe! 🛒🏃‍♂️",
    ],
  },
  {
    id: "review",
    name: "Review Honesto (Problema vs Solução)",
    emoji: "⭐",
    description: "Abordagem com autoridade, quebra de objeções e depoimento sincero.",
    getScript: (p: Product) => [
      "Se você sofre com problemas no seu dia a dia, você precisa ver esse vídeo.",
      `Esse é o ${p.name}, a solução definitiva que eu testei e aprovei.`,
      `Ele tem ${p.description} de forma totalmente prática.`,
      "Eu garanto: o custo-benefício dele é simplesmente imbatível.",
      `Quer o link promocional com frete grátis? Clique no meu perfil e aproveite! 🔥`,
    ],
  },
  {
    id: "reasons",
    name: "3 Motivos para Ter Esse Produto",
    emoji: "🎯",
    description: "Lista de benefícios diretos, didático e de altíssima conversão.",
    getScript: (p: Product) => [
      `3 motivos para você ter um ${p.name} ainda hoje!`,
      "Primeiro: ele é perfeito para quem busca otimizar tempo e ter mais praticidade.",
      `Segundo: ele resolve tudo isso porque ${p.description.toLowerCase()}.`,
      `Terceiro: está em promoção especial por apenas R$ ${formatBRL(p.price)}!`,
      "Gostou? Me segue para mais dicas e garanta o seu no link exclusivo da minha bio! 🚀",
    ],
  },
];

const VOICES = [
  { id: "v_female_1", name: "Júlia (Voz Enérgica / TikTok)", gender: "Feminina", speed: "1.1x" },
  { id: "v_male_1", name: "Thiago (Voz Grave / Comercial)", gender: "Masculina", speed: "1.0x" },
  { id: "v_female_2", name: "Mariana (Voz Doce / Amigável)", gender: "Feminina", speed: "1.05x" },
  { id: "v_funny", name: "Galvão IA (Voz Emocionante)", gender: "Masculina", speed: "1.2x" },
];

const MUSICS = [
  { id: "m_upbeat", name: "TikTok Upbeat (Viral)", vibe: "Enérgica", volume: "Média" },
  { id: "m_lofi", name: "Lofi Aesthetics (Relaxante)", vibe: "Calma", volume: "Baixa" },
  { id: "m_cinematic", name: "Cinematic Epic (Inspiradora)", vibe: "Grandiosa", volume: "Média" },
  { id: "m_none", name: "Sem música (Apenas Voz)", vibe: "Silencioso", volume: "Muda" },
];

function VideoIAPage() {
  const navigate = useNavigate();
  const [credits, setCredits] = useState<number>(100);
  const [generating, setGenerating] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [currentStep, setCurrentStep] = useState<string>("");
  const [hasVideo, setHasVideo] = useState<boolean>(false);

  // Automatically sync credits / set unlimited state for video generation
  useEffect(() => {
    setCredits(100);
  }, []);

  // All available products
  const allProducts = useMemo(() => {
    return SUPPLIERS.flatMap((s) => s.products);
  }, []);

  // Selected config state
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("viral");
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>("v_female_1");
  const [selectedMusicId, setSelectedMusicId] = useState<string>("m_upbeat");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("Todos");

  // Editable script paragraphs (each line of the script)
  const [editableScript, setEditableScript] = useState<string[]>([]);
  const [isEditingScript, setIsEditingScript] = useState<boolean>(false);

  // Video playback states
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playProgress, setPlayProgress] = useState<number>(0);
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [simulatedLikes, setSimulatedLikes] = useState<number>(2340);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [videoHasError, setVideoHasError] = useState<boolean>(false);
  const [showCleanVideoModal, setShowCleanVideoModal] = useState<boolean>(false);

  // Custom uploaded video states
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);
  const [uploadedVideoFile, setUploadedVideoFile] = useState<File | null>(null);

  // Clean up object URL when component unmounts or uploadedVideoUrl changes
  useEffect(() => {
    return () => {
      if (uploadedVideoUrl) {
        URL.revokeObjectURL(uploadedVideoUrl);
      }
    };
  }, [uploadedVideoUrl]);

  const playbackTimerRef = useRef<NodeJS.Timeout | null>(null);
  const generationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Initialize selected product
  useEffect(() => {
    if (!selectedProductId && allProducts.length > 0) {
      setSelectedProductId(allProducts[0].id);
    }
  }, [selectedProductId, allProducts]);

  // Product helper
  const activeProduct = useMemo(() => {
    return allProducts.find((p) => p.id === selectedProductId) || allProducts[0];
  }, [selectedProductId, allProducts]);

  // Update script whenever product or template changes
  useEffect(() => {
    if (activeProduct) {
      const template =
        VIDEO_TEMPLATES.find((t) => t.id === selectedTemplateId) || VIDEO_TEMPLATES[0];
      setEditableScript(template.getScript(activeProduct));
      // Reset play status when configuration changes
      setIsPlaying(false);
      setPlayProgress(0);
      setActiveSlideIndex(0);
      setVideoHasError(false);
    }
  }, [activeProduct, selectedTemplateId]);

  // Handle credits initial sync
  useEffect(() => {
    setCredits(getAICredits());
    const handleStatsChange = () => {
      setCredits(getAICredits());
    };
    window.addEventListener("apex-stats-changed", handleStatsChange);
    window.addEventListener("storage", handleStatsChange);
    return () => {
      window.removeEventListener("apex-stats-changed", handleStatsChange);
      window.removeEventListener("storage", handleStatsChange);
    };
  }, []);

  // Filtered categories
  const categories = useMemo(() => {
    const list = new Set(SUPPLIERS.map((s) => s.category));
    return ["Todos", ...Array.from(list)];
  }, []);

  const filteredProducts = useMemo(() => {
    return allProducts.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());

      if (selectedCategory === "Todos") return matchesSearch;

      const supplier = SUPPLIERS.find((s) => s.products.some((prod) => prod.id === p.id));
      return matchesSearch && supplier?.category === selectedCategory;
    });
  }, [allProducts, searchQuery, selectedCategory]);

  // Handle generating video
  const startGeneratingVideo = () => {
    if (!activeProduct) {
      toast.error("Selecione um produto primeiro!");
      return;
    }

    setGenerating(true);
    setProgress(0);
    setHasVideo(false);
    setIsPlaying(false);
    setPlayProgress(0);
    setActiveSlideIndex(0);

    // Unlimited credits for video generation
    setCredits(100);

    const steps = [
      "Processando fotos e criativos visuais...",
      "Processando voz com Inteligência Artificial...",
      "Sintetizando áudio neural com roteiro otimizado...",
      "Sincronizando áudio de fundo e efeitos de vídeo...",
      "Renderizando efeitos visuais em resolução MP4 HD...",
      "Finalizando codificação com transições dinâmicas...",
    ];

    let currentPercent = 0;
    generationTimerRef.current = setInterval(() => {
      currentPercent += 2;
      setProgress(currentPercent);

      // Select step text
      const stepIdx = Math.min(Math.floor(currentPercent / 17), steps.length - 1);
      setCurrentStep(steps[stepIdx]);

      if (currentPercent >= 100) {
        if (generationTimerRef.current) clearInterval(generationTimerRef.current);

        setTimeout(() => {
          setGenerating(false);
          setHasVideo(true);
          setIsPlaying(true);

          // Randomize simulation stats
          setSimulatedLikes(Math.floor(Math.random() * 4500) + 1200);
          setIsLiked(false);

          // Add stats to global dashboard
          addStats({
            visitors: Math.floor(Math.random() * 90) + 60,
            views: Math.floor(Math.random() * 210) + 140,
            sales: 0,
            units: 0,
          });

          toast.success("Vídeo com IA gerado com sucesso! Iniciando reprodução.", {
            icon: <Video className="h-4 w-4 text-primary" />,
          });
        }, 500);
      }
    }, 150); // Total 7.5 seconds generation time for great UX
  };

  // Simulated Video Player Playback Engine
  useEffect(() => {
    const isIframe = activeProduct?.id === "cosmeticos-1" && !uploadedVideoUrl;
    if (
      !hasVideo ||
      !isPlaying ||
      editableScript.length === 0 ||
      uploadedVideoUrl ||
      (activeProduct?.id === "cosmeticos-1" && !videoHasError && !isIframe)
    ) {
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
      return;
    }

    // A simulated reels video is, say, 15 seconds long (3 seconds per slide for 5 slides)
    const durationPerSlideMs = 3200;
    const totalDurationMs = durationPerSlideMs * editableScript.length;
    const tickIntervalMs = 100;

    playbackTimerRef.current = setInterval(() => {
      setPlayProgress((prev) => {
        const next = prev + (tickIntervalMs / totalDurationMs) * 100;
        if (next >= 100) {
          // Loop video automatically
          setActiveSlideIndex(0);
          return 0;
        }

        // Determine active slide index based on current progress percentage
        const calculatedIndex = Math.min(
          Math.floor((next / 100) * editableScript.length),
          editableScript.length - 1,
        );
        setActiveSlideIndex(calculatedIndex);

        return next;
      });
    }, tickIntervalMs);

    return () => {
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
    };
  }, [isPlaying, hasVideo, editableScript, activeProduct?.id, videoHasError, uploadedVideoUrl]);

  // HTML5 Video Play/Pause sync
  useEffect(() => {
    const video = videoRef.current;
    const isIframe = activeProduct?.id === "cosmeticos-1" && !uploadedVideoUrl;
    const isUsingRealVideo =
      uploadedVideoUrl || (activeProduct?.id === "cosmeticos-1" && !videoHasError && !isIframe);
    if (video && isUsingRealVideo && hasVideo) {
      if (isPlaying) {
        video.play().catch((err) => {
          console.log("Video auto-play blocked or error: ", err);
        });
      } else {
        video.pause();
      }
    }
  }, [isPlaying, activeProduct?.id, hasVideo, videoHasError, uploadedVideoUrl]);

  // HTML5 Video Mute sync
  useEffect(() => {
    const video = videoRef.current;
    const isIframe = activeProduct?.id === "cosmeticos-1" && !uploadedVideoUrl;
    const isUsingRealVideo =
      uploadedVideoUrl || (activeProduct?.id === "cosmeticos-1" && !videoHasError && !isIframe);
    if (video && isUsingRealVideo) {
      video.muted = isMuted;
    }
  }, [isMuted, activeProduct?.id, videoHasError, uploadedVideoUrl]);

  const handlePlayPause = () => {
    setIsPlaying((prev) => !prev);
  };

  const handleRestart = () => {
    setIsPlaying(true);
    setPlayProgress(0);
    setActiveSlideIndex(0);
    const isIframe = activeProduct?.id === "cosmeticos-1" && !uploadedVideoUrl;
    const isUsingRealVideo =
      uploadedVideoUrl || (activeProduct?.id === "cosmeticos-1" && !videoHasError && !isIframe);
    if (videoRef.current && isUsingRealVideo) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  };

  const replenishCredits = () => {
    navigate({ to: "/quero-mais-creditos" });
  };

  const handleCopyVideoLink = () => {
    const fakeLink = `https://apexf.in/v/${activeProduct?.id || "product"}`;
    navigator.clipboard.writeText(fakeLink);
    toast.success("Link do vídeo copiado para divulgar nas suas redes!");
  };

  const handleDownloadVideo = () => {
    toast.info("Processando download do MP4 otimizado...", { duration: 1500 });
    setTimeout(() => {
      // Build a simple fake text download or mock alert
      const a = document.createElement("a");
      a.href = activeProduct?.image || "#";
      a.download = `video-ia-${activeProduct?.id}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast.success("Download do criativo de vídeo concluído!");
    }, 1800);
  };

  // Script change handler
  const handleSaveScript = () => {
    setIsEditingScript(false);
    handleRestart();
    toast.success("Roteiro do vídeo atualizado com sucesso!");
  };

  const handleScriptLineChange = (index: number, value: string) => {
    setEditableScript((prev) => {
      const next = [...prev];
      next[index] = value;
      return next;
    });
  };

  return (
    <AppShell>
      <div className="container mx-auto max-w-6xl px-4 py-8 md:py-12">
        {/* Header */}
        <div className="mb-8 flex flex-col gap-3">
          <div className="inline-flex max-w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            <Video className="h-3.5 w-3.5 animate-pulse" /> Criador Inteligente
          </div>
          <h1 className="text-3xl font-black tracking-tight text-foreground md:text-4xl">
            Gerar Vídeos com IA
          </h1>
          <p className="text-sm text-muted-foreground">
            Transforme instantaneamente qualquer produto em vídeos de alta conversão para o TikTok,
            Reels, Kwai e Shorts.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-12 items-start">
          {/* COLUMN 1: PRODUCT PICKER & CONFIGS (8 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Step 1: Selector */}
            <div
              className="rounded-3xl border border-border bg-card p-6 space-y-5"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary font-black text-xs">
                    1
                  </span>
                  <h2 className="text-base font-black text-foreground">Escolha o Produto</h2>
                </div>
                {activeProduct && (
                  <span className="text-[10px] uppercase font-black tracking-widest text-primary bg-primary/10 px-2.5 py-1 rounded-full border border-primary/20">
                    Selecionado
                  </span>
                )}
              </div>

              {/* Selector scroll + search bar */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar produto..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 text-xs h-9 bg-muted/30"
                    />
                  </div>
                  <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 rounded-full text-[11px] font-bold border transition-all whitespace-nowrap ${
                          selectedCategory === cat
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-muted/40 border-border text-muted-foreground hover:bg-muted"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[160px] overflow-y-auto pr-1 border border-border/80 rounded-2xl bg-muted/10 p-2.5">
                  {filteredProducts.map((p) => {
                    const isSelected = p.id === selectedProductId;
                    return (
                      <div
                        key={p.id}
                        onClick={() => setSelectedProductId(p.id)}
                        className={`flex items-center gap-3 p-2 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? "bg-primary/5 border-primary ring-1 ring-primary"
                            : "bg-card border-border hover:bg-muted/30"
                        }`}
                      >
                        <img
                          src={p.image}
                          alt={p.name}
                          className="h-10 w-10 rounded-lg object-cover bg-muted shrink-0 border border-border/40"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0 flex-1 text-left">
                          <h4 className="text-[11px] font-bold text-foreground truncate leading-normal">
                            {p.name}
                          </h4>
                          <p className="text-[10px] font-black text-primary mt-0.5">
                            R$ {formatBRL(p.price)}
                          </p>
                        </div>
                        <div
                          className={`h-4 w-4 rounded-full border flex items-center justify-center shrink-0 ${
                            isSelected
                              ? "bg-primary border-primary text-primary-foreground"
                              : "border-muted-foreground/30 bg-card"
                          }`}
                        >
                          {isSelected && <Check className="h-2.5 w-2.5" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Step 2: Custom configs */}
            <div
              className="rounded-3xl border border-border bg-card p-6 space-y-6"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="flex items-center gap-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary font-black text-xs">
                  2
                </span>
                <h2 className="text-base font-black text-foreground">Configurações de Geração</h2>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                {/* Voice Selector */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-foreground flex items-center gap-1.5">
                    <Type className="h-4 w-4 text-primary" />
                    Voz Narradora (IA)
                  </label>
                  <div className="grid gap-2">
                    {VOICES.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVoiceId(v.id)}
                        className={`flex justify-between items-center px-3.5 py-2.5 rounded-xl border text-left text-xs transition-all ${
                          selectedVoiceId === v.id
                            ? "bg-primary/5 border-primary font-bold text-foreground"
                            : "bg-card border-border text-muted-foreground hover:bg-muted/40"
                        }`}
                      >
                        <div>
                          <p className="font-semibold text-foreground">{v.name}</p>
                          <p className="text-[10px] text-muted-foreground">Velocidade: {v.speed}</p>
                        </div>
                        <span className="text-[10px] uppercase font-bold bg-muted px-2 py-0.5 rounded border">
                          {v.gender}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Music Vibe */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-foreground flex items-center gap-1.5">
                    <Music className="h-4 w-4 text-primary" />
                    Música de Fundo (Viral)
                  </label>
                  <div className="grid gap-2">
                    {MUSICS.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setSelectedMusicId(m.id)}
                        className={`flex justify-between items-center px-3.5 py-2.5 rounded-xl border text-left text-xs transition-all ${
                          selectedMusicId === m.id
                            ? "bg-primary/5 border-primary font-bold text-foreground"
                            : "bg-card border-border text-muted-foreground hover:bg-muted/40"
                        }`}
                      >
                        <div>
                          <p className="font-semibold text-foreground">{m.name}</p>
                          <p className="text-[10px] text-muted-foreground">Volume: {m.volume}</p>
                        </div>
                        <span className="text-[10px] uppercase font-bold bg-muted px-2 py-0.5 rounded border">
                          {m.vibe}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Template Selectors */}
              <div className="space-y-2.5 pt-2 border-t border-border">
                <label className="text-xs font-bold text-foreground flex items-center gap-1.5">
                  <Sliders className="h-4 w-4 text-primary" />
                  Modelo de Roteiro / Roteirização IA
                </label>
                <div className="grid gap-3 sm:grid-cols-3">
                  {VIDEO_TEMPLATES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTemplateId(t.id)}
                      className={`flex flex-col p-3 rounded-2xl border text-left transition-all justify-between gap-1.5 ${
                        selectedTemplateId === t.id
                          ? "bg-primary/5 border-primary font-bold text-foreground ring-1 ring-primary"
                          : "bg-card border-border text-muted-foreground hover:bg-muted/30"
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm">{t.emoji}</span>
                        <h4 className="text-[11px] font-bold text-foreground leading-snug">
                          {t.name}
                        </h4>
                      </div>
                      <p className="text-[9px] text-muted-foreground leading-normal mt-1 leading-snug">
                        {t.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Video Upload Section */}
              <div className="space-y-2.5 pt-3.5 border-t border-border">
                <label className="text-xs font-bold text-foreground flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Video className="h-4 w-4 text-primary" />
                    Vídeo de Vendas / Criativo Próprio (Opcional)
                  </span>
                  {uploadedVideoUrl && (
                    <button
                      onClick={() => {
                        setUploadedVideoUrl(null);
                        setUploadedVideoFile(null);
                        setVideoHasError(false);
                        toast.info("Vídeo próprio removido. Usando visual padrão do produto.");
                      }}
                      className="text-[10px] text-destructive hover:underline font-bold"
                    >
                      Remover Vídeo
                    </button>
                  )}
                </label>

                <div className="flex flex-col gap-3">
                  {uploadedVideoUrl ? (
                    <div className="flex items-center gap-2.5 p-3 rounded-2xl border border-primary/25 bg-primary/5">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        <CheckCircle2 className="h-4 w-4 animate-bounce" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-[11px] font-bold text-foreground truncate">
                          {uploadedVideoFile?.name || "Vídeo carregado com sucesso!"}
                        </p>
                        <p className="text-[9px] text-muted-foreground leading-normal mt-0.5">
                          Pronto! O simulador móvel vai reproduzir seu vídeo assim que você clicar
                          em "Gerar Vídeo".
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="relative border border-dashed border-border hover:border-primary/50 transition-all rounded-2xl p-4 text-center cursor-pointer bg-card/40 hover:bg-muted/40">
                      <input
                        type="file"
                        accept="video/mp4,video/webm,video/ogg,video/quicktime"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            if (file.size > 50 * 1024 * 1024) {
                              toast.error("O arquivo de vídeo deve ter menos de 50MB!");
                              return;
                            }
                            const url = URL.createObjectURL(file);
                            setUploadedVideoUrl(url);
                            setUploadedVideoFile(file);
                            setVideoHasError(false);
                            toast.success(
                              "Vídeo de produto carregado com sucesso! Clique em 'Gerar Vídeo de Vendas' para assistir no celular.",
                            );
                          }
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      <Upload className="h-5 w-5 text-muted-foreground mx-auto mb-1.5" />
                      <p className="text-[11px] font-bold text-foreground leading-normal">
                        Arraste ou clique para enviar o vídeo do seu celular/computador
                      </p>
                      <p className="text-[9px] text-muted-foreground mt-0.5 leading-normal">
                        Suporta arquivos MP4, WebM ou MOV (enviados via chat) de até 50MB
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* COLUMN 2: THE MOBILE SCREEN SIMULATOR (5 Cols) */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-6 lg:self-start">
            {/* IA Credits & Action Button */}
            <div className="grid gap-4 sm:grid-cols-2">
              {/* Credits Box */}
              <div
                className="rounded-3xl border border-border bg-card p-5 flex flex-col justify-between"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Coins className="h-4.5 w-4.5 text-primary" />
                      <span className="text-xs font-bold text-foreground">Créditos de IA</span>
                    </div>
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                      Ilimitado ♾️
                    </span>
                  </div>
                  <Progress value={100} className="h-2 bg-emerald-500/20 [&>div]:bg-emerald-500" />
                  <div className="flex justify-between text-[10px] font-semibold text-muted-foreground">
                    <span>Geração de vídeo liberada</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      Uso Ilimitado
                    </span>
                  </div>
                </div>
              </div>

              {/* CTA Button Box */}
              <div className="flex items-stretch">
                <Button
                  onClick={startGeneratingVideo}
                  disabled={generating}
                  size="lg"
                  className="w-full rounded-3xl font-black uppercase tracking-widest text-xs h-full flex flex-col justify-center items-center gap-1 bg-gradient-to-r from-primary via-orange-500 to-primary text-primary-foreground shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  <Sparkles className="h-5 w-5 animate-pulse" />
                  {generating ? "Criando Cenas..." : "Gerar Vídeo de Vendas"}
                  <span className="text-[8px] font-semibold opacity-90 uppercase tracking-widest mt-1">
                    Sem custo • Créditos Ilimitados
                  </span>
                </Button>
              </div>
            </div>

            {/* Generating Overlay state or Active Video view */}
            <div className="flex flex-col items-center">
              {/* Smartphone Frame Container */}
              <div
                className="relative bg-black w-[280px] h-[520px] rounded-[40px] border-[10px] border-zinc-800 shadow-2xl overflow-hidden flex flex-col justify-between"
                style={{ boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.75)" }}
              >
                {/* Speaker top notch */}
                <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-24 h-4 bg-zinc-800 rounded-full z-30 flex items-center justify-center">
                  <div className="w-2.5 h-2.5 rounded-full bg-zinc-900 absolute right-2" />
                </div>

                {/* BACKGROUND SCREEN CONTENT */}

                {/* STATE A: NO VIDEO GENERATED YET */}
                {!generating && !hasVideo && (
                  <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-zinc-400 space-y-4">
                    <div className="h-16 w-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500 animate-pulse">
                      <Tv className="h-8 w-8" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-zinc-200">Aguardando Criação</h3>
                      <p className="text-[11px] text-zinc-500 leading-relaxed mt-1">
                        Escolha um produto e clique no botão de gerar para processar seu vídeo
                        inteligente.
                      </p>
                    </div>
                  </div>
                )}

                {/* STATE B: GENERATING (LOADING STATUS COIL) */}
                {generating && (
                  <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-zinc-950 text-white space-y-6 relative">
                    <div className="absolute inset-0 bg-radial-gradient from-primary/10 via-transparent to-transparent opacity-55" />

                    <div className="relative flex items-center justify-center">
                      <div className="h-20 w-20 rounded-full border-4 border-dashed border-primary animate-spin" />
                      <Sparkles className="h-8 w-8 text-primary absolute animate-bounce" />
                    </div>

                    <div className="space-y-3 relative z-10">
                      <p className="text-xs font-black uppercase tracking-widest text-primary animate-pulse">
                        Sintetizando IA...
                      </p>
                      <Progress value={progress} className="h-2 bg-zinc-800 w-44 mx-auto" />
                      <p className="text-[10px] text-zinc-400 font-medium italic animate-pulse px-4 min-h-[2.5rem] leading-relaxed">
                        "{currentStep}"
                      </p>
                    </div>
                  </div>
                )}

                {/* STATE C: ACTIVE PLAYABLE SIMULATED VIDEO PLAYER */}
                {hasVideo && activeProduct && (
                  <div className="flex-1 relative flex flex-col justify-between overflow-hidden bg-zinc-950">
                    {/* Active Product Image with zoom transition effect or real video */}
                    <div className="absolute inset-0 z-0">
                      {uploadedVideoUrl ||
                      (activeProduct.id === "cosmeticos-1" && !videoHasError) ? (
                        uploadedVideoUrl ? (
                          <video
                            ref={videoRef}
                            src={uploadedVideoUrl}
                            className="h-full w-full object-cover opacity-80"
                            autoPlay
                            loop
                            muted={isMuted}
                            playsInline
                            onError={() => {
                              toast.error(
                                "Erro ao carregar seu arquivo de vídeo. Usando imagem do produto.",
                              );
                            }}
                            onTimeUpdate={(e) => {
                              const video = e.currentTarget;
                              if (video.duration) {
                                const progress = (video.currentTime / video.duration) * 100;
                                setPlayProgress(progress);

                                const calculatedIndex = Math.min(
                                  Math.floor(
                                    (video.currentTime / video.duration) * editableScript.length,
                                  ),
                                  editableScript.length - 1,
                                );
                                setActiveSlideIndex(calculatedIndex);
                              }
                            }}
                          />
                        ) : activeProduct.id === "cosmeticos-1" ? (
                          <div
                            className="w-full h-full relative"
                            style={{ paddingTop: "177.77777777777777%" }}
                          >
                            <iframe
                              id="panda-1f1118da-4ef4-42dc-96a7-8e2c7a479b7e"
                              src="https://player-vz-3751d4f5-bee.tv.pandavideo.com.br/embed/?v=1f1118da-4ef4-42dc-96a7-8e2c7a479b7e"
                              style={{
                                border: "none",
                                position: "absolute",
                                top: 0,
                                left: 0,
                                width: "100%",
                                height: "100%",
                              }}
                              allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture"
                              allowFullScreen={true}
                              fetchPriority="high"
                              className="w-full h-full"
                            />
                          </div>
                        ) : (
                          <video
                            ref={videoRef}
                            src="https://assets.mixkit.co/videos/preview/mixkit-spraying-perfume-from-a-bottle-34354-large.mp4"
                            className="h-full w-full object-cover opacity-80"
                            autoPlay
                            loop
                            muted={isMuted}
                            playsInline
                            onError={() => {
                              setVideoHasError(true);
                            }}
                            onTimeUpdate={(e) => {
                              const video = e.currentTarget;
                              if (video.duration) {
                                const progress = (video.currentTime / video.duration) * 100;
                                setPlayProgress(progress);

                                const calculatedIndex = Math.min(
                                  Math.floor(
                                    (video.currentTime / video.duration) * editableScript.length,
                                  ),
                                  editableScript.length - 1,
                                );
                                setActiveSlideIndex(calculatedIndex);
                              }
                            }}
                          />
                        )
                      ) : (
                        <img
                          src={activeProduct.image}
                          alt={activeProduct.name}
                          className={`h-full w-full object-cover opacity-80 transition-transform duration-1000 ${
                            isPlaying ? "scale-110" : "scale-100"
                          }`}
                          style={{
                            transformOrigin: "center",
                            filter: "brightness(0.7) contrast(1.1)",
                          }}
                          referrerPolicy="no-referrer"
                        />
                      )}
                      {/* Gradient bottom and top overlays */}
                      <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-transparent to-black/85 z-10" />
                    </div>

                    {/* Top bar */}
                    <div className="relative z-20 flex justify-between items-center p-4 pt-6 text-white text-[10px] font-bold bg-gradient-to-b from-black/50 to-transparent">
                      <span className="flex items-center gap-1 text-primary">
                        <Flame className="h-3.5 w-3.5 fill-current animate-pulse" />
                        AO VIVO
                      </span>
                      <div className="flex gap-2">
                        <span>Seguindo</span>
                        <span className="border-b-2 border-white pb-0.5">Para Você</span>
                      </div>
                      <span className="opacity-50">Apex IA</span>
                    </div>

                    {/* Middle Interactive Area for playback control */}
                    <div
                      className={`flex-1 relative z-20 flex items-center justify-center cursor-pointer ${
                        activeProduct.id === "cosmeticos-1" && !uploadedVideoUrl
                          ? "pointer-events-none"
                          : ""
                      }`}
                      onClick={handlePlayPause}
                    >
                      {!isPlaying &&
                        !(activeProduct.id === "cosmeticos-1" && !uploadedVideoUrl) && (
                          <div className="h-14 w-14 rounded-full bg-black/60 border border-white/20 flex items-center justify-center text-white backdrop-blur-xs scale-110 transition-all">
                            <Play className="h-6 w-6 fill-current ml-1" />
                          </div>
                        )}
                    </div>

                    {/* DYNAMIC SUBTITLES / CAPTIONS OVERLAY (NEON REELS STYLE) */}
                    {activeProduct.id !== "cosmeticos-1" && (
                      <div className="relative z-20 px-4 text-center pb-2.5">
                        <div className="bg-black/60 backdrop-blur-xs px-3 py-2 rounded-2xl border border-white/10 min-h-[70px] flex items-center justify-center max-w-[240px] mx-auto shadow-xl">
                          <p className="text-xs font-black text-yellow-300 uppercase tracking-wide leading-relaxed animate-fade-in text-shadow-sm shadow-black">
                            {editableScript[activeSlideIndex] || ""}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* BOTTOM DETAILS & SOCIAL OVERLAY RETAIL INFO */}
                    <div className="relative z-20 p-4 pt-0 text-white flex justify-between items-end gap-2 bg-gradient-to-t from-black/80 to-transparent">
                      <div className="flex-1 space-y-2 text-left">
                        {/* Profile identifier */}
                        <div className="flex items-center gap-1.5">
                          <div className="h-6 w-6 rounded-full bg-primary border border-white flex items-center justify-center font-bold text-[9px]">
                            AP
                          </div>
                          <span className="text-[11px] font-black truncate max-w-[120px]">
                            @achadinhos.apex
                          </span>
                        </div>

                        {/* Description */}
                        <p className="text-[10px] text-zinc-300 line-clamp-2 leading-relaxed">
                          🛒 {activeProduct.name} - Preço incrível de R${" "}
                          {formatBRL(activeProduct.price)}! Veja o link no perfil.
                        </p>

                        {/* Sound Vibe bar indicator */}
                        <div className="flex items-center gap-1.5 text-[9px] text-zinc-400 font-semibold bg-zinc-900/60 p-1.5 rounded-lg w-fit border border-zinc-800/50">
                          <Music className="h-3 w-3 shrink-0 text-primary animate-spin" />
                          <span className="truncate max-w-[100px]">
                            {MUSICS.find((m) => m.id === selectedMusicId)?.name || "TikTok Sound"}
                          </span>
                        </div>
                      </div>

                      {/* Right Hand Interaction Sidebar icons (Heart, Comment, Share) */}
                      <div className="flex flex-col items-center gap-3.5 text-white shrink-0 z-30">
                        {/* Profile add button */}
                        <div className="relative">
                          <img
                            src={activeProduct.image}
                            alt="product thumbnail"
                            className="h-7 w-7 rounded-full border border-white object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-red-500 rounded-full h-3.5 w-3.5 flex items-center justify-center font-bold text-[8px] border border-white">
                            +
                          </span>
                        </div>

                        {/* Likes */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsLiked((prev) => !prev);
                            setSimulatedLikes((v) => (isLiked ? v - 1 : v + 1));
                          }}
                          className="flex flex-col items-center"
                        >
                          <div
                            className={`h-8 w-8 rounded-full flex items-center justify-center bg-black/40 backdrop-blur-xs border border-white/10 ${
                              isLiked ? "text-red-500 scale-110" : "text-white"
                            } transition-all`}
                          >
                            <Heart className={`h-4.5 w-4.5 ${isLiked ? "fill-current" : ""}`} />
                          </div>
                          <span className="text-[9px] font-bold mt-1">
                            {simulatedLikes.toLocaleString("pt-BR")}
                          </span>
                        </button>

                        {/* Comments */}
                        <div className="flex flex-col items-center">
                          <div className="h-8 w-8 rounded-full flex items-center justify-center bg-black/40 backdrop-blur-xs border border-white/10 text-white">
                            <MessageCircle className="h-4.5 w-4.5" />
                          </div>
                          <span className="text-[9px] font-bold mt-1">
                            {Math.round(simulatedLikes / 15)}
                          </span>
                        </div>

                        {/* Share / Mute */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsMuted((prev) => !prev);
                          }}
                          className="flex flex-col items-center"
                        >
                          <div className="h-8 w-8 rounded-full flex items-center justify-center bg-black/40 backdrop-blur-xs border border-white/10 text-white hover:text-primary transition-colors">
                            {isMuted ? (
                              <VolumeX className="h-4.5 w-4.5 text-destructive" />
                            ) : (
                              <Volume2 className="h-4.5 w-4.5" />
                            )}
                          </div>
                          <span className="text-[9px] font-bold mt-1">
                            {isMuted ? "Mudo" : "Som"}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Progress playback timeline scrubber */}
                    <div className="relative z-20 w-full h-1 bg-zinc-800">
                      <div
                        className="h-full bg-primary transition-all duration-100"
                        style={{ width: `${playProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Player Controllers below the device */}
              {hasVideo && (
                <div className="flex flex-col items-center gap-3 mt-4 w-[280px]">
                  <Button
                    onClick={() => setShowCleanVideoModal(true)}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-black uppercase tracking-wider text-xs h-10 rounded-xl flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all duration-200"
                  >
                    <Maximize2 className="h-4 w-4" />
                    Ver como ficou vídeo
                  </Button>

                  <div className="flex gap-2.5 items-center justify-center w-full">
                    <Button
                      onClick={handlePlayPause}
                      size="sm"
                      variant="outline"
                      className="h-8 rounded-full px-3 text-xs font-bold uppercase"
                    >
                      {isPlaying ? (
                        <Pause className="h-3.5 w-3.5" />
                      ) : (
                        <Play className="h-3.5 w-3.5 fill-current" />
                      )}
                    </Button>
                    <Button
                      onClick={handleRestart}
                      size="sm"
                      variant="outline"
                      className="h-8 rounded-full px-3 text-xs font-bold uppercase"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                    </Button>
                    <span className="text-[10px] text-muted-foreground font-semibold">
                      Slide {activeSlideIndex + 1} de {editableScript.length}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* SCRIPT EDITOR CARD */}
            {hasVideo && (
              <div
                className="rounded-3xl border border-border bg-card p-5 space-y-4"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-foreground">
                    <FileText className="h-4 w-4 text-primary" />
                    <span>Legendas e Roteiro IA</span>
                  </div>
                  {!isEditingScript ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setIsEditingScript(true)}
                      className="text-[10px] h-7 font-bold px-2.5"
                    >
                      Editar Roteiro
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      onClick={handleSaveScript}
                      className="text-[10px] h-7 font-bold px-2.5"
                    >
                      Salvar Alterações
                    </Button>
                  )}
                </div>

                <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                  {editableScript.map((line, idx) => (
                    <div key={idx} className="flex gap-2 items-center">
                      <span className="text-[10px] font-black text-muted-foreground bg-muted w-5 h-5 shrink-0 rounded-full flex items-center justify-center">
                        {idx + 1}
                      </span>
                      {isEditingScript ? (
                        <Input
                          value={line}
                          onChange={(e) => handleScriptLineChange(idx, e.target.value)}
                          className="text-xs h-8"
                        />
                      ) : (
                        <p
                          className={`text-xs p-2 rounded-xl flex-1 text-left ${
                            activeSlideIndex === idx
                              ? "bg-primary/10 border border-primary/20 text-foreground font-bold"
                              : "bg-muted/40 border border-transparent text-muted-foreground"
                          }`}
                        >
                          {line}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* VIDEO EXPORT CONTROLLER CARD */}
            {hasVideo && (
              <div
                className="rounded-3xl border border-border bg-card p-5 grid grid-cols-2 gap-3"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <Button
                  onClick={handleDownloadVideo}
                  size="lg"
                  className="w-full font-bold uppercase tracking-wider text-xs h-11"
                  variant="secondary"
                >
                  <Download className="mr-1.5 h-4 w-4" /> Baixar MP4 HD
                </Button>
                <Button
                  onClick={handleCopyVideoLink}
                  size="lg"
                  className="w-full font-bold uppercase tracking-wider text-xs h-11"
                >
                  <Share2 className="mr-1.5 h-4 w-4" /> Copiar Link
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Informative info footer row */}
        <div
          className="mt-8 rounded-3xl border border-border bg-card p-6"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-foreground">
                Distribuição Inteligente Ativada
              </h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Nossos vídeos com IA são formatados nativamente com aspect ratio 9:16 vertical,
                prontos para impulsionar o algoritmo orgânico do TikTok, Shorts e Reels e converter
                telespectadores em compradores.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <span className="inline-flex items-center gap-1 rounded-full border border-border bg-muted/30 px-3 py-1 text-[11px] font-bold text-muted-foreground">
                <Check className="h-3 w-3 text-success shrink-0" />
                Renderização 60FPS
              </span>
              <span className="inline-flex items-center gap-1 rounded-full border border-border bg-muted/30 px-3 py-1 text-[11px] font-bold text-muted-foreground">
                <Check className="h-3 w-3 text-success shrink-0" />
                Voz Neural Ativa
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* CLEAN FULL-SCREEN VIDEO VIEW MODAL */}
      {showCleanVideoModal && activeProduct && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-4">
          {/* Close button top right */}
          <button
            onClick={() => setShowCleanVideoModal(false)}
            className="absolute top-4 right-4 text-white hover:text-red-500 bg-white/10 hover:bg-white/20 p-2.5 rounded-full transition-all duration-200 z-50 flex items-center justify-center shadow-lg"
            title="Fechar"
          >
            <X className="h-6 w-6" />
          </button>

          {/* Clean Container for the Video - absolutely NO clutter, perfect for live streams */}
          <div className="w-full max-w-[360px] aspect-[9/16] bg-black rounded-3xl overflow-hidden shadow-2xl border border-zinc-800 flex items-center justify-center relative">
            {uploadedVideoUrl || (activeProduct.id === "cosmeticos-1" && !videoHasError) ? (
              uploadedVideoUrl ? (
                <video
                  src={uploadedVideoUrl}
                  className="w-full h-full object-cover"
                  autoPlay
                  controls
                  loop
                  playsInline
                />
              ) : activeProduct.id === "cosmeticos-1" ? (
                <div
                  className="w-full h-full relative"
                  style={{ paddingTop: "177.77777777777777%" }}
                >
                  <iframe
                    id="panda-1f1118da-4ef4-42dc-96a7-8e2c7a479b7e"
                    src="https://player-vz-3751d4f5-bee.tv.pandavideo.com.br/embed/?v=1f1118da-4ef4-42dc-96a7-8e2c7a479b7e"
                    style={{
                      border: "none",
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                    }}
                    allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture"
                    allowFullScreen={true}
                    fetchPriority="high"
                    className="w-full h-full"
                  />
                </div>
              ) : (
                <video
                  src="https://assets.mixkit.co/videos/preview/mixkit-spraying-perfume-from-a-bottle-34354-large.mp4"
                  className="w-full h-full object-cover"
                  autoPlay
                  controls
                  loop
                  playsInline
                />
              )
            ) : (
              <img
                src={activeProduct.image}
                alt={activeProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            )}
          </div>

          {/* Action guidance footer */}
          <div className="mt-5 text-center max-w-sm">
            <p className="text-zinc-400 text-xs font-semibold">
              Vídeo em alta definição para transmissão e apresentação ao vivo.
            </p>
            <Button
              onClick={() => setShowCleanVideoModal(false)}
              variant="outline"
              size="sm"
              className="mt-3 text-white border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-xs rounded-xl px-4 font-bold"
            >
              Voltar ao Editor
            </Button>
          </div>
        </div>
      )}
    </AppShell>
  );
}
