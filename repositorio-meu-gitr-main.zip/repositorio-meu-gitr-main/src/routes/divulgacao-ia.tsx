import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import {
  Sparkles,
  Share2,
  CheckCircle,
  Zap,
  Coins,
  RefreshCw,
  Play,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  Check,
  ShoppingBag,
} from "lucide-react";
import { useEffect, useState, useRef, useMemo } from "react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  addCommission,
  formatBRL,
  getAICredits,
  spendAICredits,
  setAICreditsDirectly,
  addStats,
} from "@/lib/salesStore";
import { SUPPLIERS } from "@/data/suppliers";
import type { Product } from "@/data/suppliers";
import { toast } from "sonner";

export const Route = createFileRoute("/divulgacao-ia")({
  component: DivulgacaoIAPage,
  head: () => ({
    meta: [
      { title: "Divulgação com IA — ApexFinder" },
      {
        name: "description",
        content:
          "Divulgue seus produtos de forma automática em todas as redes sociais usando Inteligência Artificial.",
      },
    ],
  }),
});

const SOCIAL_NETWORKS = [
  { name: "Kwai", color: "bg-[#FF5000]/10 text-[#FF5000] border-[#FF5000]/20" },
  { name: "TikTok", color: "bg-foreground/10 text-foreground border-foreground/20" },
  { name: "Facebook", color: "bg-[#1877F2]/10 text-[#1877F2] border-[#1877F2]/20" },
  { name: "WhatsApp", color: "bg-[#25D366]/10 text-[#25D366] border-[#25D366]/20" },
  { name: "Instagram", color: "bg-[#E1306C]/10 text-[#E1306C] border-[#E1306C]/20" },
  { name: "Twitter", color: "bg-[#1DA1F2]/10 text-[#1DA1F2] border-[#1DA1F2]/20" },
];

function DivulgacaoIAPage() {
  const navigate = useNavigate();
  const [credits, setCredits] = useState<number>(100);
  const [sharing, setSharing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [currentStep, setCurrentStep] = useState<string>("");
  const [showResults, setShowResults] = useState<boolean>(false);
  const [results, setResults] = useState<{ sales: number; commission: number } | null>(null);

  // Automatically redirect if credits are 0 on load or state updates
  useEffect(() => {
    const currentCredits = getAICredits();
    if (currentCredits <= 0) {
      navigate({ to: "/quero-mais-creditos" });
    }
  }, [navigate]);

  // All available products from our supplier base
  const allProducts = useMemo(() => {
    return SUPPLIERS.flatMap((s) => s.products);
  }, []);

  // Selection, search & categories
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("Todos");

  // Dynamically compile categories from suppliers
  const categories = useMemo(() => {
    const list = new Set(SUPPLIERS.map((s) => s.category));
    return ["Todos", ...Array.from(list)];
  }, []);

  // Default to first product if none is selected
  useEffect(() => {
    if (!selectedProductId && allProducts.length > 0) {
      setSelectedProductId(allProducts[0].id);
    }
  }, [selectedProductId, allProducts]);

  const activeProduct = useMemo(() => {
    return allProducts.find((p) => p.id === selectedProductId) || allProducts[0];
  }, [selectedProductId, allProducts]);

  // Filtered products list
  const filteredProducts = useMemo(() => {
    return allProducts.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());

      if (selectedCategory === "Todos") return matchesSearch;

      const supplier = SUPPLIERS.find((s) => s.products.some((prod) => prod.id === p.id));
      return matchesSearch && supplier?.category === selectedCategory;
    });
  }, [allProducts, searchQuery, selectedCategory]);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Initial load
    setCredits(getAICredits());

    // Listen to changes to keep sync
    const handleStatsChange = () => {
      setCredits(getAICredits());
    };
    window.addEventListener("apex-stats-changed", handleStatsChange);
    window.addEventListener("storage", handleStatsChange);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      window.removeEventListener("apex-stats-changed", handleStatsChange);
      window.removeEventListener("storage", handleStatsChange);
    };
  }, []);

  // Update step message based on progress percentage
  useEffect(() => {
    if (!sharing) {
      setCurrentStep("");
      return;
    }

    const productName = activeProduct?.name || "produto";

    if (progress < 15) {
      setCurrentStep(`Analisando métricas de alta conversão para o produto: ${productName}...`);
    } else if (progress < 35) {
      setCurrentStep(
        `Gerando copys irresistíveis, hashtags quentes e roteiros com IA para: ${productName}...`,
      );
    } else if (progress < 55) {
      setCurrentStep(`Otimizando mídias e criativos visuais de alta conversão...`);
    } else if (progress < 75) {
      setCurrentStep(`Disparando conexões seguras e configurando servidores de tráfego...`);
    } else if (progress < 95) {
      setCurrentStep(
        `Disparando postagens em massa no Kwai, TikTok, Facebook, WhatsApp, Instagram e Twitter...`,
      );
    } else {
      setCurrentStep(`Finalizando disparos automáticos e contabilizando tráfego orgânico...`);
    }
  }, [progress, sharing, activeProduct]);

  const startAutoSharing = () => {
    if (!activeProduct) {
      toast.error("Por favor, selecione um produto para divulgar.");
      return;
    }

    const currentCredits = getAICredits();
    if (currentCredits < 25) {
      toast.error("Créditos insuficientes! Recarregue seus créditos para continuar.", {
        icon: <AlertCircle className="h-4 w-4 text-destructive" />,
      });
      navigate({ to: "/quero-mais-creditos" });
      return;
    }

    // Reset and start campaign
    setSharing(true);
    setProgress(0);
    setShowResults(false);
    setResults(null);

    // Consume 25% of credits persistently
    const nextCredits = spendAICredits(25);
    setCredits(nextCredits);

    // Calculate progress increments over 30 seconds
    // 30,000 ms total. Let's increment by 1% every 300 ms.
    const interval = 300;

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (timerRef.current) clearInterval(timerRef.current);

          // Campaign finished!
          setTimeout(() => {
            finishCampaign();
          }, 400);

          return 100;
        }
        return prev + 1;
      });
    }, interval);
  };

  const finishCampaign = () => {
    // Generate random sales results
    const salesCount = Math.floor(Math.random() * 6) + 3; // 3 to 8 sales
    const earnedCommission = +(Math.random() * 110 + 35).toFixed(2); // R$ 35 to R$ 145

    // Persist this commission to global salesStore balance!
    addCommission(earnedCommission);

    // Also update dynamic dashboard statistics!
    const generatedVisitors = Math.floor(Math.random() * 60) + 40; // 40 to 100 visitors
    const generatedViews = Math.floor(Math.random() * 120) + 80; // 80 to 200 views
    addStats({
      sales: salesCount,
      units: salesCount + Math.floor(Math.random() * 2), // Some double unit orders
      visitors: generatedVisitors,
      views: generatedViews,
    });

    setResults({
      sales: salesCount,
      commission: earnedCommission,
    });
    setSharing(false);
    setShowResults(true);

    toast.success("Campanha finalizada! Comissão creditada com sucesso.", {
      icon: <CheckCircle2 className="h-4 w-4 text-success" />,
    });
  };

  const replenishCredits = () => {
    navigate({ to: "/quero-mais-creditos" });
  };

  return (
    <AppShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 md:py-12">
        <div className="mb-8 flex flex-col gap-3">
          <div className="inline-flex max-w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            <Sparkles className="h-3.5 w-3.5 animate-pulse" /> Inteligência Artificial
          </div>
          <h1 className="text-3xl font-black tracking-tight text-foreground md:text-4xl">
            Divulgação com IA
          </h1>
          <p className="text-sm text-muted-foreground">
            Sua central inteligente para propagar produtos automaticamente por toda a internet.
          </p>
        </div>

        {/* Dashboard Grid */}
        <div className="grid gap-6 md:grid-cols-12">
          {/* LEFT SIDEBAR: Credits Status & Selected Product Preview */}
          <div className="md:col-span-4 space-y-6">
            {/* AI Credits Card */}
            <div
              id="ai-credits-card"
              className="rounded-3xl border border-border bg-card p-6 flex flex-col justify-between space-y-6"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Coins className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-foreground">Créditos de IA</h3>
                    <p className="text-xs text-muted-foreground">Campanhas disponíveis</p>
                  </div>
                </div>

                {/* Account Credit Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-muted-foreground">Status do Limite</span>
                    <span className={credits < 25 ? "text-destructive" : "text-primary"}>
                      {credits}%
                    </span>
                  </div>
                  <Progress value={credits} className="h-3 bg-muted" />
                  <p className="text-[10px] text-muted-foreground leading-snug">
                    Cada divulgação automática consome{" "}
                    <span className="font-bold text-foreground">25%</span> de créditos.
                  </p>
                </div>
              </div>

              {credits < 100 && (
                <Button
                  id="recharge-credits-btn"
                  variant="outline"
                  size="sm"
                  className="w-full font-bold uppercase tracking-wider text-xs"
                  onClick={replenishCredits}
                  disabled={sharing}
                >
                  <RefreshCw className="mr-2 h-3.5 w-3.5" />
                  Recarregar Créditos
                </Button>
              )}
            </div>

            {/* Selected Product Preview Card */}
            {activeProduct && (
              <div
                id="selected-product-card"
                className="rounded-3xl border border-border bg-card p-6 space-y-4"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="flex items-center gap-2 border-b border-border pb-3">
                  <ShoppingBag className="h-4 w-4 text-primary" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Produto Selecionado
                  </h3>
                </div>

                <div className="flex gap-4 items-center">
                  <img
                    src={activeProduct.image}
                    alt={activeProduct.name}
                    className="h-16 w-16 rounded-xl object-cover border border-border shrink-0 bg-muted"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="text-sm font-bold text-foreground line-clamp-2 leading-snug">
                      {activeProduct.name}
                    </h4>
                    <p className="text-xs font-black text-primary mt-1">
                      R$ {formatBRL(activeProduct.price)}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed italic bg-muted/40 p-2.5 rounded-xl border border-border/40">
                  "{activeProduct.description}"
                </p>
              </div>
            )}
          </div>

          {/* RIGHT MAIN AREA: Campaign / Product Selector */}
          <div className="md:col-span-8 space-y-6">
            {/* Main Interactive campaign controller */}
            <div
              id="main-campaign-card"
              className="rounded-3xl border border-border bg-card p-6 md:p-8 space-y-6 relative overflow-hidden"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              {/* Decorative backgrounds */}
              <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-primary/5 blur-3xl" />
              <div className="absolute -left-12 -bottom-12 h-40 w-40 rounded-full bg-accent/5 blur-3xl" />

              <div className="relative z-10 space-y-6">
                {/* 1. Selection & Trigger Page */}
                {!sharing && !showResults && (
                  <div className="space-y-6">
                    <div className="flex flex-col gap-1">
                      <h2 className="text-lg font-black text-foreground">
                        Passo 1: Escolha o Produto & Divulgue com IA
                      </h2>
                      <p className="text-xs text-muted-foreground">
                        Selecione um produto do seu catálogo abaixo para que o algoritmo gere
                        campanhas otimizadas.
                      </p>
                    </div>

                    {/* Product Picker Search & Categories */}
                    <div className="space-y-3">
                      <div className="flex flex-col sm:flex-row gap-2">
                        {/* Search input */}
                        <div className="relative flex-1">
                          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                          <Input
                            placeholder="Buscar produto..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-9 text-xs h-9 bg-muted/30"
                          />
                        </div>

                        {/* Category list scroll container */}
                        <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
                          {categories.map((cat) => (
                            <button
                              key={cat}
                              onClick={() => setSelectedCategory(cat)}
                              className={`px-3 py-1.5 rounded-full text-[11px] font-bold border transition-all whitespace-nowrap ${
                                selectedCategory === cat
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-muted/40 border-border text-muted-foreground hover:bg-muted"
                              }`}
                            >
                              {cat}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Products scroll area */}
                      <div
                        id="products-picker-list"
                        className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[260px] overflow-y-auto pr-1.5 scrollbar-thin border border-border/80 rounded-2xl bg-muted/10 p-3"
                      >
                        {filteredProducts.length > 0 ? (
                          filteredProducts.map((p) => {
                            const isSelected = p.id === selectedProductId;
                            return (
                              <div
                                key={p.id}
                                onClick={() => setSelectedProductId(p.id)}
                                className={`flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer transition-all ${
                                  isSelected
                                    ? "bg-primary/5 border-primary ring-1 ring-primary"
                                    : "bg-card border-border hover:bg-muted/30"
                                }`}
                              >
                                <img
                                  src={p.image}
                                  alt={p.name}
                                  className="h-11 w-11 rounded-lg object-cover bg-muted shrink-0 border border-border/40"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="min-w-0 flex-1 text-left">
                                  <h4 className="text-[12px] font-bold text-foreground truncate leading-normal">
                                    {p.name}
                                  </h4>
                                  <p className="text-[11px] font-black text-primary mt-0.5">
                                    R$ {formatBRL(p.price)}
                                  </p>
                                </div>
                                <div
                                  className={`h-4.5 w-4.5 rounded-full border flex items-center justify-center shrink-0 ${
                                    isSelected
                                      ? "bg-primary border-primary text-primary-foreground"
                                      : "border-muted-foreground/30 bg-card"
                                  }`}
                                >
                                  {isSelected && <Check className="h-3 w-3" />}
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="col-span-full py-8 text-center text-xs text-muted-foreground font-semibold">
                            Nenhum produto correspondente encontrado nesta categoria.
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="border-t border-border pt-4 text-center space-y-4">
                      <p className="text-xs md:text-sm font-bold text-foreground leading-relaxed max-w-xl mx-auto">
                        Sua inteligência artificial integrada publicará automaticamente o produto
                        selecionado em massa nas redes sociais:{" "}
                        <span className="text-primary font-black">Kwai</span>,{" "}
                        <span className="text-primary font-black">TikTok</span>,{" "}
                        <span className="text-primary font-black">Facebook</span>,{" "}
                        <span className="text-primary font-black">WhatsApp</span>,{" "}
                        <span className="text-primary font-black">Instagram</span> e{" "}
                        <span className="text-primary font-black">Twitter</span>.
                      </p>

                      <Button
                        id="start-divulgacao-btn"
                        onClick={startAutoSharing}
                        disabled={credits < 25}
                        size="lg"
                        className="w-full max-w-md font-black uppercase tracking-widest text-xs h-12 shadow-lg shadow-primary/15"
                      >
                        <Play className="mr-2 h-4 w-4 fill-current" />
                        Divulgação Automática
                      </Button>
                    </div>
                  </div>
                )}

                {/* 2. Active Sharing State (30-second progress bar) */}
                {sharing && (
                  <div className="space-y-8 py-4">
                    <div className="text-center space-y-2">
                      <div className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1 text-xs font-black text-primary uppercase tracking-widest animate-pulse">
                        <Sparkles className="h-3 w-3" /> Divulgação Ativa
                      </div>
                      <h3 className="text-lg font-black text-foreground">
                        Aguarde enquanto a IA publica
                      </h3>
                      <p className="text-xs text-muted-foreground max-w-md mx-auto">
                        Isso levará cerca de 30 segundos. Estamos sincronizando suas contas e
                        publicando em massa nas plataformas parceiras.
                      </p>
                    </div>

                    {/* Progress tracking area */}
                    <div className="space-y-4 bg-muted/35 p-5 rounded-2xl border border-border/80">
                      {/* Selected product thumbnail while loading */}
                      {activeProduct && (
                        <div className="flex items-center gap-3 bg-card p-2.5 rounded-xl border border-border/60 max-w-md mx-auto mb-3">
                          <img
                            src={activeProduct.image}
                            alt={activeProduct.name}
                            className="h-9 w-9 rounded-md object-cover border border-border/40 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0 flex-1 text-left">
                            <span className="text-[10px] uppercase font-black tracking-widest text-primary">
                              Divulgando agora:
                            </span>
                            <h5 className="text-[11px] font-bold text-foreground truncate leading-tight">
                              {activeProduct.name}
                            </h5>
                          </div>
                        </div>
                      )}

                      <div className="space-y-2.5">
                        <div className="flex justify-between text-xs font-black">
                          <span className="text-primary uppercase tracking-wider">Aguarde...</span>
                          <span>{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-4 bg-muted" />
                        <p className="text-xs font-bold text-foreground italic text-center animate-pulse min-h-[1.5rem] px-2 leading-relaxed">
                          "{currentStep}"
                        </p>
                      </div>
                    </div>

                    {/* Social Networks glow grid */}
                    <div className="grid grid-cols-3 gap-3 pt-2">
                      {SOCIAL_NETWORKS.map((net, i) => {
                        // Light up icons dynamically as progress increases
                        const isActive = progress >= (i + 1) * 15;
                        return (
                          <div
                            key={net.name}
                            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all duration-200 ${
                              isActive
                                ? `${net.color} scale-105 border-primary font-bold shadow-md shadow-primary/5`
                                : "bg-muted/10 border-border text-muted-foreground opacity-40"
                            }`}
                          >
                            <span className="text-xs font-bold">{net.name}</span>
                            <span className="text-[9px] mt-1 font-semibold uppercase tracking-wider">
                              {isActive ? "Publicado" : "Pendente"}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 3. Result View */}
                {showResults && results && (
                  <div className="space-y-6 text-center py-4">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/15 text-success animate-bounce">
                      <CheckCircle2 className="h-9 w-9" />
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-xl font-black text-foreground">Campanha Concluída!</h3>
                      <p className="text-sm text-muted-foreground max-w-md mx-auto">
                        Os disparos automatizados para{" "}
                        <span className="font-bold text-foreground">"{activeProduct?.name}"</span>{" "}
                        geraram tráfego instantâneo e resultaram em excelentes comissões!
                      </p>
                    </div>

                    {/* Results box */}
                    <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto p-4 rounded-2xl border border-border bg-muted/30">
                      <div className="p-3 bg-card rounded-xl border border-border flex flex-col justify-center">
                        <span className="text-xs text-muted-foreground font-semibold">
                          Vendas Feitas
                        </span>
                        <span className="text-2xl font-black text-foreground flex items-center justify-center gap-1.5 mt-1">
                          <TrendingUp className="h-5 w-5 text-success shrink-0" />
                          {results.sales}
                        </span>
                      </div>
                      <div className="p-3 bg-card rounded-xl border border-border flex flex-col justify-center">
                        <span className="text-xs text-muted-foreground font-semibold">
                          Comissão Recebida
                        </span>
                        <span className="text-xl font-black text-success mt-1">
                          R$ {formatBRL(results.commission)}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-3 justify-center max-w-sm mx-auto pt-2">
                      <Button
                        id="restart-campaign-btn"
                        onClick={startAutoSharing}
                        disabled={credits < 25}
                        className="flex-1 font-bold uppercase tracking-wider text-xs h-10"
                      >
                        <Play className="mr-2 h-3.5 w-3.5 fill-current" />
                        Disparar Novamente
                      </Button>
                      <Button
                        id="close-summary-btn"
                        variant="outline"
                        onClick={() => setShowResults(false)}
                        className="flex-1 font-bold uppercase tracking-wider text-xs h-10"
                      >
                        Fechar Resumo
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer info banner */}
        <div
          className="mt-8 rounded-3xl border border-border bg-card p-6"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-foreground">Rede de Tráfego Global Ativa</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                As publicações são distribuídas em perfis otimizados de nichos específicos para
                maximizar taxas de cliques.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              {SOCIAL_NETWORKS.map((net) => (
                <span
                  key={net.name}
                  className="inline-flex items-center gap-1 rounded-full border border-border bg-muted/30 px-3 py-1 text-[11px] font-bold text-muted-foreground"
                >
                  <CheckCircle className="h-3 w-3 text-success shrink-0" />
                  {net.name}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
