import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import {
  Eye,
  Package,
  ShoppingCart,
  Users,
  Wallet,
  Sparkles,
  Video,
  ArrowRight,
  DollarSign,
  Mail,
} from "lucide-react";
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { useMemo, useState, useEffect } from "react";
import {
  useBalance,
  formatBRL,
  useStats,
  triggerRandomSale,
  formatBRL as formatCurrency,
  getProductSalesCounts,
} from "@/lib/salesStore";
import { products } from "@/data/products";
import { AnimatePresence, motion } from "motion/react";

export const Route = createFileRoute("/dashboard")({
  component: DashboardPage,
  head: () => ({
    meta: [
      { title: "Painel Shopee — ApexFinder" },
      {
        name: "description",
        content: "Acompanhe suas vendas Shopee em tempo real com o ApexFinder.",
      },
    ],
  }),
});

interface ToastMessage {
  id: number;
  amount: number;
  productName: string;
  productImage: string;
}

function DashboardPage() {
  const [range, setRange] = useState<"Hoje" | "7 Dias" | "30 Dias" | "Tempo Todo">("Hoje");
  const balance = useBalance();
  const stats = useStats();
  const [timeStr, setTimeStr] = useState("");
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const playCashRegisterSound = () => {
    const audio = new Audio("/media/sounds/zoeira-efeito-caixa-registradora.mp3");
    audio.play().catch((err) => console.log("Sound play error: ", err));
  };

  const playHiddenButtonSound = () => {
    const audio = new Audio("https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3");
    audio.preload = "auto";
    audio.volume = 0.7;
    audio.play().catch((err) => console.log("Sound play error: ", err));
  };

  // Ticking clock matching the format: "DD/MM/YYYY HH:MM:SS (GMT-03)"
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const pad = (n: number) => String(n).padStart(2, "0");
      const formatted = `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} (GMT-03)`;
      setTimeStr(formatted);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Automatic 15-minute interval timer for sales simulation
  useEffect(() => {
    const interval = setInterval(
      () => {
        const res = triggerRandomSale();
        if (res.added && res.amount > 0) {
          const id = Date.now();
          setToasts((prev) => [
            ...prev,
            {
              id,
              amount: res.amount,
              productName: res.productName,
              productImage: res.productImage,
            },
          ]);
          // Sound removed to ensure play only when hidden button is clicked
          setTimeout(() => {
            setToasts((prev) => prev.filter((t) => t.id !== id));
          }, 4500);
        }
      },
      15 * 60 * 1000,
    ); // 15 minutes in ms

    return () => clearInterval(interval);
  }, []);

  const handleManualSimulation = () => {
    const res = triggerRandomSale();
    if (res.added && res.amount > 0) {
      const id = Date.now();
      setToasts((prev) => [
        ...prev,
        {
          id,
          amount: res.amount,
          productName: res.productName,
          productImage: res.productImage,
        },
      ]);
      // Sound removed to ensure play only when hidden button is clicked
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4500);
    }
  };

  const handleHiddenEmailClick = () => {
    const res = triggerRandomSale();
    if (res.added && res.amount > 0) {
      const id = Date.now();
      setToasts((prev) => [
        ...prev,
        {
          id,
          amount: res.amount,
          productName: res.productName,
          productImage: res.productImage,
        },
      ]);
      playHiddenButtonSound();
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4500);
    }
  };

  // Shopee chart data based on the curved lines shown in the screenshot, adapting to selected tab range
  const salesChartData = useMemo(() => {
    const currentHour = new Date().getHours();

    if (range === "Hoje") {
      return [
        { hora: "00", hoje: currentHour >= 0 ? 30 : null, ontem: 35 },
        { hora: "02", hoje: currentHour >= 2 ? 15 : null, ontem: 18 },
        { hora: "04", hoje: currentHour >= 4 ? 10 : null, ontem: 15 },
        { hora: "06", hoje: currentHour >= 6 ? 65 : null, ontem: 75 },
        { hora: "08", hoje: currentHour >= 8 ? 160 : null, ontem: 190 },
        { hora: "10", hoje: currentHour >= 10 ? 310 : null, ontem: 280 },
        { hora: "12", hoje: currentHour >= 12 ? 390 : null, ontem: 420 },
        { hora: "14", hoje: currentHour >= 14 ? 120 : null, ontem: 310 },
        { hora: "16", hoje: currentHour >= 16 ? 40 : null, ontem: 370 },
        { hora: "18", hoje: currentHour >= 18 ? 110 : null, ontem: 520 },
        { hora: "20", hoje: currentHour >= 20 ? 180 : null, ontem: 490 },
        { hora: "22", hoje: currentHour >= 22 ? 90 : null, ontem: 260 },
        { hora: "Hora", hoje: null, ontem: 100 },
      ];
    } else if (range === "7 Dias") {
      return [
        { hora: "Seg", hoje: 240, ontem: 220 },
        { hora: "Ter", hoje: 310, ontem: 280 },
        { hora: "Qua", hoje: 450, ontem: 390 },
        { hora: "Qui", hoje: 520, ontem: 480 },
        { hora: "Sex", hoje: 590, ontem: 510 },
        { hora: "Sáb", hoje: 410, ontem: 430 },
        { hora: "Dom", hoje: 320, ontem: 350 },
      ];
    } else if (range === "30 Dias") {
      return [
        { hora: "05", hoje: 1120, ontem: 980 },
        { hora: "10", hoje: 1450, ontem: 1200 },
        { hora: "15", hoje: 1890, ontem: 1650 },
        { hora: "20", hoje: 2100, ontem: 1900 },
        { hora: "25", hoje: 2350, ontem: 2200 },
        { hora: "30", hoje: 2680, ontem: 2450 },
      ];
    } else {
      // Tempo Todo (All Time)
      return [
        { hora: "Jan", hoje: 5200, ontem: 4100 },
        { hora: "Fev", hoje: 6800, ontem: 5200 },
        { hora: "Mar", hoje: 8400, ontem: 6500 },
        { hora: "Abr", hoje: 9900, ontem: 7800 },
        { hora: "Mai", hoje: 11500, ontem: 9200 },
        { hora: "Jun", hoje: 13800, ontem: 11000 },
        { hora: "Jul", hoje: 15400, ontem: 12500 },
        { hora: "Ago", hoje: 17200, ontem: 14000 },
        { hora: "Set", hoje: 19100, ontem: 15500 },
        { hora: "Out", hoje: 21400, ontem: 17200 },
        { hora: "Nov", hoje: 23800, ontem: 19000 },
        { hora: "Dez", hoje: 26500, ontem: 21000 },
      ];
    }
  }, [range]);

  // High precision list of top 5 selling products with dynamic local storage syncing and instant event-driven updates
  const [topProducts, setTopProducts] = useState(() => {
    const list = getProductSalesCounts();
    return list
      .map((item) => {
        const realProduct = products.find((p) => p.id === item.id);
        return {
          rank: 0,
          id: item.id,
          title: item.name,
          soldQty: item.soldQty,
          price: item.price,
          image: realProduct ? realProduct.image : "",
        };
      })
      .sort((a, b) => b.soldQty - a.soldQty)
      .slice(0, 5)
      .map((item, index) => ({ ...item, rank: index + 1 }));
  });

  useEffect(() => {
    const updateProducts = () => {
      const list = getProductSalesCounts();
      setTopProducts(
        list
          .map((item) => {
            const realProduct = products.find((p) => p.id === item.id);
            return {
              rank: 0,
              id: item.id,
              title: item.name,
              soldQty: item.soldQty,
              price: item.price,
              image: realProduct ? realProduct.image : "",
            };
          })
          .sort((a, b) => b.soldQty - a.soldQty)
          .slice(0, 5)
          .map((item, index) => ({ ...item, rank: index + 1 })),
      );
    };

    window.addEventListener("apex-stats-changed", updateProducts);
    window.addEventListener("apex-balance-changed", updateProducts);
    window.addEventListener("storage", updateProducts);

    return () => {
      window.removeEventListener("apex-stats-changed", updateProducts);
      window.removeEventListener("apex-balance-changed", updateProducts);
      window.removeEventListener("storage", updateProducts);
    };
  }, []);

  return (
    <AppShell>
      <div className="min-h-screen bg-[#f5f5f5]">
        {/* Shopee header with official color #EE4D2D */}
        <section className="bg-[#EE4D2D] text-white pt-12 pb-32 relative overflow-hidden shadow-sm">
          <div className="absolute right-0 bottom-0 top-0 opacity-10 pointer-events-none w-1/3 flex items-center justify-end pr-10">
            <ShoppingCart className="w-96 h-96 transform translate-y-12 translate-x-12" />
          </div>

          <div className="relative mx-auto max-w-7xl px-4 text-center">
            <span className="text-sm font-bold tracking-wider uppercase text-orange-100 opacity-90">
              Shopee
            </span>
            <h1 className="mt-1 text-3xl font-extrabold tracking-tight md:text-4xl text-white">
              Vendas Hoje
            </h1>

            {/* Live Clock pill */}
            <div className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-black/15 px-4 py-1.5 text-xs font-semibold backdrop-blur border border-white/5 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-white/95">{timeStr || "Carregando..."}</span>
            </div>

            {/* Quick Action buttons */}
            <div className="mt-6 flex justify-center items-center gap-3">
              <Link
                to="/financeiro"
                className="inline-flex items-center gap-1 rounded-md bg-white/10 hover:bg-white/20 border border-white/25 px-4 py-1.5 text-xs font-bold text-white transition backdrop-blur-sm shadow-sm"
              >
                Ver Métricas Detalhadas <ArrowRight className="h-3 w-3 ml-0.5" />
              </Link>
            </div>
          </div>
        </section>

        <div className="mx-auto max-w-7xl px-4 md:px-6 -mt-20 relative z-20 pb-16">
          {/* Main Floating balance card matching the screenshot precisely */}
          <div className="bg-white rounded-xl shadow-md p-8 md:p-10 border border-zinc-100/60 transition hover:shadow-lg">
            <div className="text-center">
              <div className="flex items-baseline justify-center gap-1.5 md:gap-2">
                <span className="text-3xl font-bold text-[#EE4D2D] translate-y-[-12px]">R$</span>
                <span className="text-5xl md:text-7xl font-black tracking-tight leading-none text-[#EE4D2D]">
                  {formatCurrency(balance)}
                </span>
              </div>
              <p className="mt-4 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                Comissão Total Acumulada (Disponível para Saque)
              </p>
              <div className="mt-3 flex items-center justify-center gap-1.5 text-xs text-emerald-600 font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Sincronizado com API Shopee Brasil
              </div>
            </div>
          </div>

          {/* Grid Layout containing three sections */}
          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Column 1: Métricas Principais (Takes up 3cols on large screens) */}
            <div className="bg-white rounded-xl shadow-sm border border-zinc-100 p-5 lg:col-span-3 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-zinc-700 pb-3 border-b border-zinc-100">
                  Desempenho Geral
                </h3>

                {/* 2x2 Clean layout grid with inner borders */}
                <div className="grid grid-cols-2 mt-4 border border-zinc-100 rounded-lg overflow-hidden bg-zinc-50/20">
                  {/* Visitantes */}
                  <div className="p-4 border-r border-b border-zinc-100 flex flex-col items-center justify-center text-center bg-white">
                    <Users className="h-5 w-5 text-[#EE4D2D]" />
                    <span className="mt-2 text-[11px] font-semibold text-zinc-400">Visitas</span>
                    <span className="mt-1.5 text-lg font-black text-zinc-700">
                      {Number(stats.visitors).toLocaleString("pt-BR")}
                    </span>
                  </div>

                  {/* Visualizações */}
                  <div className="p-4 border-b border-zinc-100 flex flex-col items-center justify-center text-center bg-white">
                    <Eye className="h-5 w-5 text-[#EE4D2D]" />
                    <span className="mt-2 text-[11px] font-semibold text-zinc-400 truncate max-w-full">
                      Cliques
                    </span>
                    <span className="mt-1.5 text-lg font-black text-zinc-700">
                      {Number(stats.views).toLocaleString("pt-BR")}
                    </span>
                  </div>

                  {/* Pedidos */}
                  <div className="p-4 border-r border-zinc-100 flex flex-col items-center justify-center text-center bg-white">
                    <ShoppingCart className="h-5 w-5 text-[#EE4D2D]" />
                    <span className="mt-2 text-[11px] font-semibold text-zinc-400">Pedidos</span>
                    <span className="mt-1.5 text-lg font-black text-zinc-700">{stats.sales}</span>
                  </div>

                  {/* Unidades */}
                  <div className="p-4 flex flex-col items-center justify-center text-center bg-white">
                    <Package className="h-5 w-5 text-[#EE4D2D]" />
                    <span className="mt-2 text-[11px] font-semibold text-zinc-400">Unidades</span>
                    <span className="mt-1.5 text-lg font-black text-zinc-700">{stats.units}</span>
                  </div>
                </div>

                {/* Ir para o financeiro button placed precisely below metrics */}
                <div className="mt-5 pt-4 border-t border-zinc-100">
                  <Link
                    to="/financeiro"
                    className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-[#EE4D2D] hover:bg-[#d83c1f] py-2.5 px-4 text-xs font-extrabold uppercase tracking-wider text-white shadow-md transition transform active:scale-95"
                  >
                    <Wallet className="h-3.5 w-3.5" /> Ir para o Financeiro
                  </Link>
                  <p className="mt-2 text-[10px] text-center text-zinc-400 font-semibold leading-relaxed">
                    Acesse para cadastrar sua chave PIX e solicitar o saque de suas comissões.
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-zinc-50 text-[10px] text-zinc-400 text-center font-medium leading-relaxed">
                Dados atualizados de 15 em 15 minutos em tempo real.
              </div>
            </div>

            {/* Column 2: Visão Geral de Vendas - Hoje (Takes up 5cols on large screens) */}
            <div className="bg-white rounded-xl shadow-sm border border-zinc-100 p-5 lg:col-span-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
                  <h3 className="text-sm font-bold text-zinc-700">
                    Visão Geral de Vendas ({range})
                  </h3>

                  {/* Pills range tabs */}
                  <div className="flex gap-1.5">
                    {(["Hoje", "7 Dias", "30 Dias", "Tempo Todo"] as const).map((r) => (
                      <button
                        key={r}
                        onClick={() => setRange(r)}
                        className={`text-[10px] font-extrabold px-3 py-1 rounded-full border transition-all ${
                          range === r
                            ? "bg-orange-50 border-[#EE4D2D] text-[#EE4D2D]"
                            : "border-zinc-200 text-zinc-400 hover:text-zinc-600 bg-white"
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sub-legend labels */}
                <div className="mt-3.5 flex items-center gap-4 text-[11px] font-semibold text-zinc-500">
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block h-2 w-2 rounded-full bg-[#EE4D2D]" />{" "}
                    {range === "Tempo Todo" ? "Atual" : "Hoje"}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block h-2 w-2 rounded-full bg-[#3498db]" />{" "}
                    {range === "Tempo Todo" ? "Projeção" : "Ontem"}
                  </span>
                </div>

                {/* Highly aligned Line Chart */}
                <div className="mt-4 h-[240px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={salesChartData}
                      margin={{ top: 12, right: 10, bottom: 0, left: -20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f1f1" vertical={false} />
                      <XAxis
                        dataKey="hora"
                        tick={{ fontSize: 10, fill: "#a1a1aa", fontWeight: "bold" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: "#a1a1aa", fontWeight: "bold" }}
                        domain={range === "Hoje" ? [0, 600] : ["auto", "auto"]}
                        ticks={range === "Hoje" ? [0, 120, 240, 360, 480, 600] : undefined}
                        axisLine={false}
                        tickLine={false}
                      />
                      <Tooltip
                        contentStyle={{
                          fontSize: "11px",
                          borderRadius: "8px",
                          border: "1px solid #e4e4e7",
                        }}
                        formatter={(value) => [`${value} pedidos`, ""]}
                      />
                      <Line
                        type="monotone"
                        dataKey="hoje"
                        stroke="#EE4D2D"
                        strokeWidth={2.5}
                        dot={{ r: 3, fill: "#EE4D2D", strokeWidth: 0 }}
                        activeDot={{ r: 5 }}
                        connectNulls
                      />
                      <Line
                        type="monotone"
                        dataKey="ontem"
                        stroke="#3498db"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Caption message */}
              <p className="mt-4 text-[11px] font-medium text-center text-zinc-400 leading-normal">
                Os vendedores que usam os Anúncios da Shopee estão recebendo 65% mais pedidos em
                média.{" "}
                <a href="#" className="text-[#3498db] hover:underline font-semibold">
                  Crie anúncios aqui !
                </a>
              </p>
            </div>

            {/* Column 3: Top 5 dos Produtos à Venda (Takes up 4cols on large screens) */}
            <div className="bg-white rounded-xl shadow-sm border border-zinc-100 p-5 lg:col-span-4 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-zinc-700 pb-3 border-b border-zinc-100">
                  Top 5 dos Produtos à Venda
                </h3>

                {/* List items representing actual image matching and formatting */}
                <div className="mt-4 divide-y divide-zinc-50">
                  {topProducts.map((item) => (
                    <div
                      key={item.rank}
                      className="py-2.5 flex items-center gap-3.5 first:pt-0 last:pb-0"
                    >
                      {/* Rank badge */}
                      <span
                        className={`text-sm font-black w-4 text-center ${
                          item.rank === 1
                            ? "text-[#EE4D2D]"
                            : item.rank <= 3
                              ? "text-orange-400"
                              : "text-zinc-300"
                        }`}
                      >
                        {item.rank}
                      </span>

                      {/* Product image with safety referral policy */}
                      <div className="w-10 h-10 rounded bg-zinc-50 border border-zinc-100 flex-shrink-0 overflow-hidden flex items-center justify-center p-0.5">
                        {item.image ? (
                          <img
                            src={item.image}
                            alt={item.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <Package className="w-5 h-5 text-zinc-300" />
                        )}
                      </div>

                      {/* Title and details */}
                      <div className="flex-1 min-w-0">
                        <h4
                          className="text-[11px] font-bold text-zinc-700 truncate"
                          title={item.title}
                        >
                          {item.title}
                        </h4>
                        <span className="text-[10px] text-zinc-400 font-semibold block mt-0.5">
                          {item.soldQty}{" "}
                          {item.soldQty === 1 ? "unidade vendida" : "unidades vendidas"}
                        </span>
                      </div>

                      {/* Price indicator in Shopee red/orange */}
                      <span className="text-[11px] font-extrabold text-[#EE4D2D] whitespace-nowrap">
                        R$ {formatCurrency(item.price)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5 text-[10px] text-zinc-400 font-medium text-center">
                Baseado em seu histórico de indicações convertidas hoje.
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Floating Sales Notification Portal */}
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm pointer-events-none">
          <AnimatePresence>
            {toasts.map((toast) => (
              <motion.div
                key={toast.id}
                initial={{ opacity: 0, y: 30, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                className="pointer-events-auto bg-white border border-orange-100 shadow-xl rounded-xl p-4 flex items-start gap-3.5 ring-1 ring-orange-500/10 w-[300px] md:w-[320px]"
              >
                {toast.productImage ? (
                  <div className="w-10 h-10 rounded bg-zinc-50 border border-zinc-100 flex-shrink-0 overflow-hidden flex items-center justify-center p-0.5">
                    <img
                      src={toast.productImage}
                      alt={toast.productName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center flex-shrink-0 border border-orange-100">
                    <DollarSign className="w-5 h-5 text-[#EE4D2D]" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h5 className="text-[10px] font-black uppercase tracking-wider text-[#EE4D2D]">
                    Venda Realizada!
                  </h5>
                  <p
                    className="text-[11px] text-zinc-700 font-bold truncate mt-0.5"
                    title={toast.productName}
                  >
                    {toast.productName}
                  </p>
                  <p className="text-[10px] text-zinc-400 font-semibold leading-none mt-0.5">
                    Comissão recebida na Shopee
                  </p>
                  <span className="text-sm font-black text-emerald-600 block mt-1.5">
                    + R$ {formatCurrency(toast.amount)}
                  </span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Discrete email trigger button in bottom-left corner */}
        <button
          onClick={handleHiddenEmailClick}
          className="fixed bottom-6 left-6 z-50 p-2.5 rounded-full bg-white/85 hover:bg-white border border-zinc-200 hover:border-zinc-300 text-zinc-400 hover:text-[#EE4D2D] transition-all shadow-sm cursor-pointer group flex items-center justify-center backdrop-blur-sm"
          title="Simular Venda"
        >
          <Mail className="w-4.5 h-4.5 transition-transform group-hover:scale-110" />
        </button>

        {/* Hidden preloaded audio element for instant playback on button click */}
        <audio
          src="https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3"
          preload="auto"
          className="hidden"
          style={{ display: "none" }}
        />
      </div>
    </AppShell>
  );
}
