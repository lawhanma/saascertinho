import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useEffect, useState } from "react";
import { Save, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/perfil")({
  component: PerfilPage,
  head: () => ({
    meta: [
      { title: "Perfil — ApexFinder" },
      { name: "description", content: "Gerencie seus dados de perfil no ApexFinder." },
    ],
  }),
});

type ProfileData = {
  nome: string;
  emailShopee: string;
  dataNascimento: string;
  cpf: string;
  endereco: string;
};

const KEY = "apex_profile";
const empty: ProfileData = { nome: "", emailShopee: "", dataNascimento: "", cpf: "", endereco: "" };

function maskCPF(v: string) {
  return v
    .replace(/\D/g, "")
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

function PerfilPage() {
  const [data, setData] = useState<ProfileData>(empty);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setData({ ...empty, ...JSON.parse(raw) });
    } catch (e) {
      console.warn("Failed to load profile from local storage:", e);
    }
  }, []);

  const update = <K extends keyof ProfileData>(k: K, v: string) => {
    setData((d) => ({ ...d, [k]: v }));
    setSaved(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem(KEY, JSON.stringify(data));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 py-10">
        <h1 className="text-3xl font-black text-foreground">Perfil</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preencha seus dados. Eles ficam salvos para o seu perfil.
        </p>

        <form
          onSubmit={handleSave}
          className="mt-8 space-y-5 rounded-2xl border border-border bg-card p-6"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <Field label="Nome" required>
            <input
              type="text"
              value={data.nome}
              onChange={(e) => update("nome", e.target.value)}
              maxLength={120}
              required
              className="input"
              placeholder="Seu nome completo"
            />
          </Field>

          <Field label="Email da Shopee" required>
            <input
              type="email"
              value={data.emailShopee}
              onChange={(e) => update("emailShopee", e.target.value)}
              maxLength={200}
              required
              className="input"
              placeholder="voce@email.com"
            />
          </Field>

          <Field label="Data de Nascimento" required>
            <input
              type="date"
              value={data.dataNascimento}
              onChange={(e) => update("dataNascimento", e.target.value)}
              required
              className="input"
            />
          </Field>

          <Field label="CPF" required>
            <input
              type="text"
              inputMode="numeric"
              value={data.cpf}
              onChange={(e) => update("cpf", maskCPF(e.target.value))}
              required
              className="input"
              placeholder="000.000.000-00"
            />
          </Field>

          <Field label="Endereço" required>
            <textarea
              value={data.endereco}
              onChange={(e) => update("endereco", e.target.value)}
              maxLength={300}
              required
              rows={3}
              className="input resize-none"
              placeholder="Rua, número, bairro, cidade — UF, CEP"
            />
          </Field>

          <div className="flex items-center justify-between gap-3 pt-2">
            {saved ? (
              <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-green-600">
                <CheckCircle2 className="h-4 w-4" /> Perfil salvo com sucesso
              </span>
            ) : (
              <span className="text-xs text-muted-foreground">
                Seus dados ficam salvos neste dispositivo.
              </span>
            )}
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-black uppercase tracking-wide text-primary-foreground shadow-md transition hover:opacity-95"
              style={{ background: "var(--gradient-hero)" }}
            >
              <Save className="h-4 w-4" /> Salvar
            </button>
          </div>
        </form>
      </div>

      <style>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid hsl(var(--border));
          background: hsl(var(--background));
          padding: 0.65rem 0.85rem;
          font-size: 0.9rem;
          outline: none;
          transition: border-color .15s, box-shadow .15s;
        }
        .input:focus {
          border-color: oklch(0.68 0.22 35);
          box-shadow: 0 0 0 3px oklch(0.68 0.22 35 / 0.15);
        }
      `}</style>
    </AppShell>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-foreground">
        {label} {required && <span className="text-primary">*</span>}
      </span>
      {children}
    </label>
  );
}
