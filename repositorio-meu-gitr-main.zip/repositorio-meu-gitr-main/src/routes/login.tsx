import { createFileRoute, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Lock, User as UserIcon, Zap, AlertCircle } from "lucide-react";
import { APP_PASSWORD, getAuthUser, signIn } from "@/lib/authStore";
import { ApexShopLogo } from "@/components/ApexShopLogo";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({
    meta: [
      { title: "Entrar — Apex Shop" },
      { name: "description", content: "Acesse sua conta Apex Shop." },
    ],
  }),
});

function LoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const isClient = useRouterState({ select: () => true });

  useEffect(() => {
    if (getAuthUser()) navigate({ to: "/" });
  }, [navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const u = username.trim();
    if (!u) return setError("Informe um usuário.");
    if (password !== APP_PASSWORD) return setError("Senha incorreta.");
    signIn(u);
    navigate({ to: "/" });
  };

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4"
      style={{ background: "var(--gradient-hero)" }}
    >
      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl">
        <div className="mb-6 flex flex-col items-start gap-1">
          <ApexShopLogo className="text-black scale-105 origin-left" />
          <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground mt-1">
            Facilitador de vendas Shopee
          </div>
        </div>

        <h1 className="text-2xl font-black text-foreground">Entrar</h1>
        <p className="mt-1 text-sm text-muted-foreground">Faça login para acessar o Apex Shop.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4" key={isClient ? "c" : "s"}>
          <label className="block">
            <span className="mb-1.5 block text-sm font-semibold text-foreground">Usuário</span>
            <div className="flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2.5 focus-within:ring-2 focus-within:ring-primary/30">
              <UserIcon className="h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setError(null);
                }}
                maxLength={60}
                autoComplete="username"
                placeholder="Seu usuário"
                className="w-full bg-transparent text-sm font-medium outline-none"
              />
            </div>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-semibold text-foreground">Senha</span>
            <div className="flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2.5 focus-within:ring-2 focus-within:ring-primary/30">
              <Lock className="h-4 w-4 text-muted-foreground" />
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(null);
                }}
                maxLength={30}
                autoComplete="current-password"
                placeholder="••••••"
                className="w-full bg-transparent text-sm font-medium outline-none"
              />
            </div>
          </label>

          {error && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive">
              <AlertCircle className="h-4 w-4" /> {error}
            </div>
          )}

          <button
            type="submit"
            className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-black uppercase tracking-widest text-primary-foreground shadow-md transition hover:opacity-95"
            style={{ background: "var(--gradient-hero)" }}
          >
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}
