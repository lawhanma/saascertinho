import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import {
  Sparkles,
  Zap,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Clock,
  AlertTriangle,
} from "lucide-react";
import { getBrasiliaDateString } from "@/lib/salesStore";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/quero-mais-creditos")({
  component: QueroMaisCreditosPage,
  head: () => ({
    meta: [
      { title: "Adquirir Mais Créditos — Shopee Afiliados" },
      {
        name: "description",
        content:
          "Seus créditos diários acabaram. Adquira créditos ilimitados para continuar suas divulgações automáticas com IA.",
      },
    ],
  }),
});

function QueroMaisCreditosPage() {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      // Brasilia standard time is UTC-3.
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const brTime = new Date(utc + 3600000 * -3);

      const tomorrowBr = new Date(brTime);
      tomorrowBr.setHours(24, 0, 0, 0); // Next midnight

      const diffMs = tomorrowBr.getTime() - brTime.getTime();

      if (diffMs <= 0) {
        setTimeLeft("00:00:00");
        return;
      }

      const hrs = Math.floor(diffMs / (3600 * 1000));
      const mins = Math.floor((diffMs % (3600 * 1000)) / (60 * 1000));
      const secs = Math.floor((diffMs % (60 * 1000)) / 1000);

      setTimeLeft(
        `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`,
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <AppShell>
      <div className="min-h-screen bg-[#f5f5f5] text-zinc-800 pb-16">
        {/* Shopee Style Breadcrumbs */}
        <div className="bg-white border-b border-zinc-200 py-4 mb-6">
          <div className="mx-auto max-w-4xl px-4 flex items-center gap-2 text-[11px] text-zinc-400 font-bold uppercase tracking-wider">
            <span>Início</span>
            <span className="text-zinc-300">&gt;</span>
            <span className="text-[#EE4D2D]">Limite de Créditos</span>
          </div>
        </div>

        <div className="mx-auto max-w-2xl px-4">
          <div className="bg-white rounded border border-zinc-200 overflow-hidden shadow-xs">
            {/* Header with gradient warning banner */}
            <div className="bg-gradient-to-r from-orange-500 to-[#EE4D2D] p-6 text-white text-center relative">
              <div className="absolute top-2 right-4 text-white/20">
                <Sparkles className="w-20 h-20" />
              </div>
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/10 mb-3 border border-white/20">
                <AlertTriangle className="h-6 w-6 text-orange-100" />
              </div>
              <h1 className="text-2xl font-black tracking-tight">Créditos Diários Esgotados!</h1>
              <p className="text-xs text-orange-50 mt-1.5 max-w-md mx-auto font-medium">
                Você atingiu o limite de postagens gratuitas geradas por Inteligência Artificial
                para o dia de hoje.
              </p>
            </div>

            {/* Content area */}
            <div className="p-6 md:p-8 space-y-6">
              {/* Countdown box */}
              <div className="bg-amber-50/50 border border-amber-100 rounded p-4 text-center">
                <span className="text-[10px] uppercase font-extrabold text-amber-800 tracking-wider flex items-center justify-center gap-1.5 mb-1">
                  <Clock className="w-3.5 h-3.5" /> Próxima renovação automática
                </span>
                <p className="text-sm font-semibold text-amber-900 leading-relaxed">
                  Seus créditos diários gratuitos serão restaurados para 100 à{" "}
                  <span className="font-bold underline">meia-noite (00:00)</span> em:
                </p>
                <div className="mt-2.5 font-mono text-2xl font-black text-[#EE4D2D] tracking-wider">
                  {timeLeft || "Calculando..."}
                </div>
                <span className="text-[9px] text-amber-600 block mt-1 font-bold uppercase tracking-wider">
                  (Horário Oficial de Brasília)
                </span>
              </div>

              {/* Exact Requested Message Card */}
              <div className="border-2 border-dashed border-[#EE4D2D]/30 rounded-lg p-5 bg-orange-50/20 text-center space-y-2">
                <p className="text-sm font-black text-[#EE4D2D] leading-relaxed">
                  Quer adquirir mais créditos? Compre no link abaixo:
                </p>
                <a
                  href="https://go.ironpayapp.com.br/gpzrxjmshd"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block font-mono text-xs text-[#EE4D2D] hover:underline font-bold break-all"
                >
                  https://go.ironpayapp.com.br/gpzrxjmshd
                </a>
              </div>

              {/* Offer block */}
              <div className="border border-zinc-100 rounded p-6 bg-zinc-50/50 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="space-y-1 text-center md:text-left">
                  <span className="text-[10px] bg-[#EE4D2D]/10 text-[#EE4D2D] px-2 py-0.5 rounded font-black tracking-wider uppercase">
                    Acesso Instantâneo
                  </span>
                  <h2 className="text-lg font-black text-zinc-800 tracking-tight mt-1.5">
                    Quero mais créditos agora!
                  </h2>
                  <p className="text-xs text-zinc-500 font-medium max-w-sm">
                    Adquira créditos ilimitados para continuar gerando copys, roteiros e vídeos
                    altamente persuasivos hoje mesmo por apenas R$ 39,90.
                  </p>
                </div>

                <div className="text-center md:text-right shrink-0">
                  <span className="text-[10px] text-zinc-400 block font-bold uppercase">
                    Apenas
                  </span>
                  <div className="flex items-baseline justify-center md:justify-end gap-1 mt-0.5">
                    <span className="text-sm font-extrabold text-[#EE4D2D]">R$</span>
                    <span className="text-3xl font-black text-[#EE4D2D]">39,90</span>
                  </div>
                  <span className="text-[9px] text-emerald-600 block mt-0.5 font-bold uppercase tracking-wider">
                    Sem assinaturas • Pagamento Único
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <div className="space-y-3">
                <a
                  href="https://go.ironpayapp.com.br/gpzrxjmshd"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2.5 rounded bg-[#EE4D2D] hover:bg-[#d83c1f] py-4 px-6 text-sm font-extrabold uppercase tracking-widest text-white shadow-md transition transform active:scale-[0.99] cursor-pointer border border-[#EE4D2D]"
                >
                  <Zap className="h-4 w-4 fill-white" /> Adquirir Mais Créditos{" "}
                  <ArrowRight className="h-4 w-4" />
                </a>

                <div className="flex items-center justify-center gap-1.5 text-[10px] text-zinc-400 font-semibold">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Pagamento 100% seguro com intermediação oficial. Liberação imediata.</span>
                </div>
              </div>

              {/* Benefits list */}
              <div className="border-t border-zinc-100 pt-6 space-y-3">
                <h3 className="text-xs font-black text-zinc-500 uppercase tracking-wider">
                  Vantagens do Pacote de Créditos Ilimitados:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs text-zinc-600 font-medium">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#EE4D2D] mt-1.5 shrink-0" />
                    <span>Postagens em massa em todas as redes de forma 100% ilimitada.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#EE4D2D] mt-1.5 shrink-0" />
                    <span>Criação ilimitada de vídeos de alta conversão sem restrições.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#EE4D2D] mt-1.5 shrink-0" />
                    <span>Servidores dedicados de alta velocidade para postagem imediata.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#EE4D2D] mt-1.5 shrink-0" />
                    <span>
                      Acesso vitalício às novas atualizações do robô de vendas do conselho.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
