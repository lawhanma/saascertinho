import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { ProductCard } from "@/components/ProductCard";
import { GerarAnuncioDialog } from "@/components/GerarAnuncioDialog";
import { getSupplier, type Product } from "@/data/suppliers";
import { ArrowLeft, Flame } from "lucide-react";

export const Route = createFileRoute("/catalogo/$fornecedor")({
  component: SupplierPage,
  head: ({ params }) => {
    const s = getSupplier(params.fornecedor);
    return {
      meta: [
        { title: `${s?.name ?? "Fornecedor"} — Catálogo ApexFinder` },
        {
          name: "description",
          content: s?.tagline ?? "Catálogo de produtos do fornecedor.",
        },
      ],
    };
  },
  loader: ({ params }) => {
    const supplier = getSupplier(params.fornecedor);
    if (!supplier) throw notFound();
    return { supplier };
  },
  notFoundComponent: SupplierNotFound,
});

function shuffleDaily<T>(arr: T[], salt: string): T[] {
  const now = new Date();
  let seed =
    now.getFullYear() * 10000 +
    (now.getMonth() + 1) * 100 +
    now.getDate() +
    salt.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const rand = () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = seed;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function SupplierPage() {
  const { supplier } = Route.useLoaderData();
  const [selected, setSelected] = useState<Product | null>(null);
  const [open, setOpen] = useState(false);

  const products = useMemo<Product[]>(
    () => [...supplier.products].sort((a, b) => b.sold - a.sold),
    [supplier],
  );

  const handleGenerate = (p: Product) => {
    setSelected(p);
    setOpen(true);
  };

  return (
    <AppShell>
      <main className="mx-auto max-w-7xl px-4 py-10 md:py-14">
        <Link
          to="/"
          className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-primary"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar aos fornecedores
        </Link>

        <div className="mb-8 flex items-end justify-between">
          <div>
            <div className="inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-primary">
              <Flame className="h-4 w-4" /> {supplier.category}
            </div>
            <h1 className="mt-1 text-2xl font-black text-foreground md:text-3xl">
              {supplier.name}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">{supplier.tagline}</p>
          </div>
          <span className="hidden text-xs font-medium text-muted-foreground md:block">
            {supplier.productCount} produtos disponíveis
          </span>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p, idx) => {
            const rank = idx + 1;
            return <ProductCard key={p.id} product={p} onGenerate={handleGenerate} rank={rank} />;
          })}
        </div>
      </main>

      <GerarAnuncioDialog product={selected} open={open} onOpenChange={setOpen} />
    </AppShell>
  );
}

function SupplierNotFound() {
  return (
    <AppShell>
      <main className="mx-auto max-w-2xl px-4 py-20 text-center">
        <h1 className="text-2xl font-black">Fornecedor não encontrado</h1>
        <p className="mt-2 text-muted-foreground">
          Escolha um dos fornecedores disponíveis no catálogo.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Ir ao catálogo
        </Link>
      </main>
    </AppShell>
  );
}
