import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { SUPPLIERS } from "@/data/suppliers";
import { Button } from "@/components/ui/button";
import { Package, ArrowRight, Flame, Check } from "lucide-react";

export const Route = createFileRoute("/catalogo/")({
  component: CatalogoPage,
  head: () => ({
    meta: [
      { title: "Catálogo — ApexFinder" },
      {
        name: "description",
        content: "Fornecedores parceiros com produtos prontos para você anunciar.",
      },
    ],
  }),
});

const STORAGE_KEY = "apex_suppliers_registered";

function readRegistered(): Record<string, boolean> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "{}");
  } catch {
    return {};
  }
}

function CatalogoPage() {
  const [registered, setRegistered] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setRegistered(readRegistered());
  }, []);

  const toggleRegister = (id: string) => {
    setRegistered((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  return (
    <AppShell>
      <main className="mx-auto max-w-6xl px-4 py-10 md:py-14">
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-primary">
            <Flame className="h-4 w-4" /> Fornecedores parceiros
          </div>
          <h1 className="mt-1 text-2xl font-black text-foreground md:text-3xl">
            Escolha um fornecedor
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Cada fornecedor traz uma seleção exclusiva de produtos prontos para divulgar.
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {SUPPLIERS.map((s) => {
            const isRegistered = !!registered[s.id];
            return (
              <div
                key={s.id}
                className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 transition-all hover:-translate-y-0.5 md:flex-row md:items-center md:justify-between"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="flex items-center gap-4">
                  <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-secondary">
                    <img
                      src={s.cover}
                      alt={s.name}
                      loading="lazy"
                      width={200}
                      height={200}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="text-[11px] font-bold uppercase tracking-wider text-primary">
                      {s.category}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-black text-foreground md:text-xl">{s.name}</h2>
                      <button
                        type="button"
                        onClick={() => toggleRegister(s.id)}
                        aria-pressed={isRegistered}
                        className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wider text-white shadow-sm transition-transform hover:scale-105 ${
                          isRegistered
                            ? "bg-green-600 hover:bg-green-700"
                            : "bg-red-600 hover:bg-red-700"
                        }`}
                      >
                        {isRegistered ? (
                          <>
                            <Check className="h-3 w-3" /> Cadastrado
                          </>
                        ) : (
                          "Cadastrar"
                        )}
                      </button>
                    </div>
                    <p className="text-sm text-muted-foreground">{s.tagline}</p>
                    <div className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                      <Package className="h-3.5 w-3.5" />
                      {s.productCount} produtos disponíveis
                    </div>
                  </div>
                </div>
                <Button asChild size="lg" className="font-bold tracking-wide">
                  <Link
                    to="/catalogo/$fornecedor"
                    params={{ fornecedor: s.id }}
                    className="inline-flex items-center gap-2"
                  >
                    <Package className="h-4 w-4" />
                    Catálogo
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            );
          })}
        </div>
      </main>
    </AppShell>
  );
}
