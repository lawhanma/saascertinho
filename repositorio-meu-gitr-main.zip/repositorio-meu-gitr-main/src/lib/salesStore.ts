import { useEffect, useState } from "react";
import { getDeviceBalance, setDeviceBalance } from "./deviceBalance.functions";
import { products } from "../data/products";

const KEY_BALANCE = "apex_balance";
const KEY_COUNT = "apex_divulg_count";
const KEY_DEVICE = "apex_device_id";
const KEY_SALES_COUNT = "apex_sales_count";
const KEY_UNITS_COUNT = "apex_units_count";
const KEY_VISITORS_COUNT = "apex_visitors_count";
const KEY_VIEWS_COUNT = "apex_views_count";
const KEY_AI_CREDITS = "apex_ai_credits";
const KEY_AI_CREDITS_DATE = "apex_ai_credits_date";
const KEY_LAST_INITIALIZED_DATE = "apex_last_init_date";
const KEY_DAILY_TARGET_LIMIT = "apex_daily_target_limit";
const EVENT = "apex-balance-changed";
const EVENT_STATS = "apex-stats-changed";

export interface ProductSaleCount {
  id: string;
  name: string;
  price: number;
  soldQty: number;
}

export const SIMULATED_PRODUCTS = [
  { id: "camiseta-brasil", name: "Kit Álbum Copa do Mundo 2026 + 3 Envelopes", price: 167.7 },
  { id: "smartwatch", name: "Smartwatch Serie 8 Ultra", price: 149.9 },
  {
    id: "fone-bluetooth",
    name: "Kit Até 20 Painel Ripado Autocolante Decoração Adesivo...",
    price: 139.86,
  },
  { id: "tenis", name: "Chinelo Slide Nuvem Confort", price: 119.96 },
  { id: "mochila", name: "Mochila Notebook Impermeável", price: 119.9 },
];

const KEY_PRODUCT_SALES = "apex_product_sales_counts_v2";

export function getProductSalesCounts(): ProductSaleCount[] {
  if (typeof window === "undefined") return [];
  const saved = window.localStorage.getItem(KEY_PRODUCT_SALES);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
  }

  const initial: ProductSaleCount[] = [
    {
      id: "camiseta-brasil",
      name: "Kit Álbum Copa do Mundo 2026 + 3 Envelopes",
      price: 167.7,
      soldQty: 3,
    },
    {
      id: "smartwatch",
      name: "Smartwatch Serie 8 Ultra",
      price: 149.9,
      soldQty: 1,
    },
    {
      id: "fone-bluetooth",
      name: "Kit Até 20 Painel Ripado Autocolante Decoração Adesivo...",
      price: 139.86,
      soldQty: 14,
    },
    {
      id: "tenis",
      name: "Chinelo Slide Nuvem Confort",
      price: 119.96,
      soldQty: 4,
    },
    {
      id: "mochila",
      name: "Mochila Notebook Impermeável",
      price: 119.9,
      soldQty: 1,
    },
  ];
  window.localStorage.setItem(KEY_PRODUCT_SALES, JSON.stringify(initial));
  return initial;
}

export function incrementProductSales(productId: string, qty: number) {
  if (typeof window === "undefined") return;
  const list = getProductSalesCounts();
  const item = list.find((x) => x.id === productId);
  if (item) {
    item.soldQty += qty;
  } else {
    const sp = SIMULATED_PRODUCTS.find((x) => x.id === productId);
    if (sp) {
      list.push({
        id: sp.id,
        name: sp.name,
        price: sp.price,
        soldQty: qty,
      });
    }
  }
  window.localStorage.setItem(KEY_PRODUCT_SALES, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent(EVENT_STATS));
}

const INCREMENTS = [9.97, 12.1, 5.39];

function getDeviceId(): string {
  if (typeof window === "undefined") return "";
  let id = window.localStorage.getItem(KEY_DEVICE);
  if (!id) {
    id =
      (window.crypto?.randomUUID?.() as string | undefined) ??
      `dev-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    window.localStorage.setItem(KEY_DEVICE, id);
  }
  return id;
}

export function initializeOrSyncStatsForToday() {
  if (typeof window === "undefined") return;

  const now = new Date();
  const todayStr = now.toLocaleDateString("pt-BR"); // "DD/MM/YYYY"
  const lastInitDate = window.localStorage.getItem(KEY_LAST_INITIALIZED_DATE);

  const hour = now.getHours();
  const min = now.getMinutes();
  const dayProgress = (hour * 60 + min) / (24 * 60); // 0.0 to 1.0

  // Realistic progressive curve through the day:
  // - 00:00 to 07:00 -> extremely slow (sleeping hours)
  // - 07:00 to 18:00 -> steady high-volume growth
  // - 18:00 to 23:59 -> slower evening taper
  let realisticProgress = dayProgress;
  if (dayProgress < 0.25) {
    // Midnight to 6 AM (slow: 0% to 5%)
    realisticProgress = dayProgress * 0.2;
  } else if (dayProgress < 0.8) {
    // 6 AM to 7:12 PM (fast: 5% to 85%)
    realisticProgress = 0.05 + ((dayProgress - 0.25) / 0.55) * 0.8;
  } else {
    // 7:12 PM to Midnight (slower taper: 85% to 100%)
    realisticProgress = 0.85 + ((dayProgress - 0.8) / 0.2) * 0.15;
  }

  // Ensure target limit for today is around R$ 2,150.00 to R$ 2,280.00 (under 2300 max)
  let todayTarget = Number(window.localStorage.getItem(KEY_DAILY_TARGET_LIMIT));
  if (!todayTarget || lastInitDate !== todayStr) {
    todayTarget = 2150 + Math.random() * 110; // e.g. 2150 to 2260 BRL
    window.localStorage.setItem(KEY_DAILY_TARGET_LIMIT, String(todayTarget));
  }

  const expectedBalance = +(todayTarget * realisticProgress).toFixed(2);
  const expectedVisitors = Math.floor(1528 * realisticProgress) || 45;
  const expectedViews = Math.floor(4299 * realisticProgress) || 120;
  const expectedSales = Math.floor(84 * realisticProgress) || 2;
  const expectedUnits = Math.floor(93 * realisticProgress) || 3;

  const currentBalance = Number(window.localStorage.getItem(KEY_BALANCE) ?? -1);

  if (lastInitDate !== todayStr || currentBalance < 0) {
    window.localStorage.setItem(KEY_LAST_INITIALIZED_DATE, todayStr);
    window.localStorage.setItem(KEY_BALANCE, String(expectedBalance));
    window.localStorage.setItem(KEY_VISITORS_COUNT, String(expectedVisitors));
    window.localStorage.setItem(KEY_VIEWS_COUNT, String(expectedViews));
    window.localStorage.setItem(KEY_SALES_COUNT, String(expectedSales));
    window.localStorage.setItem(KEY_UNITS_COUNT, String(expectedUnits));
    window.localStorage.setItem("apex_last_sim_sale_time", String(Date.now()));

    window.dispatchEvent(new CustomEvent(EVENT));
    window.dispatchEvent(new CustomEvent(EVENT_STATS));
  } else {
    // If already initialized for today, let's catch up on any 15-minute background intervals
    const lastSimSaleTimeStr = window.localStorage.getItem("apex_last_sim_sale_time");
    if (lastSimSaleTimeStr) {
      const lastSimTime = Number(lastSimSaleTimeStr);
      const elapsedMs = Date.now() - lastSimTime;
      const intervalMs = 15 * 60 * 1000; // 15 minutes

      if (elapsedMs >= intervalMs) {
        const intervalsPassed = Math.floor(elapsedMs / intervalMs);
        let tempBalance = Number(window.localStorage.getItem(KEY_BALANCE) ?? 0);
        let tempSales = Number(window.localStorage.getItem(KEY_SALES_COUNT) ?? 0);
        let tempUnits = Number(window.localStorage.getItem(KEY_UNITS_COUNT) ?? 0);
        let tempVisitors = Number(window.localStorage.getItem(KEY_VISITORS_COUNT) ?? 0);
        let tempViews = Number(window.localStorage.getItem(KEY_VIEWS_COUNT) ?? 0);

        for (let i = 0; i < Math.min(intervalsPassed, 12); i++) {
          const saleValue = 15 + Math.random() * 55; // R$ 15 to R$ 70
          if (tempBalance + saleValue <= 2300) {
            tempBalance += saleValue;
            tempSales += 1;
            const unitsSold = Math.random() > 0.7 ? 2 : 1;
            tempUnits += unitsSold;
            tempVisitors += Math.floor(8 + Math.random() * 15);
            tempViews += Math.floor(25 + Math.random() * 45);

            // Dynamically increment random product sale
            const p = SIMULATED_PRODUCTS[Math.floor(Math.random() * SIMULATED_PRODUCTS.length)];
            incrementProductSales(p.id, unitsSold);
          }
        }

        window.localStorage.setItem(KEY_BALANCE, String(+tempBalance.toFixed(2)));
        window.localStorage.setItem(KEY_SALES_COUNT, String(tempSales));
        window.localStorage.setItem(KEY_UNITS_COUNT, String(tempUnits));
        window.localStorage.setItem(KEY_VISITORS_COUNT, String(tempVisitors));
        window.localStorage.setItem(KEY_VIEWS_COUNT, String(tempViews));
        window.localStorage.setItem("apex_last_sim_sale_time", String(Date.now()));

        window.dispatchEvent(new CustomEvent(EVENT));
        window.dispatchEvent(new CustomEvent(EVENT_STATS));
      }
    }
  }
}

export interface SaleResult {
  amount: number;
  added: boolean;
  productName: string;
  productImage: string;
  productPrice: number;
}

export function triggerRandomSale(specificProductId?: string): SaleResult {
  if (typeof window === "undefined") {
    return { amount: 0, added: false, productName: "", productImage: "", productPrice: 0 };
  }

  initializeOrSyncStatsForToday();

  const currentBalance = Number(window.localStorage.getItem(KEY_BALANCE) ?? 0);
  const saleValue = +(15 + Math.random() * 55).toFixed(2); // Between 15 and 70 BRL

  if (currentBalance + saleValue > 2300) {
    // Hard cap at R$ 2300 as requested
    return { amount: 0, added: false, productName: "", productImage: "", productPrice: 0 };
  }

  // Pick the product
  let selectedProduct = SIMULATED_PRODUCTS[Math.floor(Math.random() * SIMULATED_PRODUCTS.length)];
  if (specificProductId) {
    const found = SIMULATED_PRODUCTS.find((p) => p.id === specificProductId);
    if (found) {
      selectedProduct = found;
    }
  }

  const nextBalance = +(currentBalance + saleValue).toFixed(2);
  const nextSales = Number(window.localStorage.getItem(KEY_SALES_COUNT) ?? 0) + 1;
  const nextUnits = Number(window.localStorage.getItem(KEY_UNITS_COUNT) ?? 0) + 1;
  const nextVisitors =
    Number(window.localStorage.getItem(KEY_VISITORS_COUNT) ?? 100) +
    Math.floor(5 + Math.random() * 12);
  const nextViews =
    Number(window.localStorage.getItem(KEY_VIEWS_COUNT) ?? 300) +
    Math.floor(15 + Math.random() * 30);

  window.localStorage.setItem(KEY_BALANCE, String(nextBalance));
  window.localStorage.setItem(KEY_SALES_COUNT, String(nextSales));
  window.localStorage.setItem(KEY_UNITS_COUNT, String(nextUnits));
  window.localStorage.setItem(KEY_VISITORS_COUNT, String(nextVisitors));
  window.localStorage.setItem(KEY_VIEWS_COUNT, String(nextViews));
  window.localStorage.setItem("apex_last_sim_sale_time", String(Date.now()));

  // Increment product sales for sync!
  incrementProductSales(selectedProduct.id, 1);

  // Find actual image asset from our full products list if possible
  const realProduct = products.find((p) => p.id === selectedProduct.id);
  const productImage = realProduct ? realProduct.image : "";

  // Dispatch events so hooks update in real time
  window.dispatchEvent(new CustomEvent(EVENT));
  window.dispatchEvent(new CustomEvent(EVENT_STATS));

  return {
    amount: saleValue,
    added: true,
    productName: selectedProduct.name,
    productImage: productImage,
    productPrice: selectedProduct.price,
  };
}

function readLocal(key: string, defaultValue = 0): number {
  if (typeof window === "undefined") return defaultValue;
  const v = window.localStorage.getItem(key);
  if (v === null) return defaultValue;
  const num = Number(v);
  return isNaN(num) ? defaultValue : num;
}

function writeLocal(balance: number, count: number) {
  window.localStorage.setItem(KEY_BALANCE, String(balance));
  window.localStorage.setItem(KEY_COUNT, String(count));
  window.dispatchEvent(new CustomEvent(EVENT));
}

async function persist(balance: number, count: number) {
  const deviceId = getDeviceId();
  try {
    await setDeviceBalance({ data: { deviceId, balance, divulgCount: count } });
  } catch (e) {
    console.error("Falha ao salvar saldo no banco", e);
  }
}

export function addDivulgacao(): { increment: number; balance: number } {
  const count = readLocal(KEY_COUNT);
  const increment = INCREMENTS[count % INCREMENTS.length];
  const balance = +(readLocal(KEY_BALANCE) + increment).toFixed(2);
  const newCount = count + 1;
  writeLocal(balance, newCount);
  void persist(balance, newCount);

  // Increment stats on manual share too!
  addStats({
    visitors: Math.floor(Math.random() * 4) + 1,
    views: Math.floor(Math.random() * 8) + 2,
    sales: Math.random() > 0.6 ? 1 : 0,
    units: Math.random() > 0.6 ? 1 : 0,
  });

  return { increment, balance };
}

/**
 * Adiciona uma comissão de uma venda.
 * A comissão nunca pode exceder o valor do produto vendido.
 */
export function addCommission(amount: number, productPrice?: number): number {
  const capped = typeof productPrice === "number" ? Math.min(amount, productPrice) : amount;
  const safe = Math.max(0, +capped.toFixed(2));
  const balance = +(readLocal(KEY_BALANCE) + safe).toFixed(2);
  const count = readLocal(KEY_COUNT);
  writeLocal(balance, count);
  void persist(balance, count);
  return balance;
}

export function withdrawAmount(amount: number): number {
  const current = readLocal(KEY_BALANCE);
  const balance = +Math.max(0, current - amount).toFixed(2);
  const count = readLocal(KEY_COUNT);
  writeLocal(balance, count);
  void persist(balance, count);
  return balance;
}

export function useBalance(): number {
  const [balance, setBalance] = useState<number>(0);
  useEffect(() => {
    initializeOrSyncStatsForToday();
    // Hydrate from DB on mount so the dashboard persists per device across browsers/sessions.
    const deviceId = getDeviceId();
    getDeviceBalance({ data: { deviceId } })
      .then(({ balance: b, divulgCount: c }) => {
        writeLocal(b, c);
        setBalance(b);
      })
      .catch(() => setBalance(readLocal(KEY_BALANCE)));

    const handler = () => setBalance(readLocal(KEY_BALANCE));
    window.addEventListener(EVENT, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(EVENT, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return balance;
}

export function formatBRL(n: number): string {
  return n.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

// Stats persistence and retrieval
export interface DashboardStats {
  sales: number;
  units: number;
  visitors: number;
  views: number;
}

export function getStats(): DashboardStats {
  // Default values
  const defaultVisitors = 24;
  const defaultViews = 36;

  return {
    sales: readLocal(KEY_SALES_COUNT, 0),
    units: readLocal(KEY_UNITS_COUNT, 0),
    visitors: readLocal(KEY_VISITORS_COUNT, defaultVisitors),
    views: readLocal(KEY_VIEWS_COUNT, defaultViews),
  };
}

export function addStats(update: Partial<DashboardStats>) {
  const current = getStats();
  const sales = current.sales + (update.sales ?? 0);
  const units = current.units + (update.units ?? 0);
  const visitors = current.visitors + (update.visitors ?? 0);
  const views = current.views + (update.views ?? 0);

  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY_SALES_COUNT, String(sales));
    window.localStorage.setItem(KEY_UNITS_COUNT, String(units));
    window.localStorage.setItem(KEY_VISITORS_COUNT, String(visitors));
    window.localStorage.setItem(KEY_VIEWS_COUNT, String(views));
    window.dispatchEvent(new CustomEvent(EVENT_STATS));
  }
}

export function useStats(): DashboardStats {
  const [stats, setStats] = useState<DashboardStats>(getStats());

  useEffect(() => {
    initializeOrSyncStatsForToday();
    const handler = () => {
      setStats(getStats());
    };
    window.addEventListener(EVENT_STATS, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(EVENT_STATS, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  return stats;
}

// AI Credits Logic
export function getBrasiliaDateString(): string {
  const d = new Date();
  const utc = d.getTime() + d.getTimezoneOffset() * 60000;
  const brTime = new Date(utc + 3600000 * -3);
  const yyyy = brTime.getFullYear();
  const mm = String(brTime.getMonth() + 1).padStart(2, "0");
  const dd = String(brTime.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export function getAICredits(): number {
  if (typeof window === "undefined") return 100;

  const todayStr = getBrasiliaDateString();
  const lastDate = window.localStorage.getItem(KEY_AI_CREDITS_DATE);

  // If date is different or not set, renew to 100 daily credits!
  if (lastDate !== todayStr) {
    window.localStorage.setItem(KEY_AI_CREDITS_DATE, todayStr);
    window.localStorage.setItem(KEY_AI_CREDITS, "100");
    return 100;
  }

  const savedCredits = window.localStorage.getItem(KEY_AI_CREDITS);
  if (savedCredits === null) return 100;
  const num = Number(savedCredits);
  if (isNaN(num) || num <= 0) {
    // Automatically replenish if depleted
    window.localStorage.setItem(KEY_AI_CREDITS, "100");
    return 100;
  }
  return num;
}

export function spendAICredits(amount: number): number {
  const current = getAICredits();
  const next = Math.max(0, current - amount);
  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY_AI_CREDITS, String(next));
    window.dispatchEvent(new CustomEvent(EVENT_STATS)); // Trigger stats update event
  }
  return next;
}

export function setAICreditsDirectly(amount: number) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY_AI_CREDITS, String(amount));
    window.dispatchEvent(new CustomEvent(EVENT_STATS));
  }
}
