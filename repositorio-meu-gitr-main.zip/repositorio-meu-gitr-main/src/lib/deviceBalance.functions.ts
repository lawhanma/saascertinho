import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

function getClient() {
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  const url = process.env.SUPABASE_URL!;
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const getDeviceBalance = createServerFn({ method: "GET" })
  .inputValidator((input) => z.object({ deviceId: z.string().min(1) }).parse(input))
  .handler(async ({ data }) => {
    const supabase = getClient();
    const { data: row } = await supabase
      .from("device_balances")
      .select("balance, divulg_count")
      .eq("device_id", data.deviceId)
      .maybeSingle();
    return {
      balance: Number(row?.balance ?? 0),
      divulgCount: Number(row?.divulg_count ?? 0),
    };
  });

export const setDeviceBalance = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        deviceId: z.string().min(1),
        balance: z.number().min(0),
        divulgCount: z.number().int().min(0),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const supabase = getClient();
    const { error } = await supabase.from("device_balances").upsert(
      {
        device_id: data.deviceId,
        balance: data.balance,
        divulg_count: data.divulgCount,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "device_id" },
    );
    if (error) throw new Error(error.message);
    return { balance: data.balance, divulgCount: data.divulgCount };
  });
