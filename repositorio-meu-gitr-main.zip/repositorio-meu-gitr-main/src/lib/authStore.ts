import { useEffect, useState } from "react";

const KEY = "apex_auth_user";
const EVENT = "apex-auth-changed";

export function getAuthUser(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(KEY);
}

export function signIn(username: string) {
  window.localStorage.setItem(KEY, username);
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function signOut() {
  window.localStorage.removeItem(KEY);
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function useAuthUser() {
  const [user, setUser] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    setUser(getAuthUser());
    setReady(true);
    const h = () => setUser(getAuthUser());
    window.addEventListener(EVENT, h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener(EVENT, h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return { user, ready };
}

export const APP_PASSWORD = "101190";
